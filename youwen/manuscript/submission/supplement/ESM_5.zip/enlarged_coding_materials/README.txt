MATERIALS OF THE ENLARGED CODING
Online Resource 5 (ESM_5.zip)

Article title:  What does 'also phonetic' mark? The Shuōwén's yìshēng label, homophony and derivation in Old Chinese
Journal:        Morphology
Authors:        Withheld for double-anonymous review
Corresponding author (affiliation, e-mail): Withheld for double-anonymous review

Caption: Materials of the enlarged coding: the 14 prompts (7 batches, 2 passes), the raw answers returned by the Claude instances, the two second answers that were not used, the blank sheet for the authors' check and the log of when each answer was collected.

CONTENTS

  prompts/pass{1,2}_b{01..07}.txt
      The complete prompt given to each of the 14 coders (Claude instances; 2 passes x 7 batches), exactly as sent. Each prompt holds the coding
      instructions and about 100 items; an item line reads: item number, phonetic, its gloss, compound, its gloss (tab-separated; the
      Shuowen structural analysis, such as 從某 or 某聲, is removed from the glosses). The group (yisheng or ordinary) is never shown.
  raw_answers/pass{1,2}_b{01..07}.txt
      The answer of each instance, saved unchanged. A line reads: item number, code, confidence, note (tab-separated). In pass 2,
      batch 5 the instance wrote explanatory text before and after the coding lines; it is kept as returned (only the coding lines are read).
  raw_answers/pass1_b03_second_answer_not_used.txt, raw_answers/pass1_b06_second_answer_not_used.txt
      In two batches of pass 1 the environment returned a second answer. A rule fixed before any analysis was run says that the first
      complete, acceptable answer of an instance counts; the second answers enter no main analysis and are used only in the sensitivity
      analysis X5 (Table 8 note; Online Resource 4, Section 7, and Online Resource 6).
  item_key.csv
      The key that links every prompt line to a pair: sw_id (the key of Online Resource 2), phonetic, compound, relation (亦聲 = labelled,
      聲 = ordinary), role (new = coded for the first time; anchor = first-sample item added to a batch as a calibration check: 5 per batch, 35 in all, each coded once in each pass),
      sampling stratum, whether Middle and Old Chinese forms exist, the batch and item position of the pair in pass 1 and pass 2,
      and the glosses shown. The group was never shown to the coders. Column definitions: data_dictionary.csv in Online Resource 7.
  author_check_sheet_blank.xlsx
      The sheet on which the authors checked 126 items, blank, as sent (English rendering of the instructions and headers; the original
      was in Chinese and is given beside the English). The sheet showed the type of each item (the passes disagree / drawn at random from
      those that agree) and the codes of the two passes (columns H and I); the instructions asked the authors to enter their own judgment
      before looking at the codes. The consolidated filled sheet is the sheet "author_check" of Online Resource 3.
  collection_log.csv
      When each answer was collected (UTC), whether the prompt that was sent was identical to the file in prompts/, the tool calls the
      instance reported (the only one is the hand-back of its answer; the first answer of pass 1, batch 3 came as plain text, with none),
      and the number of parsable lines against the number of items expected.

HOW THE FILES FIT TOGETHER

Reading a prompt and its answer: line i of prompts/passP_bBB.txt (after the instructions) and line i of raw_answers/passP_bBB.txt carry the
same item number; item_key.csv gives the pair behind it (columns pP_batch and pP_item). Online Resource 3 (sheet "enlarged_coding") lists
the codes, confidence and notes of both passes next to the pair; Online Resource 7 (scripts/ext_analysis.py) parses these raw answers and
runs the analyses. The prompts can be regenerated from the sampling script and are compared by hash in the self-check.

LICENCE

CC BY 4.0 for the authors' contributions (prompts, answers, key, log). The glosses in the key and the prompts are Shuowen text from the
shuowenjiezi project (Apache License 2.0, https://github.com/shuowenjiezi/shuowen).
