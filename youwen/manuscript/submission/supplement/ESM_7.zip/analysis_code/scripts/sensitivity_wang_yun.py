# Sensitivity analysis: rerun the H1a, H1c and H2 models of the paper after removing the yisheng labels that Wang Yun (Shuowen shili, juan 3) judges to be Da Xu's
#   erroneous additions: the nine characters 貧 愾 恇 娶 婚 姻 婢 緉 坪 (juan 3, "all of these are Da Xu's mistaken additions"); juan 8 also rejects 媄 (the "ten" variant adds it).
# Two treatments: drop = the row is removed; as_sheng = the character is recoded as an ordinary sheng compound (Wang Yun holds that the label is wrong,
#   the character is still a phonetic compound with the same phonetic).
# Usage: python scripts/sensitivity_wang_yun.py
# Reads:  data/pairs.csv, data/first_sample_codes.csv      Writes: output/yisheng_models_wangyun_sensitivity.csv
import csv, math, warnings
import pandas as pd, statsmodels.api as sm, statsmodels.formula.api as smf
from statsmodels.genmod.bayes_mixed_glm import BinomialBayesMixedGLM
from _paths import DATA, OUT
warnings.filterwarnings('ignore')
LAB, ORD = 'labelled', 'ordinary'
W9 = set('貧愾恇娶婚姻婢緉坪'); W10 = W9 | {'媄'}
R = list(csv.DictReader(open(DATA / 'pairs.csv', encoding='utf-8-sig', newline='')))
# The blind semantic codes of the first sample (used for H2), keyed by phonetic, character and group
S = list(csv.DictReader(open(DATA / 'first_sample_codes.csv', encoding='utf-8-sig', newline='')))
DS = {(r['phonetic'], r['char'], r['group']): r for r in R}    # one character can occur under two phonetics or in two groups, hence the group is part of the key

def variant(excl, mode):
    rows = []
    for r in R:
        if r['in_analysis_set'] != 'True': continue
        if r['group'] == LAB and r['char'] in excl:
            if mode == 'drop': continue
            r = dict(r, group=ORD)
        rows.append(r)
    yph = {r['phonetic'] for r in rows if r['group'] == LAB}
    return [r for r in rows if r['phonetic'] in yph]
def h2rows(excl, mode):
    out = []
    for s in S:
        d = DS.get((s['phonetic'], s['member'], s['group']))
        if not d or d['in_analysis_set'] != 'True' or s['blind_code'] == 'X': continue
        grp = d['group']
        if grp == LAB and s['member'] in excl:
            if mode == 'drop': continue
            grp = ORD
        out.append(dict(y=int(s['blind_code'] in 'YE'), label=int(grp == LAB), phon=d['phonetic'], par=d['paronomastic_gloss']))
    return pd.DataFrame(out)
def fit(df, vb=True):
    g = smf.gee('y ~ label', groups='phon', data=df, family=sm.families.Binomial(), cov_struct=sm.cov_struct.Exchangeable()).fit()
    b, se = g.params['label'], g.bse['label']; p = g.pvalues['label'] / 2 if b > 0 else 1 - g.pvalues['label'] / 2
    res = dict(n=len(df), n_phonetics=df.phon.nunique(), labelled_hits=int(df[df.label == 1].y.sum()), labelled_n=int((df.label == 1).sum()),
               ordinary_hits=int(df[df.label == 0].y.sum()), ordinary_n=int((df.label == 0).sum()),
               gee_OR=round(math.exp(b), 2), gee_CI95=f'{math.exp(b - 1.96 * se):.2f}-{math.exp(b + 1.96 * se):.2f}', gee_p_one_sided='%.2g' % p)
    if vb:
        v = BinomialBayesMixedGLM.from_formula('y ~ label', {'phon': '0 + C(phon)'}, df).fit_vb()
        i = list(v.model.exog_names).index('label'); bm, sd = v.fe_mean[i], v.fe_sd[i]
        res.update(glmm_vb_OR=round(math.exp(bm), 2), glmm_vb_CI95=f'{math.exp(bm - 1.96 * sd):.2f}-{math.exp(bm + 1.96 * sd):.2f}')
    return res
res = []
for vname, excl, mode in [('original', set(), 'drop'), ('drop Wang 9', W9, 'drop'), ('drop Wang 10 (+ 媄)', W10, 'drop'),
                          ('Wang 9 recoded as ordinary (sheng)', W9, 'as_sheng'), ('Wang 10 recoded as ordinary (sheng)', W10, 'as_sheng')]:
    A = variant(excl, mode)
    mc = [r for r in A if r['mc_relation'] != 'NA']
    df = pd.DataFrame(dict(y=[int(r['mc_relation'] == 'identical') for r in mc], label=[int(r['group'] == LAB) for r in mc], phon=[r['phonetic'] for r in mc]))
    res.append(dict(variant=vname, hypothesis='H1a', outcome='MC identical syllable', **fit(df)))
    alt = [r for r in mc if r['mc_relation'] == 'tone_voicing_alt']
    df = pd.DataFrame(dict(y=[int(r['mc_qusheng_direction'] == 'member') for r in alt], label=[int(r['group'] == LAB) for r in alt], phon=[r['phonetic'] for r in alt]))
    res.append(dict(variant=vname, hypothesis='H1c', outcome='member departing | tone/voicing alternation', **fit(df)))
    h = h2rows(excl, mode)
    res.append(dict(variant=vname, hypothesis='H2', outcome='semantic Y/E (blind LLM coding, X excluded)', **fit(h, vb=False)))
    res.append(dict(variant=vname, hypothesis='H2', outcome='same, paronomastic glosses removed', **fit(h[h.par == 'False'], vb=False)))
with open(OUT / 'yisheng_models_wangyun_sensitivity.csv', 'w', newline='', encoding='utf-8-sig') as f:
    w = csv.DictWriter(f, fieldnames=list(dict.fromkeys(k for r in res for k in r)), lineterminator='\n'); w.writeheader(); w.writerows(res)
for r in res: print(r['variant'], '|', r['hypothesis'], r['outcome'][:30], f"{r['labelled_hits']}/{r['labelled_n']} vs {r['ordinary_hits']}/{r['ordinary_n']}", r['gee_OR'], r['gee_CI95'], r['gee_p_one_sided'], r.get('glmm_vb_OR', ''))
