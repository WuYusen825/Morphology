# Additional analyses reported in the paper (profiles, within-phonetic comparisons, direction of the departing tone, recension layers, combined checks, the sampling frame).
# Nothing here changes a data file; the script reads data/pairs.csv and the coding tables and writes output/yisheng_models_extra_checks.csv.
#  1. Four-way Middle Chinese (MC) profile: identical / tone-voicing alternation involving the departing tone / other tone-voicing alternation / other difference
#     (mutually exclusive; denominator = all pairs with MC readings at both ends)
#  2. Within-phonetic (stratified) comparison: Mantel-Haenszel pooled OR and CMH test, using only phonetics that have both labelled and ordinary members
#     (GEE only corrects for dependence; it does not remove baseline differences between phonetics)
#  3. Precision of the H1c two-step decomposition: is the departing tone involved at all; if so, which end carries it (conditional MLE OR with exact 95% CI)
#  4. H1b, Old Chinese (OC) R category split: R involving *-s versus R not involving *-s ("other affixes")
#  5. Duan Yucai notes on "xingsheng containing huiyi" and similar phrases for ordinary compounds (exploratory, descriptive; needs the open Shuowen data, see below)
#  6. Subdivision of non-departing alternations (descriptive): voicing only / level-rising tone only / both, among non-identical pairs with MC readings at both ends
#  7. H1a, H1c and departing-tone alternation redone without paronomastic glosses (glosses that explain the character by its phonetic)
#  8. Baseline for direction (descriptive): among pairs with exactly one departing-tone end, the share in which the member is the departing-tone end
#  9. MC four-way profile of the labelled pairs by recension layer (descriptive): layer shared by both recensions versus Da Xu only
# 10. The "other difference" pairs (descriptive): share with both initial and final different; share of OC R among pairs with OC forms; semantic coding of such labelled pairs
# 11. Labels not filed under their own phonetic, compared by layer for MC identity; paronomastic glosses by layer (descriptive)
# 12. Within semantically related pairs: does the label still predict identity or a departing-tone alternation (descriptive; small sample)
#     12b pooled over both groups: share coded related in each MC category; 12c within each group: related versus unrelated pairs
# 13. Number of head entries whose Duan notes contain the phrases (all 9,833 head entries, each counted once; needs the open Shuowen data)
# 14. Combined checks: H1a, departing-tone alternation and H1c after removing paronomastic glosses, labels not shared with the Xiao Xu, both ("core" labels),
#     Wang Yun's nine rejected labels, labels filed under their own phonetic; GEE and within-phonetic MH. Only labelled entries are removed (all ordinary compounds are kept),
#     except that the "paronomastic" and "core" rows also remove paronomastic glosses among the ordinary compounds.
#     Also reported: the four-way profile of the labelled pairs by layer x paronomastic gloss; core labels compared with the other labels.
# 15. Two-sided Fisher p for H4 (labels filed under their own phonetic versus the other labels) and for the Duan layer (labels Duan drops versus keeps)
# 16. The sampling frame of the first blind sample: 4 of the 50 ordinary pairs are under phonetics whose only labelled member is a xinfu entry and so lie outside the
#     172-phonetic comparison frame; H2 recomputed without them, and a descriptive logit on the remaining pairs
# Sections 10, 12 and 16 use the first-sample coding table (data/first_sample_codes.csv: blind semantic codes).
# Usage: python scripts/paper_checks.py [path to the open Shuowen JSON data]
#   Sections 5 and 13 count phrases in the Duan Yucai notes of the open Shuowen data (https://github.com/shuowenjiezi/shuowen, directory "data"; third-party, not redistributed here).
#   Without the path, those rows are taken from data/duan_notes_precomputed.csv, which holds the counts computed from that data (see README).
import sys, json, math, csv, glob, warnings
import pandas as pd, numpy as np
import statsmodels.api as sm, statsmodels.formula.api as smf
from statsmodels.stats.contingency_tables import StratifiedTable
from scipy.stats import fisher_exact
from scipy.stats.contingency import odds_ratio
from _paths import DATA, OUT
warnings.filterwarnings('ignore')
swdir = sys.argv[1] if len(sys.argv) > 1 else None
d = pd.read_csv(DATA / 'pairs.csv', encoding='utf-8-sig', dtype=str)      # default missing-value handling: the entries "NA" and "" are missing
A = d[d.in_analysis_set == 'True']
yph = set(A[A.group == 'labelled'].phonetic)
A = A[A.phonetic.isin(yph)].copy()
A['label'] = (A.group == 'labelled').astype(int)
MC = A[A.mc_relation.notna()].copy()
DEP = {'member', 'head'}
def cat4(r):
    if r.mc_relation == 'identical': return 'identical'
    if r.mc_relation == 'tone_voicing_alt': return 'alt_departing' if r.mc_qusheng_direction in DEP else 'alt_other'
    return 'other'
MC['cat4'] = MC.apply(cat4, axis=1)
OC = A[A.morph_relation_auto.notna()].copy()
NI_OC = OC[OC.morph_relation_auto != 'I'].copy()
NI_OC['R_s'] = ((NI_OC.morph_relation_auto == 'R') & NI_OC.morph_affix_detail.fillna('').str.contains('-s')).astype(int)
NI_OC['R_nos'] = ((NI_OC.morph_relation_auto == 'R') & ~NI_OC.morph_affix_detail.fillna('').str.contains('-s')).astype(int)
ALT = MC[MC.mc_relation == 'tone_voicing_alt'].copy()
DEPP = ALT[ALT.mc_qusheng_direction.isin(DEP)].copy()
NI_MC = MC[MC.mc_relation != 'identical'].copy()

out = []
def counts(df, y):
    L = df[df.label == 1]; O = df[df.label == 0]
    return int(L[y].sum()), len(L), int(O[y].sum()), len(O)
def gee(df, y):
    x = pd.DataFrame(dict(y=df[y].astype(int).values, label=df.label.values, phon=df.phonetic.values))
    if x.y.nunique() < 2: return None
    g = smf.gee('y ~ label', groups='phon', data=x, family=sm.families.Binomial(), cov_struct=sm.cov_struct.Exchangeable()).fit()
    b, se = g.params['label'], g.bse['label']
    return math.exp(b), math.exp(b - 1.96 * se), math.exp(b + 1.96 * se), g.pvalues['label']
def mh(df, y):
    tabs = []
    for p, g in df.groupby('phonetic'):
        if g.label.nunique() < 2: continue
        a = int(((g.label == 1) & (g[y] == 1)).sum()); b = int(((g.label == 1) & (g[y] == 0)).sum())
        c = int(((g.label == 0) & (g[y] == 1)).sum()); e = int(((g.label == 0) & (g[y] == 0)).sum())
        tabs.append(np.array([[a, b], [c, e]], dtype=float))
    if not tabs: return None
    st = StratifiedTable(tabs)
    lo, hi = st.oddsratio_pooled_confint()
    t = st.test_null_odds(correction=False)
    L = sum(t_[0].sum() for t_ in tabs); O = sum(t_[1].sum() for t_ in tabs)
    return len(tabs), int(L), int(O), st.oddsratio_pooled, lo, hi, t.pvalue
def add(section, name, df, y, note=''):
    a, n1, c, n0 = counts(df, y)
    r = dict(section=section, comparison=name, labelled_hits=a, labelled_n=n1, ordinary_hits=c, ordinary_n=n0,
             labelled_rate=round(a / n1, 3) if n1 else '', ordinary_rate=round(c / n0, 3) if n0 else '')
    g = gee(df, y)
    if g: r.update(gee_OR=round(g[0], 2), gee_CI95=f'{g[1]:.2f}-{g[2]:.2f}', gee_p_two_sided='%.2g' % g[3])
    m = mh(df, y)
    if m: r.update(mh_strata=m[0], mh_labelled_n=m[1], mh_ordinary_n=m[2], mh_OR=round(m[3], 2), mh_CI95=f'{m[4]:.2f}-{m[5]:.2f}', cmh_p_two_sided='%.2g' % m[6])
    fe = fisher_exact([[a, n1 - a], [c, n0 - c]])
    r['fisher_p_two_sided'] = '%.2g' % fe[1]
    r['note'] = note
    out.append(r)

# 0. Reconciliation with the main results (must give 63/177 vs 133/858 and 16/33 vs 43/150)
MC['identical'] = (MC.cat4 == 'identical').astype(int)
ALT['member_dep'] = (ALT.mc_qusheng_direction == 'member').astype(int)
assert counts(MC, 'identical') == (63, 177, 133, 858), counts(MC, 'identical')
assert counts(ALT, 'member_dep') == (16, 33, 43, 150), counts(ALT, 'member_dep')

# 1. Four-way profile
for k in ['identical', 'alt_departing', 'alt_other', 'other']:
    MC[k] = (MC.cat4 == k).astype(int)
    add('MC profile (all MC pairs)', f'MC category: {k}', MC, k, 'mutually exclusive categories; denominators = all pairs with MC readings at both ends')
# 2. Within-phonetic comparison: main results
add('within-series', 'H1a MC identical (within phonetic)', MC, 'identical', 'MH pooled over phonetics with both labelled and ordinary members')
add('within-series', 'H1c member departing | tone/voicing alternation (within phonetic)', ALT, 'member_dep')
ALT['any_dep'] = ALT.mc_qusheng_direction.isin(DEP).astype(int)
add('within-series', 'departing tone involved | tone/voicing alternation', ALT, 'any_dep', 'step 1 of the H1c decomposition')
NI_MC['alt_other'] = (NI_MC.cat4 == 'alt_other').astype(int)
NI_MC['alt_departing'] = (NI_MC.cat4 == 'alt_departing').astype(int)
add('within-series', 'non-departing tone/voicing alternation | non-identical MC pairs', NI_MC, 'alt_other', 'the MC part of H1b once departing-tone alternations are set aside')
add('within-series', 'departing-tone alternation | non-identical MC pairs', NI_MC, 'alt_departing')
# 3. Direction (the member carries the departing tone)
DEPP['member_dep'] = (DEPP.mc_qusheng_direction == 'member').astype(int)
add('direction', 'member departing | departing-tone alternation', DEPP, 'member_dep', 'step 2 of the H1c decomposition')
a, n1, c, n0 = counts(DEPP, 'member_dep')
orc = odds_ratio([[a, n1 - a], [c, n0 - c]], kind='conditional')
ci = orc.confidence_interval(0.95)
out.append(dict(section='direction', comparison='member departing | departing-tone alternation: conditional MLE OR (exact CI)',
                labelled_hits=a, labelled_n=n1, ordinary_hits=c, ordinary_n=n0, labelled_rate=round(a / n1, 3), ordinary_rate=round(c / n0, 3),
                gee_OR=round(orc.statistic, 2), gee_CI95=f'{ci.low:.2f}-{ci.high:.2f}', note='columns gee_OR/gee_CI95 here hold the conditional MLE OR and its exact 95% CI'))
# 4. OC R split
NI_OC['R'] = (NI_OC.morph_relation_auto == 'R').astype(int)
add('OC R split', 'OC R (any) | non-identical OC pairs', NI_OC, 'R', 'H1b-OC as in yisheng_models.csv')
add('OC R split', 'OC R involving *-s | non-identical OC pairs', NI_OC, 'R_s', 'R with a suffix change involving -s (affix detail contains -s)')
add('OC R split', 'OC R not involving *-s | non-identical OC pairs', NI_OC, 'R_nos', 'other affixes and alternations only')

# 6. Subdivision of the non-departing alternations (descriptive; two-sided Fisher p only)
def alt_sub(r):
    if r.cat4 != 'alt_other': return ''
    v = r.mc_voicing_differs == 'True'; t = r.mc_tone_member != r.mc_tone_head
    if v and not t: return 'voicing_only'
    if t and not v: return 'level_rising_only'
    return 'voicing_and_level_rising'
NI_MC['alt_sub'] = NI_MC.apply(alt_sub, axis=1)
for k, lab in [('voicing_only', 'voicing only'), ('level_rising_only', 'level/rising tone only'), ('voicing_and_level_rising', 'voicing and level/rising tone')]:
    NI_MC[k] = (NI_MC.alt_sub == k).astype(int)
    a, n1, c, n0 = counts(NI_MC, k)
    out.append(dict(section='MC other alternations split (descriptive)', comparison=f'non-departing alternation, {lab} | non-identical MC pairs',
                    labelled_hits=a, labelled_n=n1, ordinary_hits=c, ordinary_n=n0, labelled_rate=round(a / n1, 3), ordinary_rate=round(c / n0, 3),
                    fisher_p_two_sided='%.2g' % fisher_exact([[a, n1 - a], [c, n0 - c]])[1], note='descriptive; subcategories of alt_other'))

# 7. H1a and H1c without paronomastic glosses (GEE and within-phonetic MH)
NOPAR = MC[MC.paronomastic_gloss != 'True'].copy()
add('paronomastic glosses removed', 'H1a MC identical, paronomastic glosses removed', NOPAR, 'identical', 'expected counts as in the paper: 40/126 vs 131/848')
ALT_NP = ALT[ALT.paronomastic_gloss != 'True'].copy()
add('paronomastic glosses removed', 'H1c member departing | tone/voicing alternation, paronomastic glosses removed', ALT_NP, 'member_dep')
NOPAR['alt_departing'] = (NOPAR.cat4 == 'alt_departing').astype(int)
add('paronomastic glosses removed', 'departing-tone alternation | all MC pairs, paronomastic glosses removed', NOPAR, 'alt_departing')

# 8. Baseline for direction (descriptive)
ONE = MC[(MC.mc_tone_member == '去') != (MC.mc_tone_head == '去')].copy()        # '去' = departing tone (qusheng)
ONE['member_dep'] = (ONE.mc_tone_member == '去').astype(int)
t_alt = ONE[ONE.mc_relation == 'tone_voicing_alt']; t_oth = ONE[ONE.mc_relation == 'other']
a, n1, c, n0 = int(t_alt.member_dep.sum()), len(t_alt), int(t_oth.member_dep.sum()), len(t_oth)
out.append(dict(section='direction baseline (descriptive)', comparison='member is the departing-tone end, pairs with exactly one departing end: tone/voicing-only pairs (labelled columns) vs pairs differing in other ways too (ordinary columns); labelled and ordinary compounds pooled',
                labelled_hits=a, labelled_n=n1, ordinary_hits=c, ordinary_n=n0, labelled_rate=round(a / n1, 3), ordinary_rate=round(c / n0, 3),
                fisher_p_two_sided='%.2g' % fisher_exact([[a, n1 - a], [c, n0 - c]])[1], note='baseline for the configuration effect; columns here are not labelled vs ordinary'))
for lab, nm in [(1, 'labelled'), (0, 'ordinary')]:
    sub = t_oth[t_oth.label == lab]
    out.append(dict(section='direction baseline (descriptive)', comparison=f'member is the departing-tone end, pairs differing in other ways too, {nm} compounds only',
                    labelled_hits=int(sub.member_dep.sum()), labelled_n=len(sub), labelled_rate=round(sub.member_dep.mean(), 3), note='descriptive'))

# 9. MC four-way profile of the labelled pairs by recension layer (descriptive)
LAY = {r['sw_id']: r['layer'] for r in csv.DictReader(open(DATA / 'recension_collation.csv', encoding='utf-8-sig', newline=''))}
MC['layer'] = MC.sw_id.map(LAY)
LB = MC[(MC.label == 1) & (MC.layer == 'both')]; LD = MC[(MC.label == 1) & (MC.layer == 'daxu_only')]
for k in ['identical', 'alt_departing', 'alt_other', 'other']:
    a, n1, c, n0 = int(LB[k].sum()), len(LB), int(LD[k].sum()), len(LD)
    out.append(dict(section='labelled pairs by recension layer (descriptive)', comparison=f'MC category: {k}; shared layer (labelled columns) vs Da Xu-only layer (ordinary columns)',
                    labelled_hits=a, labelled_n=n1, ordinary_hits=c, ordinary_n=n0, labelled_rate=round(a / n1, 3), ordinary_rate=round(c / n0, 3),
                    fisher_p_two_sided='%.2g' % fisher_exact([[a, n1 - a], [c, n0 - c]])[1], note='labelled pairs only; undecidable layer (%d pairs) left out' % int(((MC.label == 1) & (MC.layer == 'unknown')).sum())))

# 10. The "other difference" pairs
INI = sorted(['p', 'ph', 'b', 'm', 't', 'th', 'd', 'n', 'tr', 'trh', 'dr', 'nr', 'ts', 'tsh', 'dz', 's', 'z', 'tsr', 'tsrh', 'dzr', 'sr', 'zr',
              'tsy', 'tsyh', 'dzy', 'ny', 'sy', 'zy', 'k', 'kh', 'g', 'ng', "'", 'x', 'h', 'y', 'l'], key=len, reverse=True)
def mc_split(x):  # split a Baxter-Sagart MC transcription into initial, rhyme (without tone) and tone
    tone = {'X': '上', 'H': '去'}.get(x[-1:], '')            # rising / departing; no letter = level or entering
    body = x[:-1] if tone else x
    if not tone: tone = '入' if body.endswith(('p', 't', 'k')) else '平'
    ini = next((i for i in INI if body.startswith(i)), '')
    return ini, body[len(ini):], tone
FAR = MC[MC.cat4 == 'other'].copy()
def both_differ(r):
    a, b = mc_split(r.mc_bs2014), mc_split(r.head_mc_bs2014)
    return int(a[0] != b[0] and a[1] != b[1])
FAR['ini_and_fin'] = FAR.apply(both_differ, axis=1)
a, n1, c, n0 = counts(FAR, 'ini_and_fin')
out.append(dict(section='remote pairs (descriptive)', comparison='MC initial and final both differ | pairs in the other-difference category',
                labelled_hits=a, labelled_n=n1, ordinary_hits=c, ordinary_n=n0, labelled_rate=round(a / n1, 3), ordinary_rate=round(c / n0, 3),
                fisher_p_two_sided='%.2g' % fisher_exact([[a, n1 - a], [c, n0 - c]])[1], note='descriptive; the rest differ in initial only or in final only (tone may also differ)'))
FAR_OC = FAR[FAR.morph_relation_auto.notna()].copy()
FAR_OC['oc_R'] = (FAR_OC.morph_relation_auto == 'R').astype(int)
a, n1, c, n0 = counts(FAR_OC, 'oc_R')
out.append(dict(section='remote pairs (descriptive)', comparison='OC relation R (affix or regular alternation only) | other-difference pairs with OC forms at both ends',
                labelled_hits=a, labelled_n=n1, ordinary_hits=c, ordinary_n=n0, labelled_rate=round(a / n1, 3), ordinary_rate=round(c / n0, 3),
                fisher_p_two_sided='%.2g' % fisher_exact([[a, n1 - a], [c, n0 - c]])[1], note='descriptive; OC categories as in the coding criteria (data dictionary)'))

# The first-sample coding table (shared by sections 10, 12 and 16)
fs = pd.read_csv(DATA / 'first_sample_codes.csv', encoding='utf-8-sig', dtype=str, keep_default_na=False)
S = fs.rename(columns={'member': 'char', 'blind_code': 'code'}).merge(d[['sw_id', 'group']].rename(columns={'group': 'group_d'}), on='sw_id', how='left')
S = S[(S.in_analysis_set == 'True') & (S.code != 'X')].copy()
S['label'] = (S.group_d == 'labelled').astype(int)
assert (int(S.label.sum()), int((S.label == 0).sum())) == (33, 50), (int(S.label.sum()), int((S.label == 0).sum()))
S['related'] = S.code.isin(['Y', 'E']).astype(int)
S = S.merge(MC[['sw_id', 'phonetic', 'cat4']], on=['sw_id', 'phonetic'], how='left')
SL = S[(S.label == 1) & (S.cat4 == 'other')]
out.append(dict(section='remote pairs (descriptive)', comparison='coded semantically related (Y or E) | labelled other-difference pairs in the blind-coded sample',
                labelled_hits=int(SL.related.sum()), labelled_n=len(SL), labelled_rate=round(SL.related.mean(), 3) if len(SL) else '', note='descriptive; chars: ' + ''.join(SL.char)))

# 11. Labels not filed under their own phonetic, by layer (MC identity); paronomastic glosses by layer (descriptive)
NF = MC[(MC.label == 1) & (MC.filed_under_phonetic != 'True') & MC.layer.isin(['both', 'daxu_only'])]
a, n1, c, n0 = int(NF[NF.layer == 'daxu_only'].identical.sum()), int((NF.layer == 'daxu_only').sum()), int(NF[NF.layer == 'both'].identical.sum()), int((NF.layer == 'both').sum())
out.append(dict(section='recension layers (descriptive)', comparison='MC identical among labels not filed under their phonetic: Da Xu-only (labelled columns) vs shared (ordinary columns)',
                labelled_hits=a, labelled_n=n1, ordinary_hits=c, ordinary_n=n0, labelled_rate=round(a / n1, 3), ordinary_rate=round(c / n0, 3),
                fisher_p_two_sided='%.2g' % fisher_exact([[a, n1 - a], [c, n0 - c]])[1], note='H3 without the filed-under labels (37 of the 40 are in the shared layer)'))
YE = A[A.label == 1].copy(); YE['layer'] = YE.sw_id.map(LAY); YE['par'] = (YE.paronomastic_gloss == 'True').astype(int)
a, n1, c, n0 = int(YE[YE.layer == 'daxu_only'].par.sum()), int((YE.layer == 'daxu_only').sum()), int(YE[YE.layer == 'both'].par.sum()), int((YE.layer == 'both').sum())
out.append(dict(section='recension layers (descriptive)', comparison='paronomastic gloss (gloss uses the phonetic) among labelled entries: Da Xu-only (labelled columns) vs shared (ordinary columns)',
                labelled_hits=a, labelled_n=n1, ordinary_hits=c, ordinary_n=n0, labelled_rate=round(a / n1, 3), ordinary_rate=round(c / n0, 3),
                fisher_p_two_sided='%.2g' % fisher_exact([[a, n1 - a], [c, n0 - c]])[1], note='entries, not pairs; all 202 labelled entries of the two layers'))

# 12. Within semantically related pairs: label and sound
R_ = S[(S.related == 1) & S.cat4.notna()].copy()
R_['near'] = R_.cat4.isin(['identical', 'alt_departing']).astype(int)
R_['ident'] = (R_.cat4 == 'identical').astype(int)
for y, lab in [('near', 'MC identical or departing-tone alternation'), ('ident', 'MC identical')]:
    a, n1, c, n0 = counts(R_, y)
    out.append(dict(section='related pairs only (descriptive)', comparison=f'{lab} | blind-coded pairs coded related (Y or E) with MC readings',
                    labelled_hits=a, labelled_n=n1, ordinary_hits=c, ordinary_n=n0, labelled_rate=round(a / n1, 3), ordinary_rate=round(c / n0, 3),
                    fisher_p_two_sided='%.2g' % fisher_exact([[a, n1 - a], [c, n0 - c]])[1], note='the comparison that would separate a meaning-first account from one in which the label also tracks sound; too few related ordinary pairs to decide'))
# 12b. Both groups pooled: share coded related in each MC category (descriptive; the premise of the meaning-first account)
S_ = S[S.cat4.notna()]
for k in ['identical', 'alt_departing', 'alt_other', 'other']:
    g = S_[S_.cat4 == k]
    out.append(dict(section='related pairs only (descriptive)', comparison=f'coded related (Y or E) | MC category {k}, labelled and ordinary pooled',
                    labelled_hits=int(g.related.sum()), labelled_n=len(g), labelled_rate=round(g.related.mean(), 3) if len(g) else '', note='descriptive; blind-coded sample'))
# 12c. Within each group: identical or departing-tone alternation among pairs coded related versus unrelated
for grp, glab in [(1, 'labelled pairs'), (0, 'ordinary pairs')]:
    g = S_[S_.label == grp].copy(); g['near'] = g.cat4.isin(['identical', 'alt_departing']).astype(int)
    r1, r0 = g[g.related == 1], g[g.related == 0]
    a, n1, c, n0 = int(r1.near.sum()), len(r1), int(r0.near.sum()), len(r0)
    out.append(dict(section='related pairs only (descriptive)', comparison=f'MC identical or departing-tone alternation within {glab}: coded related (labelled columns) vs coded unrelated (ordinary columns)',
                    labelled_hits=a, labelled_n=n1, ordinary_hits=c, ordinary_n=n0, labelled_rate=round(a / n1, 3), ordinary_rate=round(c / n0, 3),
                    fisher_p_two_sided='%.2g' % fisher_exact([[a, n1 - a], [c, n0 - c]])[1], note='columns reused: here "labelled" = related pairs and "ordinary" = unrelated pairs of the one group named'))

# 13. Duan notes: number of head entries containing each phrase (needs the open Shuowen data; otherwise the precomputed rows are used)
PRE = pd.read_csv(DATA / 'duan_notes_precomputed.csv', encoding='utf-8-sig', dtype=str, keep_default_na=False)
def precomputed(section):
    return [{k: v for k, v in r.items() if v != ''} for r in PRE[PRE.section == section].to_dict('records')]
DP = ['形聲包會意', '形聲中有會意', '形聲兼會意', '會意兼形聲', '會意包形聲']          # the five phrases searched for in the Duan notes
if swdir:
    dn, anyn, nfiles = {p_: 0 for p_ in DP}, 0, 0
    for f in sorted(glob.glob(swdir.rstrip('/') + '/*.json')):
        j = json.load(open(f, encoding='utf-8')); nfiles += 1
        t_ = json.dumps(j.get('duan_notes'), ensure_ascii=False)
        hit = False
        for p_ in DP:
            if p_ in t_: dn[p_] += 1; hit = True
        anyn += hit
    for p_ in DP:
        out.append(dict(section='Duan notes: head entries (descriptive)', comparison=f'head entries whose Duan notes contain {p_}', labelled_hits=dn[p_], labelled_n=nfiles, note='each head entry counted once'))
    out.append(dict(section='Duan notes: head entries (descriptive)', comparison='head entries whose Duan notes contain any of the five phrases', labelled_hits=anyn, labelled_n=nfiles, note='each head entry counted once'))
else:
    out.extend(precomputed('Duan notes: head entries (descriptive)'))

# 14. Combined checks
ALT['layer'] = ALT.sw_id.map(LAY)
WANG9 = set('貧愾恇娶婚姻婢緉坪')
FILTERS = [('paronomastic glosses removed', lambda x: x[x.paronomastic_gloss != 'True']),
           ('shared labels only', lambda x: x[(x.label == 0) | (x.layer == 'both')]),
           ('core: shared labels without paronomastic glosses', lambda x: x[(x.paronomastic_gloss != 'True') & ((x.label == 0) | (x.layer == 'both'))]),
           ("Wang Yun's nine rejected labels removed", lambda x: x[(x.label == 0) | ~x.char.isin(WANG9)]),
           ('labels filed under own phonetic removed', lambda x: x[(x.label == 0) | (x.filed_under_phonetic != 'True')])]
for fname, f in FILTERS:
    add('combined checks', f'H1a MC identical | {fname}', f(MC), 'identical', 'labelled entries dropped, all ordinary compounds kept')
    add('combined checks', f'departing-tone alternation | all MC pairs | {fname}', f(MC), 'alt_departing', 'labelled entries dropped, all ordinary compounds kept')
    add('combined checks', f'H1c member departing | tone/voicing alternation | {fname}', f(ALT), 'member_dep', 'labelled entries dropped, all ordinary compounds kept')
LL = MC[MC.label == 1].copy()
LL['par'] = np.where(LL.paronomastic_gloss == 'True', 'paronomastic', 'plain')
for (lay_, par_), g in LL.groupby(['layer', 'par']):
    for k in ['identical', 'alt_departing', 'alt_other', 'other']:
        out.append(dict(section='labelled pairs by layer and gloss type (descriptive)', comparison=f'MC category {k} | {lay_} layer, {par_} gloss',
                        labelled_hits=int(g[k].sum()), labelled_n=len(g), labelled_rate=round(g[k].mean(), 3), note='descriptive'))
core = (LL.layer == 'both') & (LL.paronomastic_gloss != 'True')
a, n1, c, n0 = int(LL[core].identical.sum()), int(core.sum()), int(LL[~core].identical.sum()), int((~core).sum())
out.append(dict(section='labelled pairs by layer and gloss type (descriptive)', comparison='MC identical: core labels (labelled columns) vs all other labels (ordinary columns)',
                labelled_hits=a, labelled_n=n1, ordinary_hits=c, ordinary_n=n0, labelled_rate=round(a / n1, 3), ordinary_rate=round(c / n0, 3),
                fisher_p_two_sided='%.2g' % fisher_exact([[a, n1 - a], [c, n0 - c]])[1], note='core = shared by both recensions and without a paronomastic gloss'))

# 5. Duan notes on meaningful phonetics (exploratory); the five phrases are searched in the notes of each ordinary compound
PATS = ['形聲包會意', '形聲中有會意', '會意包形聲', '會意兼形聲', '亦聲']
def duan_flag(sw):
    try: j = json.load(open(swdir.rstrip('/') + f'/{sw}.json', encoding='utf-8'))
    except FileNotFoundError: return False
    t = ' '.join(n.get('note', '') for n in j.get('duan_notes', []))
    return any(p in t for p in PATS)
if swdir:
    OM = MC[MC.label == 0].copy(); OM['duan_flag'] = OM.sw_id.map(duan_flag)
    fl = OM[OM.duan_flag]; nf = OM[~OM.duan_flag]; lab = MC[MC.label == 1]
    fi, nfi, li = int(fl.identical.sum()), int(nf.identical.sum()), int(lab.identical.sum())
    p1 = fisher_exact([[fi, len(fl) - fi], [nfi, len(nf) - nfi]])[1]
    p2 = fisher_exact([[li, len(lab) - li], [fi, len(fl) - fi]])[1]
    out.append(dict(section='Duan notes (exploratory)', comparison='MC identical: ordinary compounds with a Duan meaningful-phonetic note (labelled columns) vs other ordinary compounds (ordinary columns)',
                    labelled_hits=fi, labelled_n=len(fl), ordinary_hits=nfi, ordinary_n=len(nf), labelled_rate=round(fi / len(fl), 3), ordinary_rate=round(nfi / len(nf), 3),
                    fisher_p_two_sided='%.2g' % p1, note='notes matched: ' + '/'.join(PATS) + '; flagged chars: ' + ''.join(fl.char)))
    out.append(dict(section='Duan notes (exploratory)', comparison='MC identical: labelled (labelled columns) vs Duan-noted ordinary compounds (ordinary columns)',
                    labelled_hits=li, labelled_n=len(lab), ordinary_hits=fi, ordinary_n=len(fl), labelled_rate=round(li / len(lab), 3), ordinary_rate=round(fi / len(fl), 3),
                    fisher_p_two_sided='%.2g' % p2, note='descriptive; 21 or so items only'))
    fa = int(fl.alt_departing.sum()); nfa = int(nf.alt_departing.sum())
    out.append(dict(section='Duan notes (exploratory)', comparison='MC departing-tone alternation: Duan-noted ordinary (labelled columns) vs other ordinary (ordinary columns)',
                    labelled_hits=fa, labelled_n=len(fl), ordinary_hits=nfa, ordinary_n=len(nf), labelled_rate=round(fa / len(fl), 3), ordinary_rate=round(nfa / len(nf), 3),
                    fisher_p_two_sided='%.2g' % fisher_exact([[fa, len(fl) - fa], [nfa, len(nf) - nfa]])[1], note='descriptive'))
else:
    out.extend(precomputed('Duan notes (exploratory)'))

# 15. H4 and the Duan layer: two-sided Fisher p (the counts equal those of the H4 and H3 rows of yisheng_summary.csv, which gives one-sided p only)
LB = MC[MC.label == 1]
for g1, g0, lab_, note_ in [(LB[LB.filed_under_phonetic == 'True'], LB[LB.filed_under_phonetic != 'True'],
                             'labels filed under their own phonetic (labelled columns) vs other labels (ordinary columns)', 'H4; yisheng_summary.csv gives one-sided p = 0.15 for the same counts'),
                            (LB[LB.duan_label == '無'], LB[LB.duan_label == '亦聲'],           # '無' = Duan drops the label, '亦聲' = Duan keeps it
                             'labels Duan drops (labelled columns) vs labels Duan keeps (ordinary columns)', 'H3, Duan layer; entries without Duan text in the data left out')]:
    a, n1, c, n0 = int(g1.identical.sum()), len(g1), int(g0.identical.sum()), len(g0)
    out.append(dict(section='exploratory comparisons (two-sided)', comparison=f'MC identical: {lab_}',
                    labelled_hits=a, labelled_n=n1, ordinary_hits=c, ordinary_n=n0, labelled_rate=round(a / n1, 3), ordinary_rate=round(c / n0, 3),
                    fisher_p_two_sided='%.2g' % fisher_exact([[a, n1 - a], [c, n0 - c]])[1], note=note_))

# 16. The sampling frame of the first blind sample: the comparison frame holds only the 172 phonetics that still have a labelled member (yph);
#     4 ordinary pairs are under phonetics whose only labelled member is a xinfu entry
g83 = gee(S, 'related')
assert round(g83[0], 1) == 22.0, g83          # the same as the H2 result of the main analysis
FR, OUTSIDE = S[S.phonetic.isin(yph)].copy(), S[~S.phonetic.isin(yph)]
a, n1, c, n0 = counts(FR, 'related'); g = gee(FR, 'related')
out.append(dict(section='blind sample frame', comparison='H2 related (Y or E) | ordinary pairs outside the 172-phonetic comparison frame removed',
                labelled_hits=a, labelled_n=n1, ordinary_hits=c, ordinary_n=n0, labelled_rate=round(a / n1, 3), ordinary_rate=round(c / n0, 3),
                gee_OR=round(g[0], 2), gee_CI95=f'{g[1]:.2f}-{g[2]:.2f}', gee_p_two_sided='%.2g' % g[3],
                fisher_p_two_sided='%.2g' % fisher_exact([[a, n1 - a], [c, n0 - c]])[1],
                note='removed: %d ordinary pairs (%s), all coded unrelated; all 83 pairs give GEE OR %.1f' % (len(OUTSIDE), '、'.join(OUTSIDE.phonetic + ':' + OUTSIDE.char), g83[0])))
FM = FR[FR.cat4.notna()].copy()
FM['ident'] = (FM.cat4 == 'identical').astype(int); FM['near'] = FM.cat4.isin(['identical', 'alt_departing']).astype(int)
for y, ylab in [('ident', 'MC identical'), ('near', 'MC identical or departing-tone alternation')]:
    lg = smf.logit(f'{y} ~ label + related', data=FM).fit(disp=0)
    for term, tlab in [('related', 'coded related'), ('label', 'label')]:
        b, (lo, hi) = lg.params[term], lg.conf_int().loc[term]
        out.append(dict(section='blind sample frame', comparison=f'descriptive logit on the {len(FM)} in-frame pairs: {ylab} ~ label + related | coefficient of {tlab}',
                        gee_OR=round(math.exp(b), 2), gee_CI95=f'{math.exp(lo):.2f}-{math.exp(hi):.2f}', gee_p_two_sided='%.2g' % lg.pvalues[term],
                        note='ordinary logistic regression, not GEE (columns gee_* hold its OR, Wald CI and p); same model as in first_sample_checks.py on its 83 pairs'))

cols = ['section', 'comparison', 'labelled_hits', 'labelled_n', 'labelled_rate', 'ordinary_hits', 'ordinary_n', 'ordinary_rate', 'gee_OR', 'gee_CI95', 'gee_p_two_sided',
        'mh_strata', 'mh_labelled_n', 'mh_ordinary_n', 'mh_OR', 'mh_CI95', 'cmh_p_two_sided', 'fisher_p_two_sided', 'note']
with open(OUT / 'yisheng_models_extra_checks.csv', 'w', newline='', encoding='utf-8-sig') as f:
    w = csv.DictWriter(f, fieldnames=cols, lineterminator='\n'); w.writeheader()
    for r in out: w.writerow({k: r.get(k, '') for k in cols})
for r in out:
    print(r['section'], '|', r['comparison'], '|', f"{r.get('labelled_hits', '')}/{r.get('labelled_n', '')} vs {r.get('ordinary_hits', '')}/{r.get('ordinary_n', '')}",
          '| GEE', r.get('gee_OR', ''), r.get('gee_CI95', ''), r.get('gee_p_two_sided', ''), '| MH', r.get('mh_strata', ''), r.get('mh_OR', ''), r.get('mh_CI95', ''), r.get('cmh_p_two_sided', ''),
          '| Fisher', r.get('fisher_p_two_sided', ''))
