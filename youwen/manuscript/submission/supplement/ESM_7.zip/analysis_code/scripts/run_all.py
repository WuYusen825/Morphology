# Runs every analysis script in dependency order, then (unless --no-check) the self-check.
# Usage (from the folder that contains README.txt):
#   python scripts/run_all.py                      # all scripts, then the self-check
#   python scripts/run_all.py --shuowen DIR        # also recompute the Duan-note counts from the open Shuowen JSON data in DIR (optional)
#   python scripts/run_all.py --no-figure          # skip Fig. 1 (needs matplotlib)
#   python scripts/run_all.py --no-check           # skip the self-check
# The scripts write to output/. Compare with expected/ (the self-check does this).
import subprocess, sys, time
from pathlib import Path

HERE = Path(__file__).resolve().parent
args = sys.argv[1:]
shuowen = args[args.index('--shuowen') + 1] if '--shuowen' in args else None
STEPS = [
    ('ext_sample.py', [], 'sampling of the enlarged blind coding (reproduces the item key and the 14 prompts)'),
    ('ext_analysis.py', [], 'enlarged blind coding: the two passes, kappa, the primary test and the secondary and exploratory tests'),
    ('ext_author_check.py', [], "the authors' check of 126 items and the sensitivity analysis with their codes"),
    ('ext_bias_sensitivity.py', [], 'bias sensitivity (tipping-point) analysis'),
    ('ext_second_answer_sensitivity.py', [], 'sensitivity analysis X5: second answers of two batches'),
    ('ext_bias_reverse_scenario.py', [], 'reverse-direction bias scenario S3'),
    ('core_models.py', [], 'core comparison of labelled and ordinary compounds: counts, Fisher tests, GEE and mixed models'),
    ('paper_checks.py', [shuowen] if shuowen else [], 'additional analyses of the paper (profiles, within-phonetic estimates, layers, combined checks)'),
    ('first_sample_checks.py', [], 'first-sample checks: agreement of the two codings and H2 on the 100 items'),
    ('sensitivity_wang_yun.py', [], "sensitivity analysis without Wang Yun's rejected labels"),
    ('sensitivity_xiao_xu.py', [], 'recension layers and the shared-labels sensitivity analysis'),
    ('paper_counts.py', [], 'counts quoted in the paper and Table 5'),
]
if '--no-figure' not in args:
    STEPS.append(('paper_figure.py', [], 'Fig. 1 (needs matplotlib)'))
for name, extra, what in STEPS:
    t0 = time.time()
    print(f'== {name}: {what}', flush=True)
    r = subprocess.run([sys.executable, str(HERE / name)] + extra, cwd=HERE.parent, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, text=True)
    if r.returncode != 0:
        print(r.stderr[-3000:]); sys.exit(f'{name} failed')
    print(f'   done in {time.time() - t0:.0f} s', flush=True)
if '--no-check' not in args:
    r = subprocess.run([sys.executable, str(HERE / 'self_check.py')] + (['--no-figure'] if '--no-figure' in args else []), cwd=HERE.parent)
    sys.exit(r.returncode)
