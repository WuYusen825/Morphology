# Enlarged blind semantic coding (bias sensitivity, tipping-point analysis). Exploratory, added after the results were seen; not part of the decision rule.
# Question: if (A) "meaning first" is true (the label is determined by true relatedness only, and given true relatedness the label is unrelated to sound),
#   how large would the share of truly unrelated pairs coded "related" have to be to create the observed sound difference among the pairs coded related
#   (P1: 73/141 vs 23/79)? The answer is then compared with the coding disagreements actually observed (between the two passes; between pass 1 and the authors' consolidated judgment).
# Usage: python scripts/ext_bias_sensitivity.py      (run scripts/ext_analysis.py first)
# Reads:  output/ext_codes_long.csv, data/author_check.csv, output/ext_check_key.csv, output/yisheng_models_ext_coding.csv
# Writes: output/ext_bias_sensitivity_output.txt, output/yisheng_bias_sensitivity_grid.csv
# Uses only the existing codes (no new machine coding).
#
# Model (stated first):
#   R* = true relatedness (unobservable), R = coded related (Y/E) in pass 1, L = labelled, N = near (MC identical or departing-tone alternation).
#   (A): L is determined by R* alone, i.e. given R*, N is independent of L; so among truly related pairs the near share is the same in the labelled and ordinary groups (true OR = 1).
#   Coding error: given R* and L, R is independent of N (the coders do not see the readings, so their error is unrelated to sound); the error may differ by group;
#     the false-positive rates fp_L, fp_O are the shares of truly unrelated pairs coded related (labelled group, ordinary group); the sensitivities se_L, se_O are arbitrary.
#   Under these assumptions the near share among truly related pairs can be recovered from the observed 2x2x2 table:
#     A*_{l,n} = (a_{l,n} - fp_l * T_{l,n}) / (se_l - fp_l), a = number coded related, T = total of the cell;
#     the corrected odds ratio of being near, labelled vs ordinary, among truly related pairs is OR* = (A*_{L,1}/A*_{L,0}) / (A*_{O,1}/A*_{O,0}); se_l cancels in the ratio, so OR* depends on fp_L and fp_O only.
#   OR* is a pooled (unweighted) odds ratio, observed 2.61; the GEE primary test (clustered by phonetic, exchangeable) is 2.35; the two differ only in weighting.
#   Intervals: bootstrap resampling whole phonetics (5,000 resamples, seed 20260936); they do not include the uncertainty of fp itself unless stated.
import csv
import numpy as np, pandas as pd
from scipy.stats import fisher_exact
from _paths import DATA, OUT

B, SEED = 5000, 20260936
YE = ('Y', 'E')
rng = np.random.default_rng(SEED)
lines = []
def out(s=''): lines.append(s)

# ---------- Data: the same sample as the primary test of ext_analysis.py (in the frame, MC readings, pass-1 code not X) ----------
C = pd.read_csv(OUT / 'ext_codes_long.csv', encoding='utf-8-sig', dtype=str)
for c in ['label', 'near']: C[c] = C[c].astype(int)
C['cat4'] = C.cat4.replace('nan', np.nan)
P = C[C.cat4.notna() & (C.code1 != 'X')].copy()
assert len(P) == 634 and int(P.label.sum()) == 172
P['R1'] = P.code1.isin(YE).astype(int)
phon = sorted(P.phonetic.unique()); pix = {p: i for i, p in enumerate(phon)}
cnt = np.zeros((len(phon), 2, 2, 2), dtype=np.int64)          # [phonetic, labelled, near, coded related]
for r in P.itertuples(): cnt[pix[r.phonetic], r.label, r.near, r.R1] += 1
tot = cnt.sum(0)
assert tot[1, 1, 1] == 73 and tot[1, 0, 1] == 68 and tot[0, 1, 1] == 23 and tot[0, 0, 1] == 56   # P1: 73/141 vs 23/79

def orstar(c, fpL, fpO):
    """c[..., labelled, near, coded related]; returns the corrected odds ratio of being near among truly related pairs.
    If a cell is "used up" by too large a false-positive rate, the limit is returned."""
    gL, gO = fpL / (1 - fpL), fpO / (1 - fpO)
    aL1 = c[..., 1, 1, 1] - gL * c[..., 1, 1, 0]; aL0 = c[..., 1, 0, 1] - gL * c[..., 1, 0, 0]
    aO1 = c[..., 0, 1, 1] - gO * c[..., 0, 1, 0]; aO0 = c[..., 0, 0, 1] - gO * c[..., 0, 0, 0]
    with np.errstate(all='ignore'):
        res = (aL1 * aO0) / (aL0 * aO1)
    ok = (aL1 > 0) & (aL0 > 0) & (aO1 > 0) & (aO0 > 0)
    res = np.where(ok, res, np.nan)
    res = np.where((aL1 > 0) & (aL0 > 0) & (aO0 <= 0) & (aO1 > 0), 0.0, res)       # the ordinary non-near related pairs are all "used up": OR* tends to 0
    res = np.where((aL1 > 0) & (aL0 > 0) & (aO1 <= 0) & (aO0 > 0), np.inf, res)    # the near related pairs are used up: OR* tends to infinity
    return res
def fp_max(c=tot):   # the largest false-positive rate at which the ordinary non-near related pairs are not reduced below zero
    g = c[0, 0, 1] / c[0, 0, 0]; return g / (1 + g)
def fp_max_L(c=tot):  # the same for the labelled group
    g = c[1, 0, 1] / c[1, 0, 0]; return g / (1 + g)
def solve(fn, target, hi):
    """fn decreases monotonically in fp_O; find fp_O with fn(fp_O) = target; returns 0.0 if fn(0) is already not above the target, None if fn is still above it at the upper limit."""
    if not fn(0.0) > target: return 0.0
    if fn(hi) > target: return None
    lo = 0.0
    for _ in range(80):
        mid = (lo + hi) / 2
        if fn(mid) > target: lo = mid
        else: hi = mid
    return (lo + hi) / 2

# Self-test: check the correction formula on tables with known true values (true OR 1 and 2; errors differ by group)
def _selftest(tL1, tL0):
    uL1, uL0, uO1, uO0, tO1, tO0 = 30., 70., 70., 310., 10., 10.
    fpL, fpO, seL, seO = 0.05, 0.11, 0.8, 0.9
    c = np.zeros((2, 2, 2))
    for l, n, tr, un, se, fp in [(1, 1, tL1, uL1, seL, fpL), (1, 0, tL0, uL0, seL, fpL), (0, 1, tO1, uO1, seO, fpO), (0, 0, tO0, uO0, seO, fpO)]:
        a = se * tr + fp * un; c[l, n, 1] = a; c[l, n, 0] = tr + un - a
    return float(orstar(c, fpL, fpO))
assert abs(_selftest(50., 50.) - 1.0) < 1e-9 and abs(_selftest(100., 50.) - 2.0) < 1e-9

# Bootstrap: resample whole phonetics
ix = rng.integers(0, len(phon), (B, len(phon)))
boot = cnt[ix].sum(1)
def boot_q(fpL, fpO):
    v = orstar(boot, fpL, fpO); v = v[~np.isnan(v)]
    return np.percentile(v, 2.5), np.percentile(v, 97.5), len(v)
def boot_lo(fpL, fpO): return boot_q(fpL, fpO)[0]
def ci(v):
    v = np.asarray(v, dtype=float); v = v[~np.isnan(v)]
    return np.percentile(v, 2.5), np.percentile(v, 97.5)
def pct(x): return f'{x:.1%}'

REF = pd.read_csv(OUT / 'yisheng_models_ext_coding.csv', encoding='utf-8-sig', dtype=str).fillna('')
def ref_row(prefix):
    m = REF[REF.test.str.startswith(prefix + ' ')]; assert len(m) == 1, prefix
    return m.iloc[0]
def ref_or(prefix):
    m = ref_row(prefix); return f"{m.gee_OR} [{m.gee_CI95.replace('-', ', ')}]"
assert ref_row('P1').gee_OR == '2.35'

# ---------- 1. The observed table ----------
out('Bias sensitivity (tipping-point) analysis (exploratory; uses the existing pass-1 codes, no new coding)')
out('For the model and its assumptions see the head of ext_bias_sensitivity.py. In short: if (A) is true the true OR is 1; coding error is unrelated to sound but may differ between labelled and ordinary pairs.')
out('')
out('1. The observed table (primary-test sample: in the frame, with MC readings, pass-1 code not X; 634 pairs; the same as P1)')
out(f'  Coded related: labelled near {tot[1,1,1]}, not near {tot[1,0,1]}; ordinary near {tot[0,1,1]}, not near {tot[0,0,1]}')
out(f'  Coded unrelated: labelled near {tot[1,1,0]}, not near {tot[1,0,0]}; ordinary near {tot[0,1,0]}, not near {tot[0,0,0]}')
crude = (tot[1, 1, 1] / tot[1, 0, 1]) / (tot[0, 1, 1] / tot[0, 0, 1])
nU_O, nU_L, nR_O = int(tot[0, :, 0].sum()), int(tot[1, :, 0].sum()), int(tot[0, :, 1].sum())
out(f'  Pooled odds ratio {crude:.2f} (GEE primary test {ref_or("P1")}; the two differ only in weighting)')
out(f'  Near share among pairs coded related: labelled {tot[1,1,1]}/{tot[1,:,1].sum()} = {tot[1,1,1]/tot[1,:,1].sum():.0%}, ordinary {tot[0,1,1]}/{nR_O} = {tot[0,1,1]/nR_O:.0%}.')
out(f'  Pairs coded unrelated: {nU_O} ordinary pairs against only {nU_L} labelled pairs, {nU_O/nU_L:.0f} times as many: far more truly unrelated ordinary pairs are available to be miscoded as "related".')
out('')

# ---------- 2. Tipping points ----------
out('2. Tipping points: the false-positive rate fp_O in the ordinary group (false positive = truly unrelated but coded related) needed to bring the corrected OR* down to the target; fp_L (labelled group) takes the values below')
hi_ = fp_max() * (1 - 1e-9)
out(f'  Upper limit of the ordinary-group false-positive rate (above it the {tot[0,0,1]} ordinary pairs coded related and not near would not suffice to be subtracted): {pct(fp_max())}')
out('  target | fp_L | fp_O needed | ordinary related pairs subtracted, as a share of the ordinary pairs coded related | true related ordinary pairs left')
rows_tip, xtip = [], {}
for target in [2.0, 1.5, 1.0, 'lower']:
    for fpL in [0.0, 0.05, 0.10, 0.20, 0.30]:
        if target == 'lower':
            fn = lambda x, fpL=fpL: boot_lo(fpL, x); tv, tag = 1.0, 'lower 95% bootstrap limit of OR* = 1'
        else:
            fn = lambda x, fpL=fpL: orstar(tot, fpL, x); tv, tag = target, f'OR* = {target:g}'
        x = solve(fn, tv, hi_)
        if x is None:
            out(f'  {tag} | {fpL:.0%} | impossible'); continue
        g = x / (1 - x); fpos = g * nU_O; xtip[(target, fpL)] = (x, fpos)
        out(f'  {tag} | {fpL:.0%} | {pct(x)} | {fpos:.0f}/{nR_O} = {fpos/nR_O:.0%} | {nR_O-fpos:.0f}')
        rows_tip.append(dict(kind='tipping', target=('lower95=1' if target == 'lower' else target), fp_L=fpL, fp_O_required=round(x, 4),
                             false_pos_share_of_coded_related_ordinary=round(fpos / nR_O, 3)))
# False-positive rate equal in the two groups
xnd = solve(lambda x: orstar(tot, x, x), 1.0, hi_)
xndl = solve(lambda x: boot_lo(x, x), 1.0, hi_)
gnd = xnd / (1 - xnd)
out(f'  Equal false-positive rates (fp_L = fp_O): OR* = 1 needs {pct(xnd)}; bringing the lower limit of the bootstrap 95% interval down to 1 needs {pct(xndl)}')
out(f'    Then only about {gnd*nU_L:.0f}/{tot[1,:,1].sum()} labelled pairs coded related are false positives ({gnd*nU_L/tot[1,:,1].sum():.0%}), against about {gnd*nU_O:.0f}/{nR_O} ordinary pairs ({gnd*nU_O/nR_O:.0%}).')
xg = solve(lambda x: orstar(tot, 0.0, x), crude / 2.35, hi_)
xgn = solve(lambda x: orstar(tot, x, x), crude / 2.35, hi_)
out(f'  On the GEE scale (matching the pooled {crude:.2f} to 2.35, target OR* = {crude:.2f}/2.35 = {crude/2.35:.3f}): with fp_L = 0, fp_O = {pct(xg)}; with fp_L = fp_O, {pct(xgn)} (against {pct(solve(lambda x: orstar(tot, 0.0, x), 1.0, hi_))} and {pct(xnd)} on the pooled scale: less than one percentage point apart)')
out('')
out(f'  How to read this: what is needed is not a difference between the false-positive rates of the two groups. Equal rates (about {pct(xnd)}) suffice, because there are many truly unrelated pairs in the ordinary group ({nU_O} pairs, against {nU_L} labelled),')
out(f'  so that with the same rate the share of false positives among the pairs coded related is much higher in the ordinary group (about {gnd*nU_O/nR_O:.0%}) than in the labelled group (about {gnd*nU_L/tot[1,:,1].sum():.0%}). Put differently: if (A) is true, the near share among truly related ordinary pairs')
out(f'  should equal that of the labelled group ({tot[1,1,1]}/{tot[1,0,1]} = {tot[1,1,1]/tot[1,0,1]:.2f} to 1), whereas {tot[0,1,1]}/{tot[0,0,1]} = {tot[0,1,1]/tot[0,0,1]:.2f} is observed; to raise {tot[0,1,1]}/{tot[0,0,1]} to {tot[1,1,1]/tot[1,0,1]:.2f},')
out(f'  about {xtip[(1.0, 0.0)][1]:.0f} of the {nR_O} ordinary pairs coded related would have to be false positives (false positives do not choose by sound and fall mainly among the majority of non-near pairs).')
out('  OR* falls with fp_O, ever more steeply (fp_L = 0; fp_O -> OR*): ' + '; '.join(f'{pct(x)} -> {float(orstar(tot, 0.0, x)):.2f}' for x in [0.0, 0.025, 0.05, 0.075, 0.10, 0.115]))
out('')

# ---------- 3. Comparison with the coding disagreements actually observed ----------
out('3. Comparison: the coding disagreements actually observed (all are disagreements between coders, not judgments relative to Xu Shen; see the limitations at the end)')
# (a) pass 1 vs pass 2: new items in the frame that are not X in either pass
Nn = P[(P.source == 'extended') & (P.code2 != 'X')].copy(); Nn['R2'] = Nn.code2.isin(YE).astype(int)
def two_pass(df):
    d = np.zeros((len(phon), 2, 6), dtype=np.int64)
    for r in df.itertuples():
        i = pix[r.phonetic]
        d[i, r.label, 0] += (r.R2 == 0); d[i, r.label, 1] += (r.R1 == 1 and r.R2 == 0); d[i, r.label, 2] += (r.R1 == 1)
        d[i, r.label, 3] += (r.R1 == 0); d[i, r.label, 4] += (r.R2 == 1 and r.R1 == 0); d[i, r.label, 5] += (r.R2 == 1)
    return d
d2 = two_pass(Nn); d2t = d2.sum(0); d2b = d2[ix].sum(1)
two = {}
for l, nm in [(0, 'ordinary'), (1, 'labelled')]:
    nl = int((Nn.label == l).sum())
    fpv = d2t[l, 1] / d2t[l, 0]; sh = d2t[l, 1] / d2t[l, 2]
    fpr = d2t[l, 4] / d2t[l, 3]
    with np.errstate(all='ignore'):
        cfp = ci(d2b[:, l, 1] / d2b[:, l, 0]); csh = ci(d2b[:, l, 1] / d2b[:, l, 2]); cfpr = ci(d2b[:, l, 4] / d2b[:, l, 3])
    two[l] = dict(fp=fpv, fpr=fpr, sh=sh)
    out(f'  Pass 1 vs pass 2 ({nm} pairs, the {nl} new items in the frame that are not X in pass 2):')
    out(f'    With pass 2 as reference: of the {d2t[l,0]} pairs coded unrelated in pass 2, {d2t[l,1]} were coded related in pass 1, a false-positive rate of {pct(fpv)} [{pct(cfp[0])}, {pct(cfp[1])}]; of the {d2t[l,2]} pairs coded related in pass 1, {sh:.0%} [{csh[0]:.0%}, {csh[1]:.0%}] are not confirmed by pass 2')
    out(f'    With pass 1 as reference: of the {d2t[l,3]} pairs coded unrelated in pass 1, {d2t[l,4]} were coded related in pass 2, a false-positive rate of {pct(fpr)} [{pct(cfpr[0])}, {pct(cfpr[1])}]')
out('  (The disagreement between the two passes is roughly the sum of each pass\'s own random errors, so the random false-positive rate of a single pass is about half the figures above; systematic errors, where both passes make the same mistake, cannot be seen.)')
# (b) pass 1 vs the authors' consolidated judgment: stratified estimate
Ad = pd.read_csv(DATA / 'author_check.csv', encoding='utf-8-sig', dtype=str)
Ad = Ad.rename(columns={'check_type': 'why', 'phonetic': 'phon', 'phonetic_gloss': 'pg', 'member': 'char', 'member_gloss': 'mg',
                        'author_code': 'author', 'pass1_code': 'p1s', 'pass2_code': 'p2s'})
K = pd.read_csv(OUT / 'ext_check_key.csv', encoding='utf-8-sig', dtype=str)
M0 = Ad.merge(K, on='check_id', suffixes=('', '_k')); assert len(M0) == 126
M0['dis'] = (M0.why_k == 'passes_disagree')
fr = P.set_index('sw_id')
M = M0[M0.sw_id.isin(fr.index) & (M0.author != 'X')].copy()
M['label'] = fr.label.loc[M.sw_id].values; M['near'] = fr.near.loc[M.sw_id].values
M['R1'] = fr.R1.loc[M.sw_id].values; M['Ra'] = M.author.isin(YE).astype(int)
M['w'] = np.where(M.dis, 1.0, 601 / 50)
out(f'  Of the items in the authors\' check, {len(M)} are in the frame and not X for the authors (disagreement stratum {int(M.dis.sum())}, random stratum {int((~M.dis).sum())}; each random item stands for 601/50 = 12.02 items).')
for l, nm in [(0, 'ordinary'), (1, 'labelled')]:
    s = M[(M.label == l) & (M.R1 == 1)]
    out(f'    Checked {nm} pairs coded related in pass 1: random stratum {int((~s.dis).sum())} (judged unrelated by the authors: {int(((~s.dis) & (s.Ra == 0)).sum())}), disagreement stratum {int(s.dis.sum())} (judged unrelated by the authors: {int((s.dis & (s.Ra == 0)).sum())})')
ml, mn, m1, ma, mw = (M[c].values for c in ['label', 'near', 'R1', 'Ra', 'w'])
idd, idr = np.where(M.dis.values)[0], np.where(~M.dis.values)[0]
A_orig = np.zeros((2, 2))                                      # the original 100 items (also coded by the authors): pairs in the frame coded related in pass 1
for r in P[P.source == 'original_100'].itertuples():
    if r.R1 == 1: A_orig[r.label, r.near] += 1
def stats(ii):
    l, n, r1, ra, w = ml[ii], mn[ii], m1[ii], ma[ii], mw[ii]
    res = {}
    for g in (0, 1):
        s = l == g
        neg = w[s & (ra == 0)].sum(); pos = w[s & (r1 == 1)].sum(); fa = w[s & (r1 == 1) & (ra == 0)].sum()
        res[g] = (fa / neg if neg > 0 else np.nan, fa / pos if pos > 0 else np.nan)
    A = A_orig.copy()
    for g in (0, 1):
        for k in (0, 1): A[g, k] += w[(l == g) & (n == k) & (ra == 1)].sum()
    orw = (A[1, 1] * A[0, 0]) / (A[1, 0] * A[0, 1]) if min(A[1, 0], A[0, 1]) > 0 else np.nan
    return res, orw, A
ast, orw0, Aw = stats(np.arange(len(M)))
fpO_b, fsO_b, fsL_b, orw_b = [], [], [], []
for _ in range(B):
    ii = np.concatenate([idd[rng.integers(0, len(idd), len(idd))], idr[rng.integers(0, len(idr), len(idr))]])
    r, o, _A = stats(ii)
    fpO_b.append(r[0][0]); fsO_b.append(r[0][1]); fsL_b.append(r[1][1]); orw_b.append(o)
fpO_b = np.array(fpO_b)
cfpO, cfsO, cfsL, corw = ci(fpO_b), ci(fsO_b), ci(fsL_b), ci(orw_b)
out(f'  Pass 1 vs the authors (ordinary pairs): of the pairs the authors judged unrelated, the share coded related in pass 1 (false-positive rate) is {pct(ast[0][0])} [{pct(cfpO[0])}, {pct(cfpO[1])}]; '
    f'of the pairs coded related in pass 1, the share the authors judged unrelated is {ast[0][1]:.0%} [{cfsO[0]:.0%}, {cfsO[1]:.0%}]')
out(f'  Pass 1 vs the authors (labelled pairs): of the pairs coded related in pass 1, the share the authors judged unrelated is {ast[1][1]:.0%} [{cfsL[0]:.0%}, {cfsL[1]:.0%}]; '
    f'the false-positive rate of the labelled group ({pct(ast[1][0])}) is not usable: very few labelled pairs were judged unrelated by the authors, almost all of them among those coded related in pass 1, so the estimate lies outside the feasible range of the model (fp_L < {fp_max_L():.0%}).')
# Ordinary related pairs that were not checked
chk = set(M0.sw_id)
unc = P[(P.source == 'extended') & (P.label == 0) & (P.R1 == 1) & ~P.sw_id.isin(chk)]
n_o_o = int(((P.source == 'original_100') & (P.label == 0) & (P.R1 == 1)).sum())
n_o_e = int(((P.source == 'extended') & (P.label == 0) & (P.R1 == 1)).sum())
n_o_c = int(((P.source == 'extended') & (P.label == 0) & (P.R1 == 1) & P.sw_id.isin(chk)).sum())
out(f'  Of the {nR_O} ordinary pairs coded related in pass 1, {n_o_o} belong to the original 100 items (coded by the authors themselves); of the {n_o_e} new items, {n_o_c} were checked (including those the authors judged X), and {len(unc)} have no author judgment.')
out('')
out(f'  Estimates of the ordinary-group false-positive rate under each reference (compare the tipping point of section 2: OR* = 1 needs fp_O {pct(xtip[(1.0, 0.0)][0])}, i.e. {xtip[(1.0, 0.0)][1]:.0f}/{nR_O} = {xtip[(1.0, 0.0)][1]/nR_O:.0%} of the ordinary related pairs would be false positives):')
g4 = two[0]['fp'] / (1 - two[0]['fp']); ga = ast[0][0] / (1 - ast[0][0])
out(f'    The two passes (pass 2 as reference): fp_O {pct(two[0]["fp"])}, equivalent to {g4*nU_O:.0f}/{nR_O} = {g4*nU_O/nR_O:.0%} of the ordinary related pairs being false positives')
out(f'    The authors\' consolidated judgment: fp_O {pct(ast[0][0])}, equivalent to {ga*nU_O:.0f}/{nR_O} = {ga*nU_O/nR_O:.0%}; counted directly, the share of the ordinary pairs coded related in pass 1 that the authors judged unrelated is {ast[0][1]:.0%} (about {int(round(ast[0][1]*nR_O))}/{nR_O})')
out('')

# ---------- 4. The corrected OR* at the false-positive rates actually observed ----------
out('4. The corrected OR* at the false-positive rates actually observed (labelled-group rate 0, or equal to the ordinary-group rate; the intervals include the resampling of phonetics and of the reference sample)')
def corrected(fps, fpb, same):
    o = float(orstar(tot, fps if same else 0.0, fps))
    vals = np.array([float(orstar(boot[b], (fpb[b] if same else 0.0), fpb[b])) for b in range(B) if not np.isnan(fpb[b])])
    vals = vals[~np.isnan(vals)]
    return o, np.percentile(vals, 2.5), np.percentile(vals, 97.5)
fp2s = two[0]['fp']; fp2b = d2b[:, 0, 1] / d2b[:, 0, 0]
corr = {}
for key, nm, fps, fpb in [('two', 'The two passes (pass 2 as reference)', fp2s, fp2b), ('auth', 'The authors\' consolidated judgment', ast[0][0], fpO_b)]:
    for same, tag in [(False, 'ordinary group only corrected (fp_L = 0)'), (True, 'equal rates in the two groups')]:
        o, lo_, hi_b = corrected(fps, fpb, same); corr[(key, same)] = (o, lo_, hi_b)
        out(f'  {nm}, fp_O = {pct(fps)}, {tag}: OR* = {o:.2f}, 95% interval [{lo_:.2f}, {hi_b:.2f}]')
out(f'  (A lower limit of 0 means that in that resample the false-positive rate exceeded the upper limit of about {pct(fp_max())}, the ordinary pairs coded related and not near were all subtracted, and OR* tends to 0.)')
out(f'  An alternative estimate that does not use the false-positive model (direct recoding): the checked items stand for the whole new-item frame with their design weights, the original 100 items keep their codes, and relatedness is taken from the authors\' judgment: pooled OR = {orw0:.2f}, 95% interval [{corw[0]:.2f}, {corw[1]:.2f}].')
out(f'    Weighted number of pairs the authors judged related: labelled near {Aw[1,1]:.0f}, not near {Aw[1,0]:.0f}; ordinary near {Aw[0,1]:.0f}, not near {Aw[0,0]:.0f}. The ordinary near cell has only {Aw[0,1]:.0f} weighted pairs, and the random stratum contains only 1 ordinary near pair coded related in pass 1 (each standing for 12), so this estimate is very unstable and goes in the opposite direction to the false-positive correction above; neither can count as evidence.')
out('    The unweighted replacement of the checked items alone is reported in yisheng_models_ext_author_check.csv (P1, author_adjudicated).')
out('')

# ---------- 4b. The other route: relatedness missed among near ordinary pairs (false negatives, related to sound) ----------
# Besides false positives, (A) has a second route: relatedness coded from the glosses may underestimate what Xu Shen judged for homophonous pairs.
# Model: the sensitivity in the labelled group does not vary with sound; in the ordinary group the ratio of the sensitivities for near and not-near pairs is r = se_O1/se_O0.
# If (A) is true the observed OR is 1/r, so r = 1/OR.
orb = (boot[:, 1, 1, 1] * boot[:, 0, 0, 1]) / (boot[:, 1, 0, 1] * boot[:, 0, 1, 1])
rlo, rhi = 1 / np.percentile(orb, 97.5), 1 / np.percentile(orb, 2.5)
need = tot[0, 0, 1] * tot[1, 1, 1] / tot[1, 0, 1]            # if the not-near ordinary related pairs are not missed, the near truly related ones would have to number this many
miss = need - tot[0, 1, 1]
nU_near = int(tot[0, 1, 0])
Mn = M[(M.label == 0) & (M.near == 1) & (M.R1 == 0)]
chk_n = int(((P.source == 'extended') & (P.label == 0) & (P.near == 1) & (P.R1 == 0) & P.sw_id.isin(chk)).sum())
orig_n = int(((P.source == 'original_100') & (P.label == 0) & (P.near == 1) & (P.R1 == 0)).sum())
unc_n = int(((P.source == 'extended') & (P.label == 0) & (P.near == 1) & (P.R1 == 0) & ~P.sw_id.isin(chk)).sum())
out('4b. The other route: relatedness missed by the gloss-based coding among near ordinary pairs (false negatives, only in the ordinary group)')
out(f'  If (A) is true and the sensitivity of the labelled group does not vary with sound, the observed OR equals the ratio of the sensitivities for not-near and near ordinary pairs, so a truly related near ordinary pair has only 1/{crude:.2f} = {1/crude:.2f} of the chance of a not-near one of being coded related (95% interval [{rlo:.2f}, {rhi:.2f}], from the bootstrap interval of the pooled OR).')
out(f'  Put differently: if the not-near ordinary related pairs are not missed, about {miss:.0f} of the {nU_near} ordinary near pairs coded unrelated ({miss/nU_near:.0%}) would in fact be related, whereas almost all of the {tot[0,0,0]} not-near ordinary pairs coded unrelated would be unrelated. The coders do not see the readings; for this to hold, links of meaning would have to hide outside the glosses more often in homophonous ordinary pairs than in labelled ones (the underestimate discussed in the summary).')
out(f'  The authors\' judgment: of these {nU_near} near ordinary pairs, {orig_n} belong to the original 100 items (coded by the authors themselves); of the new items {chk_n} were checked, of which the authors judged {int((Mn.Ra == 1).sum())} related (out of {len(Mn)} not judged X); {unc_n} have no author judgment. The numbers are too small to say much.')
out('')

# ---------- 5. Grid and output ----------
grid = []
for fpL in [0.0, 0.05, 0.10, 0.20, 0.30]:
    for fpO in [round(x, 3) for x in np.arange(0, 0.145, 0.005)]:
        v = float(orstar(tot, fpL, fpO))
        lo, hi, nv = boot_q(fpL, fpO)
        grid.append(dict(kind='grid', fp_L=fpL, fp_O=fpO, OR_star=round(v, 3) if not np.isnan(v) else '', OR_star_boot_lo=round(lo, 3), OR_star_boot_hi=round(hi, 3) if np.isfinite(hi) else ''))
rand_rel_O = int(((~M.dis) & (M.label == 0) & (M.R1 == 1)).sum()); rand_rel_O_unrel = int(((~M.dis) & (M.label == 0) & (M.R1 == 1) & (M.Ra == 0)).sum())
n_E_O = int(((P.label == 0) & (P.code1 == 'E') & (P.R1 == 1)).sum())
pL = fisher_exact([[tot[1, 1, 0], tot[1, 1, 1]], [tot[1, 0, 0], tot[1, 0, 1]]])[1]
out('Limitations:')
out('  1. The comparisons use disagreements between coders (the two passes; the authors\' consolidated judgment). They measure random error in the coding and the difference between the authors and the machine passes, not a systematic departure from Xu Shen\'s own judgment; '
    'a systematic difference shared by all coders between gloss-based "relatedness" and the relatedness Xu Shen saw would not show up here. The authors\' consolidated judgment is one sheet consolidated from the two authors\' separate checks, and only the consolidated sheet is on file. '
    'The sheet showed the type of check and the codes of the two passes; if the authors were therefore drawn towards them, the false-positive rate estimated here is too low (a bias towards (C)).')
out('  2. The model assumes that coding error is unrelated to sound (the coders do not see the readings, which the procedure guarantees). But the labelled pairs coded unrelated lie mostly on the not-near side (near %d/%d, not near %d/%d, Fisher p = %.3f), '
    'which shows that gloss-based "relatedness" and sound are linked in any case (as (C) predicts, but under (A) true relatedness and closeness in sound can also be linked); the correction treats error as unrelated to sound and cannot tell the two apart.' % (tot[1, 1, 0], tot[1, 1, :].sum(), tot[1, 0, 0], tot[1, 0, :].sum(), pL))
out('  3. "Related" is binary; its strength is not graded (see X1 and X2 for the effect of strength). Very few labelled pairs were judged unrelated by the authors, so the labelled-group false-positive rate cannot be estimated; only fp_L = 0 and fp_L = fp_O are given.')
out('  4. The random stratum of the authors\' check has only %d items, each standing for about 12; the share of ordinary pairs the authors judged unrelated (%.0f%%) is determined mainly by the disagreement stratum (pairs on which the two passes differed); '
    'of the %d ordinary related pairs in the random stratum only %d were judged unrelated, so the interval is wide. To narrow it, the authors could judge the remaining %d ordinary pairs coded related that have no judgment.'
    % (int((~M.dis).sum()), ast[0][1] * 100, rand_rel_O, rand_rel_O_unrel, len(unc)))
out('  5. The observed pooled odds ratio 2.61 and the GEE estimate 2.35 differ in weighting; the tipping points differ little between the two scales (see section 2).')
out(f'  6. The most likely shared bias is the threshold for E (connected through one step of extension): nearly all ordinary pairs coded related are E ({n_E_O}/{nR_O}), and the rule is to choose N when unsure between E and N. '
    f'Counting only E (X1: {ref_or("X1")}) and controlling for Y/E (X2: {ref_or("X2")}) are reported in the results table; the direction is unchanged, but Y/E is itself coded and cannot replace checking every pair.')
out('  7. This is an exploratory sensitivity analysis. It does not change the primary test fixed before the analysis (P1 OR 2.35, which the pre-specified rule reads as support for C) and involves no new coding.')
x1, f1 = xtip[(1.0, 0.0)]; x2, f2 = xtip[(2.0, 0.0)]; x15, f15 = xtip[(1.5, 0.0)]; xlo, _f = xtip[('lower', 0.0)]
x1h = xtip[(1.0, 0.30)][0]
sm = ['Key points (numbers in the sections above; exploratory, the primary test is unchanged):',
      f'  1. If (A) is true (true OR = 1), bringing the pooled OR {crude:.2f} down to 1 requires that {pct(x1)} of the truly unrelated ordinary pairs were coded "related", i.e. about {f1:.0f} of the {nR_O} ordinary pairs coded related ({f1/nR_O:.0%}) are false positives; bringing it to 2 needs {pct(x2)} ({f2/nR_O:.0%}), to 1.5 needs {pct(x15)} ({f15/nR_O:.0%}); bringing the lower 95% bootstrap limit to 1 needs {pct(xlo)}. The labelled-group rate hardly affects these figures (for fp_L from 0 to 30%, OR* = 1 needs {pct(x1)} to {pct(x1h)}); with equal rates in the two groups {pct(xnd)} suffices.',
      f'  2. So what is needed is not different error in the two groups but the base: {nU_O} ordinary pairs against {nU_L} labelled pairs are coded unrelated. If (A) is true, "true relatedness" is a confounder, and the coders\' measurement error in it leaves residual confounding in the ordinary group; the ordinary-group false positives fall mainly among the majority of not-near pairs and lower the near share of the ordinary pairs coded related.',
      f'  3. For comparison, between the two passes the ordinary-group false-positive rate is {pct(two[0]["fp"])} (of the {d2t[0,2]} ordinary pairs coded related in pass 1, {two[0]["sh"]:.0%} are not confirmed by pass 2); corrected by it, OR* = {corr[("two", False)][0]:.2f} [{corr[("two", False)][1]:.2f}, {corr[("two", False)][2]:.2f}]; random error does not wipe out the difference.',
      f'  4. The authors\' check sample gives {pct(ast[0][0])} [{pct(cfpO[0])}, {pct(cfpO[1])}] (of the ordinary pairs coded related in pass 1 the authors judged {ast[0][1]:.0%} [{cfsO[0]:.0%}, {cfsO[1]:.0%}] unrelated, of the labelled pairs {ast[1][1]:.0%} [{cfsL[0]:.0%}, {cfsL[1]:.0%}]); corrected by it, OR* = {corr[("auth", False)][0]:.2f} [{corr[("auth", False)][1]:.2f}, {corr[("auth", False)][2]:.2f}] ({pct(ast[0][0])} is close to the critical value {pct(x1)}), but the interval is too wide to settle the question. The reason is that the random stratum contains only {rand_rel_O} ordinary pairs coded related in pass 1 ({rand_rel_O_unrel} judged unrelated by the authors), the others mostly coming from pairs on which the two passes disagreed; and {len(unc)} ordinary pairs coded related have no author judgment.',
      f'  5. Conclusion: random error between the two passes is not enough to wipe out the difference. How large a systematic bias shared by both passes (if any; most likely a threshold for E wider than the authors\') would have to be: to lower OR* to 2 or the lower limit to 1 takes about {pct(x2)}, to lower it to 1 about {pct(x1)}; the present check sample can neither confirm nor exclude it. Having the {len(unc)} ordinary pairs coded related that have no author judgment judged as well would turn "what share are false positives" into a count.',
      f'  6. The other route (relatedness missed by the gloss-based coding among near ordinary pairs): a truly related near ordinary pair has only {1/crude:.2f} ([{rlo:.2f}, {rhi:.2f}]) of the chance of a not-near one of being coded related, i.e. about {miss:.0f} of the {nU_near} near ordinary pairs coded unrelated would in fact be related, while almost none of the not-near pairs are missed; the coders do not see the readings, so this would require links of meaning to hide outside the glosses more often in homophonous ordinary pairs than in labelled ones. Of these pairs the authors\' check covered only {len(Mn)}, of which {int((Mn.Ra == 1).sum())} were judged related; too few to say.',
      '']
lines[2:2] = sm
open(OUT / 'ext_bias_sensitivity_output.txt', 'w', encoding='utf-8').write('\n'.join(lines) + '\n')
with open(OUT / 'yisheng_bias_sensitivity_grid.csv', 'w', newline='', encoding='utf-8-sig') as f:
    cols = ['kind', 'target', 'fp_L', 'fp_O', 'fp_O_required', 'false_pos_share_of_coded_related_ordinary', 'OR_star', 'OR_star_boot_lo', 'OR_star_boot_hi']
    w = csv.DictWriter(f, fieldnames=cols, lineterminator='\n'); w.writeheader()
    for r in rows_tip + grid: w.writerow({k: r.get(k, '') for k in cols})
print('\n'.join(lines))
