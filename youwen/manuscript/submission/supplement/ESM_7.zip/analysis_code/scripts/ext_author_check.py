# Enlarged blind semantic coding, step 3: the authors' check of 126 items (analysis plan, section 4.5):
#   (1) agreement and kappa between the authors' consolidated judgment and the first and second pass;
#   (2) the tests redone with the authors' codes substituted for the machine codes (sensitivity analysis; the primary test is not changed).
# Usage: python scripts/ext_author_check.py      (run scripts/ext_analysis.py first)
# Reads:  data/author_check.csv (the authors' consolidated check sheet), output/ext_check_key.csv, output/ext_codes_long.csv,
#         output/yisheng_models_ext_coding.csv
# Writes: output/ext_author_check_output.txt, output/yisheng_models_ext_author_check.csv
# Note: gee()/mh()/verdict()/add()/frame() are the same functions as in ext_analysis.py (that script was fixed before the coding and is not modified);
#       this script first reproduces the results of ext_analysis.py with the unsubstituted data (see "identity check") and then does the substitution.
import csv, math, warnings
import numpy as np, pandas as pd
import statsmodels.api as sm, statsmodels.formula.api as smf
from statsmodels.stats.contingency_tables import StratifiedTable
from scipy.stats import fisher_exact, norm, binomtest
from _paths import DATA, OUT
warnings.filterwarnings('ignore')
SESOI = 2.0
SEED_BOOT, N_BOOT = 20260935, 2000

# ---------- Input ----------
A = pd.read_csv(DATA / 'author_check.csv', encoding='utf-8-sig', dtype=str)
A = A.rename(columns={'check_type': 'why', 'phonetic': 'phon', 'phonetic_gloss': 'pg', 'member': 'char', 'member_gloss': 'mg',
                      'author_code': 'author', 'pass1_code': 'p1s', 'pass2_code': 'p2s'})
K = pd.read_csv(OUT / 'ext_check_key.csv', encoding='utf-8-sig', dtype=str)
M = A.merge(K, on='check_id', suffixes=('', '_k'))
assert len(A) == len(M) == 126
assert (M.phon == M.phonetic).all() and (M['char'] == M['char_k']).all() and (M.p1s == M.p1_code).all() and (M.p2s == M.p2_code).all()
assert M.author.isin(list('YENX')).all() and M.check_id.is_unique
M['dis'] = (M.why_k == 'passes_disagree')
assert int(M.dis.sum()) == 76 and int((~M.dis).sum()) == 50

C = pd.read_csv(OUT / 'ext_codes_long.csv', encoding='utf-8-sig', dtype=str)
for c in ['label', 'near', 'ident']: C[c] = C[c].astype(int)
C['cat4'] = C.cat4.replace('nan', np.nan)
assert C.sw_id.is_unique and len(C) == 767

lines = []
def out(s=''): lines.append(s)

# ---------- 1. Agreement and kappa ----------
def kappa(a, b):
    a, b = list(a), list(b); n = len(a)
    po = sum(x == y for x, y in zip(a, b)) / n
    cats = set(a) | set(b)
    pe = sum((a.count(k) / n) * (b.count(k) / n) for k in cats)
    return ((po - pe) / (1 - pe) if pe < 1 else float('nan')), po
def wkappa(x, y, w):
    """Weighted kappa: items are repeated according to the weight w (a float); x and y are category sequences."""
    x, y, w = np.array(x), np.array(y), np.array(w, float)
    tot = w.sum(); po = w[x == y].sum() / tot
    pe = sum(w[x == k].sum() / tot * w[y == k].sum() / tot for k in set(x) | set(y))
    return (po - pe) / (1 - pe) if pe < 1 else float('nan'), po
def views(s):
    return {'four-category': list(s), 'related (Y/E) vs unrelated': [c in 'YE' for c in s], 'Y vs not-Y': [c == 'Y' for c in s]}

out("The authors' check (consolidated sheet data/author_check.csv: 126 items = all 76 items on which the two passes disagree + 50 items drawn at random from the 601 on which they agree)")
out("The sheet has no notes. Each author checked the items separately and the judgments were consolidated into one code per item; only the consolidated sheet is on file, so the agreement below is between the authors' consolidated judgment and the machine coding, not between the authors. The sheet showed the type of check and the codes of the two passes, so the check is not independent of them.")
out('')
out('Distribution of the authors\' codes: ' + ', '.join(f'{k} {int((M.author == k).sum())}' for k in 'YENX'))
out('')
d, r = M[M.dis], M[~M.dis]
out('1. The 76 items on which the passes disagree: which side the authors take')
out(f'  same as pass 1: {int((d.author == d.p1_code).sum())}; same as pass 2: {int((d.author == d.p2_code).sum())}; different from both: {int(((d.author != d.p1_code) & (d.author != d.p2_code)).sum())}')
out('  Cross-tabulation (rows = pass 1/pass 2, columns = authors):')
out(pd.crosstab(d.p1_code + '/' + d.p2_code, d.author).to_string())
out('')
out('2. The 50 random items (passes agree): agreement of the authors with the shared code')
out(f'  four-category agreement {int((r.author == r.p1_code).sum())}/50; related/unrelated agreement {int((r.author.isin(list("YE")) == r.p1_code.isin(list("YE"))).sum())}/50; X vs not-X agreement {int(((r.author == "X") == (r.p1_code == "X")).sum())}/50')
out('  Cross-tabulation (rows = shared code, columns = authors):')
out(pd.crosstab(r.p1_code, r.author).to_string())
out('')

# Stratified estimate: the disagreement stratum is complete, the agreement stratum is a random draw of 50 from 601
N_AGR, N_DIS = 677 - 76, 76
assert int((C.source == 'extended').sum()) == 677
W = np.where(M.dis, 1.0, N_AGR / 50)
def est(col, view):
    va, vb = views(M[col].values), views(M.author.values)
    return wkappa(va[view], vb[view], W)
rng = np.random.default_rng(SEED_BOOT)
di, ri = np.where(M.dis.values)[0], np.where(~M.dis.values)[0]
out('3. Estimated for all 677 new items (disagreement stratum complete, agreement stratum weighted 601/50): agreement and kappa between the authors and the machine passes')
out('  The agreement is a stratified estimate and kappa is computed from the weighted cross-tabulation; the intervals are 95%% percentile intervals of a stratified bootstrap (2,000 resamples, seed %d).' % SEED_BOOT)
out('  This is agreement between a human judgment and a model, not reliability between the authors; the authors\' judgment is not a gold standard, only a check.')
est_rows = []
for col, nm in [('p1_code', 'authors vs pass 1'), ('p2_code', 'authors vs pass 2')]:
    for view in ['four-category', 'related (Y/E) vs unrelated', 'Y vs not-Y']:
        k0, p0 = est(col, view)
        ks, ps = [], []
        for _ in range(N_BOOT):
            idx = np.concatenate([rng.choice(di, len(di)), rng.choice(ri, len(ri))])
            a = M[col].values[idx]; b = M.author.values[idx]; w = W[idx]
            va, vb = views(a), views(b)
            kk, pp = wkappa(va[view], vb[view], w)
            ks.append(kk); ps.append(pp)
        out(f'  {nm} | {view}: agreement {p0:.1%} [{np.nanpercentile(ps, 2.5):.1%}, {np.nanpercentile(ps, 97.5):.1%}], kappa = {k0:.3f} [{np.nanpercentile(ks, 2.5):.3f}, {np.nanpercentile(ks, 97.5):.3f}]')
out('')
out('  For comparison: between the two passes (677 new items) four-category kappa 0.817, related/unrelated kappa 0.833, Y/not-Y kappa 0.740 (ext_kappa_output.txt).')
out('')
out('4. Agreement by group (descriptive; the group was not shown to the authors)')
for rel, nm in [('亦聲', 'labelled'), ('聲', 'ordinary')]:
    s = M[M.relation == rel]; sd = s[s.dis]; sr = s[~s.dis]
    out(f'  {nm}: {len(s)} items checked; of these {len(sd)} disagreements, authors same as pass 1 {int((sd.author == sd.p1_code).sum())}, same as pass 2 {int((sd.author == sd.p2_code).sum())}; {len(sr)} random items, authors same as the shared code {int((sr.author == sr.p1_code).sum())}')
out('')

# ---------- 2. Sensitivity analysis with the authors' codes substituted ----------
# All 76 new items on which the passes disagree are in the check sheet, and the unchecked new items have the same code in both passes.
# So "substitute the authors' judgment for the 126 checked items" gives the same data whether pass 1 or pass 2 is the base: there is only one such data set.
auth = dict(zip(M.sw_id, M.author))
C['codeA'] = [auth.get(s, c1) for s, c1 in zip(C.sw_id, C.code1)]
unchecked_ext = C[(C.source == 'extended') & (~C.sw_id.isin(auth))]
assert (unchecked_ext.code1 == unchecked_ext.code2).all()
n_change = int(sum(auth[s] != c1 for s, c1 in zip(M.sw_id, M.p1_code)))
out('5. Sensitivity analysis with the authors\' codes substituted')
out(f'  The authors\' judgment replaces the 126 checked items (the other new items have the same code in both passes; the 90 original items keep their original blind codes). {n_change} items differ from the pass-1 code and {int((M.author != M.p2_code).sum())} differ from the pass-2 code.')
for rel, nm in [('亦聲', 'labelled'), ('聲', 'ordinary')]:
    s = M[M.relation == rel]
    out(f'  Of the {nm} pairs: different from pass 1 in {int((s.author != s.p1_code).sum())}/{len(s)}')

out('  Direction of the changes (authors relative to pass 1; the 126 checked items only, descriptive, the group was not shown):')
def trans(a, b):
    ra, rb = a in 'YE', b in 'YE'
    if a == b: return 'unchanged'
    if (a == 'X') != (b == 'X'): return 'X→non-X' if a == 'X' else 'non-X→X'
    if ra and not rb: return 'related→unrelated'
    if rb and not ra: return 'unrelated→related'
    return 'Y/E within related'
for rel, nm in [('亦聲', 'labelled pairs'), ('聲', 'ordinary pairs')]:
    s_ = M[M.relation == rel]
    tt = pd.Series([trans(a, b) for a, b in zip(s_.p1_code, s_.author)]).value_counts()
    out(f'    {nm} ({len(s_)} items): ' + ', '.join(f'{k} {v}' for k, v in tt.items()))
n1_, n2_ = int((d.author == d.p1_code).sum()), int((d.author == d.p2_code).sum())
out(f'  Of the 76 disagreements, in the {n1_ + n2_} where the authors agree with one of the passes they side with pass 2 in {n2_} (pass 1 in {n1_}); symmetric two-sided binomial test p = {binomtest(n2_, n1_ + n2_, 0.5).pvalue:.2g} (descriptive).')
out('')

res = []
def gee(df, formula, term):
    x = df.copy()
    for cs in [sm.cov_struct.Exchangeable(), sm.cov_struct.Independence()]:
        try:
            g = smf.gee(formula, groups='phonetic', data=x, family=sm.families.Binomial(), cov_struct=cs).fit()
            b, se = g.params[term], g.bse[term]
            if np.isfinite(b) and np.isfinite(se) and 0 < se < 10 and abs(b) < 10:
                return dict(OR=math.exp(b), lo=math.exp(b - 1.96 * se), hi=math.exp(b + 1.96 * se),
                            p2=2 * norm.sf(abs(b / se)), p1=norm.sf(b / se))
        except Exception:
            pass
    return None
def mh(df, y):
    tabs = []
    for _, g in df.groupby('phonetic'):
        if g.label.nunique() < 2: continue
        tabs.append(np.array([[((g.label == 1) & (g[y] == 1)).sum(), ((g.label == 1) & (g[y] == 0)).sum()],
                              [((g.label == 0) & (g[y] == 1)).sum(), ((g.label == 0) & (g[y] == 0)).sum()]], dtype=float))
    if not tabs: return None
    st = StratifiedTable(tabs); lo, hi = st.oddsratio_pooled_confint()
    return dict(strata=len(tabs), OR=st.oddsratio_pooled, lo=lo, hi=hi, p=st.test_null_odds(correction=False).pvalue)
def verdict(g):
    if g is None: return 'not estimable (GEE; e.g. complete separation)'
    c = g['p1'] < 0.05; a = g['hi'] < SESOI
    if c and a: return 'mixed: excess significant but upper CI below 2 (small residual sound effect)'
    if c: return 'supports C (same word / minimal derivation)'
    if a: return 'supports A (meaning-first)'
    return 'indeterminate'
def add(tier, name, df, y, x='label', formula=None, note='', decide=False):
    L, O = df[df[x] == 1], df[df[x] == 0]
    r = dict(tier=tier, test=name, n=len(df), n_phonetics=df.phonetic.nunique(),
             group1_hits=int(L[y].sum()), group1_n=len(L), group0_hits=int(O[y].sum()), group0_n=len(O),
             group1_rate=round(L[y].mean(), 3) if len(L) else '', group0_rate=round(O[y].mean(), 3) if len(O) else '')
    g = gee(df, formula or f'{y} ~ {x}', x)
    if g:
        r.update(gee_OR=round(g['OR'], 2), gee_CI95=f"{g['lo']:.2f}-{g['hi']:.2f}", gee_p_one_sided='%.2g' % g['p1'], gee_p_two_sided='%.2g' % g['p2'])
    if x == 'label' and formula is None:
        m = mh(df, y)
        if m: r.update(mh_strata=m['strata'], mh_OR=round(m['OR'], 2), mh_CI95=f"{m['lo']:.2f}-{m['hi']:.2f}", cmh_p_two_sided='%.2g' % m['p'])
    a, n1, c, n0 = r['group1_hits'], r['group1_n'], r['group0_hits'], r['group0_n']
    if n1 and n0: r['fisher_p_two_sided'] = '%.2g' % fisher_exact([[a, n1 - a], [c, n0 - c]])[1]
    if decide: r['verdict'] = verdict(g)
    r['note'] = note
    res.append(r); return g
def frame(code_col, related=('Y', 'E'), sub=None):
    x = C[C.cat4.notna() & (C[code_col] != 'X')].copy()
    x['related'] = x[code_col].isin(related).astype(int)
    return x if sub is None else sub(x)

def battery(code_col, tag):
    P = frame(code_col); PR = P[P.related == 1]
    add(tag, 'P1 near ~ label | related', PR, 'near', decide=True)
    add(tag, 'S1 MC identical ~ label | related', PR, 'ident', decide=True)
    NP = frame(code_col, sub=lambda x: x[x.paronomastic_gloss != 'True'])
    add(tag, 'S2 near ~ label | related, paronomastic glosses removed', NP[NP.related == 1], 'near', decide=True)
    SH = frame(code_col, sub=lambda x: x[(x.label == 0) | (x.layer == 'both')])
    add(tag, 'S3 near ~ label | related, labels shared with Xiao Xu only', SH[SH.related == 1], 'near', decide=True)
    CORE = frame(code_col, sub=lambda x: x[(x.paronomastic_gloss != 'True') & ((x.label == 0) | (x.layer == 'both'))])
    add(tag, 'X3 near ~ label | related, shared and non-paronomastic (exploratory)', CORE[CORE.related == 1], 'near', decide=True)
    PY = frame(code_col, related=('Y',))
    add(tag, 'S6 near ~ label | coded Y only', PY[PY.related == 1], 'near', decide=True)
    PE = frame(code_col, related=('E',))
    add(tag, 'X1 near ~ label | coded E only (exploratory)', PE[PE.related == 1], 'near')
    add(tag, 'S8 H2 related ~ label | all coded pairs, X excluded', P, 'related')
    add(tag, 'S9 near ~ related + label: coefficient of label', P, 'near', x='label', formula='near ~ related + label')
    add(tag, 'S9 near ~ related + label: coefficient of related', P, 'near', x='related', formula='near ~ related + label')
    ex = PR[PR.source == 'extended']
    add(tag, 'X4 near ~ label | related, new items only (exploratory)', ex, 'near')

battery('code1', 'identity_pass1')      # control: must equal the pass-1 rows of yisheng_models_ext_coding.csv
battery('codeA', 'author_adjudicated')  # the authors' judgment replaces the 126 checked items

# identity check: without substitution the results of ext_analysis.py must be reproduced
ref = pd.read_csv(OUT / 'yisheng_models_ext_coding.csv', encoding='utf-8-sig', dtype=str).fillna('')
chk = {'P1': 'P1', 'S1': 'S1', 'S2': 'S2', 'S3': 'S3', 'X3': 'X3', 'S8': 'S8 H2 related (Y/E) ~ label | all coded pairs in the MC frame, X excluded, pass-1 codes', 'X4': 'X4'}
ok = True; msgs = []
for r in [x for x in res if x['tier'] == 'identity_pass1']:
    tag = r['test'].split(' ')[0]
    if tag not in chk: continue
    m = ref[ref.test.str.startswith(chk[tag])]
    m = m[m.tier != 'descriptive']
    if tag == 'X4': m = m[m.test.str.startswith('X4 ')]
    if len(m) != 1: ok = False; msgs.append(f'{tag}: {len(m)} rows in reference'); continue
    m = m.iloc[0]
    same = all(str(r.get(c, '')) == m[c] for c in ['group1_hits', 'group1_n', 'group0_hits', 'group0_n', 'gee_OR', 'gee_CI95', 'gee_p_one_sided', 'mh_OR', 'mh_CI95'])
    if not same: ok = False; msgs.append(f'{tag}: differs')
out('')
out('  identity check (no substitution, pass-1 codes): ' + ('identical, cell by cell, to the corresponding rows of yisheng_models_ext_coding.csv' if ok else 'differences: ' + '; '.join(msgs)))
out('')
out('  test                                   | pass 1 (control)                       | authors\' judgment substituted')
def fmt(r):
    if r is None: return '—'
    g = f"{r['group1_hits']}/{r['group1_n']} vs {r['group0_hits']}/{r['group0_n']}"
    o = f", OR {r['gee_OR']} [{r['gee_CI95'].replace('-', ', ')}], p1 {r['gee_p_one_sided']}" if 'gee_OR' in r else ', not estimable'
    if r.get('mh_OR', '') != '': o += f"; MH {r['mh_OR']} [{r['mh_CI95'].replace('-', ', ')}]"
    return g + o
byname = {}
for r in res: byname.setdefault(r['test'], {})[r['tier']] = r
for name, dd in byname.items():
    out(f"  {name}\n      control:      {fmt(dd.get('identity_pass1'))}\n      substituted:  {fmt(dd.get('author_adjudicated'))}" + (f"\n      rule:         {dd['author_adjudicated'].get('verdict', '')}" if dd['author_adjudicated'].get('verdict') else ''))

cols = ['tier', 'test', 'n', 'n_phonetics', 'group1_hits', 'group1_n', 'group1_rate', 'group0_hits', 'group0_n', 'group0_rate',
        'gee_OR', 'gee_CI95', 'gee_p_one_sided', 'gee_p_two_sided', 'mh_strata', 'mh_OR', 'mh_CI95', 'cmh_p_two_sided', 'fisher_p_two_sided', 'verdict', 'note']
with open(OUT / 'yisheng_models_ext_author_check.csv', 'w', newline='', encoding='utf-8-sig') as f:
    w = csv.DictWriter(f, fieldnames=cols, lineterminator='\n'); w.writeheader()
    for r in res: w.writerow({k: r.get(k, '') for k in cols})
open(OUT / 'ext_author_check_output.txt', 'w', encoding='utf-8').write('\n'.join(lines) + '\n')
print('\n'.join(lines))
