"""Common paths for the analysis scripts. Run every script from any directory: python scripts/<name>.py"""
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent   # root folder of the unpacked analysis kit
DATA = ROOT / 'data'                              # released input tables (CSV, UTF-8) and raw coder answers
OUT = ROOT / 'output'                             # everything the scripts write
OUT.mkdir(exist_ok=True)
