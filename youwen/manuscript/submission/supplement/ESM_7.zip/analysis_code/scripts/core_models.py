# Core comparison of labelled (yisheng) and ordinary (sheng) compounds that share a phonetic: counts, Fisher tests and clustered models.
# Analysis set: in_analysis_set = True (label in the Da Xu text, Xu Xuan's additions removed, relation yisheng or sheng only);
#   ordinary compounds are kept only for phonetics that have at least one labelled member in the analysis set ("all"); a subset of phonetics with
#   both labelled and ordinary members is reported as well ("matched").
# Writes output/yisheng_summary.csv (counts, rates, one-sided Fisher p) and output/yisheng_models.csv (GEE clustered by phonetic, with a
#   variational-Bayes mixed logit as a cross-check and Holm correction within the main set and within the set that drops labels filed under their own phonetic).
# Usage: python scripts/core_models.py
import csv, collections, math, warnings
import numpy as np, pandas as pd
import statsmodels.api as sm, statsmodels.formula.api as smf
from statsmodels.genmod.bayes_mixed_glm import BinomialBayesMixedGLM
from statsmodels.stats.multitest import multipletests
from _paths import DATA, OUT
warnings.filterwarnings('ignore')

# Chinese data values used in pairs.csv (see the data dictionary): the Duan Yucai note layer and the Xiao Xu layer
DUAN_KEEPS, DUAN_DROPS, DUAN_MISSING = '亦聲', '無', '缺段注'      # Duan keeps the label / drops it / no Duan text in the data
XIAOXU_KEEPS, XIAOXU_DROPS = '亦聲', '無'                        # Xiao Xu keeps the label / drops it (aligned entries only)

with open(DATA / 'pairs.csv', encoding='utf-8-sig', newline='') as f:
    R = list(csv.DictReader(f))
LAB, ORD = 'labelled', 'ordinary'                                   # values of the column "group"

def lc(n, k): return math.lgamma(n + 1) - math.lgamma(k + 1) - math.lgamma(n - k + 1)
def fisher(a, b, c, d):                                              # one-sided Fisher exact p (excess in the first row)
    n1 = a + b; K = a + c; N = a + b + c + d
    return sum(math.exp(lc(K, x) + lc(N - K, n1 - x) - lc(N, n1)) for x in range(a, min(n1, K) + 1))

A = [r for r in R if r['in_analysis_set'] == 'True']
yph = {r['phonetic'] for r in A if r['group'] == LAB}
A = [r for r in A if r['phonetic'] in yph]
def matched(rows):
    k = collections.defaultdict(set)
    for r in rows: k[r['phonetic']].add(r['group'])
    keep = {p for p, v in k.items() if v == {LAB, ORD}}
    return [r for r in rows if r['phonetic'] in keep], len(keep)
out = []
def row(h, label, rows, pred, note=''):
    L1 = [r for r in rows if r['group'] == LAB]; L0 = [r for r in rows if r['group'] == ORD]
    a = sum(map(pred, L1)); c = sum(map(pred, L0))
    out.append(dict(hypothesis=h, comparison=label, labelled_hits=a, labelled_n=len(L1), labelled_rate=round(a / len(L1), 3) if L1 else '',
                    ordinary_hits=c, ordinary_n=len(L0), ordinary_rate=round(c / len(L0), 3) if L0 else '',
                    fisher_one_sided='%.2g' % fisher(a, len(L1) - a, c, len(L0) - c), note=note))
def both(h, label, rows, pred, note=''):
    row(h, label + ', all phonetics', rows, pred, note); m, k = matched(rows); row(h, label + f', matched phonetics (n={k})', m, pred, note)
mc = [r for r in A if r['mc_relation'] != 'NA']
oc = [r for r in A if r['morph_relation_auto'] != 'NA']
both('H1a', 'MC identical syllable', mc, lambda r: r['mc_relation'] == 'identical')
both('H1a', 'OC (BS) identical', oc, lambda r: r['morph_relation_auto'] == 'I')
ni_oc = [r for r in oc if r['morph_relation_auto'] != 'I']; ni_mc = [r for r in mc if r['mc_relation'] != 'identical']
both('H1b', 'OC R (affix/alternation only) among non-identical', ni_oc, lambda r: r['morph_relation_auto'] == 'R')
for t in sorted({r['morph_affix_type'] for r in ni_oc if r['morph_affix_type']}):
    row('H1b', f'OC R subtype {t} among non-identical, all phonetics', ni_oc, lambda r, t=t: r['morph_affix_type'] == t, 'descriptive')
for cat in ('O', 'O2', 'V', 'C'):
    row('H1b', f'OC category {cat} among non-identical, all phonetics', ni_oc, lambda r, cat=cat: r['morph_relation_auto'] == cat, 'descriptive')
both('H1b', 'MC tone/voicing alternation among non-identical', ni_mc, lambda r: r['mc_relation'] == 'tone_voicing_alt')
alt = [r for r in mc if r['mc_relation'] == 'tone_voicing_alt']
both('H1c', 'member has departing tone, among tone/voicing alternations', alt, lambda r: r['mc_qusheng_direction'] == 'member')
row('H1c', 'head has departing tone, among tone/voicing alternations, all phonetics', alt, lambda r: r['mc_qusheng_direction'] == 'head', 'descriptive')
both('H1c', 'member-departing derivative, among all MC pairs', mc, lambda r: r['mc_qusheng_direction'] == 'member')
both('H2-confound', 'paronomastic gloss (definition contains the phonetic)', A, lambda r: r['paronomastic_gloss'] == 'True')
nopar = [r for r in mc if r['paronomastic_gloss'] == 'False']
row('H1a-sens', 'MC identical, paronomastic glosses removed, all phonetics', nopar, lambda r: r['mc_relation'] == 'identical')
# Relation types of the homophonous pairs (descriptive)
idp = [r for r in A if r['mc_relation'] == 'identical']
for t in 'LFCUX':
    row('H1a-types', f'identical pairs of relation type {t}', idp, lambda r, t=t: r['identical_relation_type'] == t, 'descriptive; first-pass coding with the label visible (not blind)')
# Duan Yucai and Xiao Xu layers (H3, exploratory)
yi = [r for r in A if r['group'] == LAB]
def layer(name, rows):
    m = [r for r in rows if r['mc_relation'] != 'NA']; n = len(m)
    out.append(dict(hypothesis='H3', comparison=name + f' ({len(rows)} items)', labelled_n=n, labelled_hits=sum(r['mc_relation'] == 'identical' for r in m),
                    labelled_rate=round(sum(r['mc_relation'] == 'identical' for r in m) / n, 3) if n else '', note='MC-identical among items with MC; semantic codes not used here'))
layer('Da Xu + Duan both label', [r for r in yi if r['duan_label'] == DUAN_KEEPS])
layer('Da Xu labels, Duan drops', [r for r in yi if r['duan_label'] == DUAN_DROPS])
layer('Da Xu labels, Duan text missing in data', [r for r in yi if r['duan_label'] == DUAN_MISSING])
layer('Da Xu + Xiao Xu both label (aligned)', [r for r in yi if r['xiaoxu_label'] == XIAOXU_KEEPS])
layer('Da Xu labels, Xiao Xu drops (aligned)', [r for r in yi if r['xiaoxu_label'] == XIAOXU_DROPS])
ex = [r for r in R if r['label_source'] != 'daxu']
layer('Duan/Xiao Xu only (extra rows, huiyi in Da Xu)', ex)
layer('Da Xu sheng, Duan adds yisheng', [r for r in A if r['group'] == ORD and r['duan_label'] == DUAN_KEEPS])

# H4 (exploratory): labels filed under the section of their own phonetic (no ordinary compound is filed there, so only labelled entries can be compared)
def h4(name, pred):
    rs = [r for r in yi if r['mc_relation'] != 'NA']; a = [r for r in rs if r['filed_under_phonetic'] == 'True']; b = [r for r in rs if r['filed_under_phonetic'] == 'False']
    x = sum(map(pred, a)); y = sum(map(pred, b))
    out.append(dict(hypothesis='H4', comparison=name + ' (filed under phonetic vs other labels)', labelled_hits=x, labelled_n=len(a), labelled_rate=round(x / len(a), 3),
                    ordinary_hits=y, ordinary_n=len(b), ordinary_rate=round(y / len(b), 3),
                    fisher_one_sided='%.2g' % min(fisher(x, len(a) - x, y, len(b) - y), fisher(y, len(b) - y, x, len(a) - x)),
                    note=f"columns: labelled entries filed under their phonetic vs other labelled entries; the smaller of the two one-sided p values; {sum(r['filed_under_phonetic'] == 'True' for r in yi)} of {len(yi)} labels are filed under their phonetic; no ordinary compound is"))
h4('MC identical', lambda r: r['mc_relation'] == 'identical')
h4('MC tone/voicing alternation', lambda r: r['mc_relation'] == 'tone_voicing_alt')

# ---- Models: outcome ~ label, clustered by phonetic (GEE, exchangeable) and a variational-Bayes mixed logit with a phonetic random intercept ----
tests = [('H1a', 'MC identical', mc, lambda r: r['mc_relation'] == 'identical'),
         ('H1b', 'MC tone/voicing alt | non-identical', ni_mc, lambda r: r['mc_relation'] == 'tone_voicing_alt'),
         ('H1b-OC', 'OC R | non-identical', ni_oc, lambda r: r['morph_relation_auto'] == 'R'),
         ('H1c', 'member departing | alternation', alt, lambda r: r['mc_qusheng_direction'] == 'member')]
res = []
sub = lambda rows: [r for r in rows if r.get('filed_under_phonetic') != 'True']
tests += [(h + ' (excl. filed-under-phonetic)', n, sub(rows), p) for h, n, rows, p in tests]
for h, name, rows, pred in tests:
    df = pd.DataFrame(dict(y=[int(pred(r)) for r in rows], label=[int(r['group'] == LAB) for r in rows], phon=[r['phonetic'] for r in rows]))
    g = smf.gee('y ~ label', groups='phon', data=df, family=sm.families.Binomial(), cov_struct=sm.cov_struct.Exchangeable()).fit()
    b, se = g.params['label'], g.bse['label']
    vb = BinomialBayesMixedGLM.from_formula('y ~ label', {'phon': '0 + C(phon)'}, df).fit_vb()
    i = list(vb.model.exog_names).index('label'); bm, sd = vb.fe_mean[i], vb.fe_sd[i]
    p1 = g.pvalues['label'] / 2 if b > 0 else 1 - g.pvalues['label'] / 2   # one-sided (direction fixed beforehand)
    res.append(dict(hypothesis=h, outcome=name, n=len(df), n_phonetics=df.phon.nunique(),
                    gee_OR=round(math.exp(b), 2), gee_CI95=f'{math.exp(b - 1.96 * se):.2f}-{math.exp(b + 1.96 * se):.2f}', gee_p_one_sided=p1,
                    glmm_vb_OR=round(math.exp(bm), 2), glmm_vb_CI95=f'{math.exp(bm - 1.96 * sd):.2f}-{math.exp(bm + 1.96 * sd):.2f}',
                    glmm_vb_z=round(bm / sd, 2)))
k = len(res) // 2   # Holm correction separately within the main set and within the set that excludes labels filed under their own phonetic
adj = list(multipletests([x['gee_p_one_sided'] for x in res[:k]], method='holm')[1]) + list(multipletests([x['gee_p_one_sided'] for x in res[k:]], method='holm')[1])
for x, a in zip(res, adj): x['gee_p_one_sided'] = '%.2g' % x['gee_p_one_sided']; x['holm_p'] = '%.2g' % a
with open(OUT / 'yisheng_models.csv', 'w', newline='', encoding='utf-8-sig') as f:
    w = csv.DictWriter(f, fieldnames=list(res[0]), lineterminator='\n'); w.writeheader(); w.writerows(res)
cols = ['hypothesis', 'comparison', 'labelled_hits', 'labelled_n', 'labelled_rate', 'ordinary_hits', 'ordinary_n', 'ordinary_rate', 'fisher_one_sided', 'note']
with open(OUT / 'yisheng_summary.csv', 'w', newline='', encoding='utf-8-sig') as f:
    w = csv.DictWriter(f, fieldnames=cols, lineterminator='\n'); w.writeheader()
    for o in out: w.writerow({c: o.get(c, '') for c in cols})
for x in res: print(x)
print('analysis set:', collections.Counter(r['group'] for r in A), 'phonetics', len(yph))
for o in out: print(o['hypothesis'], o['comparison'], f"{o['labelled_hits']}/{o['labelled_n']}", f"{o.get('ordinary_hits', '')}/{o.get('ordinary_n', '')}", o.get('fisher_one_sided', ''))
