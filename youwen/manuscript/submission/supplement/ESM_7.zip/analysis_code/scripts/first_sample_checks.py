# Checks behind the paper's first-sample numbers: fanqie identity, the H1c decomposition, agreement between the blind and the non-blind first-sample coding,
# and the semantic contrast (H2) on the 100-item first sample. Read-only: nothing here changes a data file.
# Usage: python scripts/first_sample_checks.py
# Reads:  data/pairs.csv, data/first_sample_codes.csv
# Writes: output/first_sample_checks_output.txt
import math, warnings
from collections import Counter
import numpy as np, pandas as pd
import statsmodels.api as sm, statsmodels.formula.api as smf
from scipy.stats import fisher_exact
from _paths import DATA, OUT
warnings.filterwarnings('ignore')
lines = []
def out(s=''): lines.append(str(s))

# NB: read with the default missing-value handling, so that the entries "NA" and "" count as missing exactly as in the original analysis
d = pd.read_csv(DATA / 'pairs.csv', encoding='utf-8-sig', dtype=str)
A = d[d.in_analysis_set == 'True']; yph = set(A[A.group == 'labelled'].phonetic); A = A[A.phonetic.isin(yph)].copy()
A['label'] = (A.group == 'labelled').astype(int)
def gee(df, y):
    df = df.assign(y=y.astype(int))
    g = smf.gee('y ~ label', groups='phonetic', data=df, family=sm.families.Binomial(), cov_struct=sm.cov_struct.Exchangeable()).fit()
    b, se = g.params['label'], g.bse['label']; p = g.pvalues['label']
    return f'OR={math.exp(b):.2f} [{math.exp(b - 1.96 * se):.2f}-{math.exp(b + 1.96 * se):.2f}] p2={p:.2g} n={len(df)} k={df.phonetic.nunique()}'
def fis(df, y, name):
    y = y.astype(bool); a = (y & (df.label == 1)).sum(); n1 = (df.label == 1).sum(); c = (y & (df.label == 0)).sum(); n0 = (df.label == 0).sum()
    orr, p = fisher_exact([[a, n1 - a], [c, n0 - c]], alternative='greater')
    out(f'{name}: {a}/{n1} ({a / n1:.1%}) vs {c}/{n0} ({c / n0:.1%}) fisherOR={orr:.2f} p1={p:.2g} | GEE {gee(df, y)}')

out('A. Full dataset (labelled = first number, ordinary = second number)')
mc = A[A.mc_relation != 'NA'].dropna(subset=['mc_relation'])
fis(mc, mc.mc_relation == 'identical', 'H1a MC identical')
# fanqie identity (independent of the Guangyun matching)
fq = A.dropna(subset=['daxu_fanqie', 'head_dx_fanqie'])
fis(fq, fq.daxu_fanqie == fq.head_dx_fanqie, 'Da Xu fanqie identical')
out(f'fanqie coverage (0 = ordinary, 1 = labelled): {fq.label.value_counts().to_dict()}')
alt = mc[mc.mc_relation == 'tone_voicing_alt']
fis(alt, alt.mc_qusheng_direction == 'member', 'H1c member departing | alternation')
fis(alt, alt.mc_qusheng_direction.isin(['member', 'head']), 'departing tone involved | alternation')
dep = alt[alt.mc_qusheng_direction.isin(['member', 'head'])]
fis(dep, dep.mc_qusheng_direction == 'member', 'member departing | departing tone involved')
fis(mc, mc.mc_qusheng_direction.isin(['member', 'head']), 'departing-tone alternation among all MC pairs')
fis(mc, mc.mc_qusheng_direction == 'member', 'member-departing among all MC pairs')
fis(mc, mc.mc_qusheng_direction == 'head', 'head-departing among all MC pairs')
nn = alt[alt.mc_qusheng_direction == 'none']
out('Tone/voicing alternations without a departing tone, by tone of head and member:')
out(pd.crosstab([nn.mc_tone_head, nn.mc_tone_member], nn.group).to_string())
out('Voicing differs among tone/voicing alternations:')
out(pd.crosstab(alt.mc_voicing_differs, alt.group).to_string())
fis(mc, (mc.mc_relation == 'identical') | (mc.mc_qusheng_direction == 'member'), 'identity or member-departing')
out('MC match confidence (member), by group:'); out(pd.crosstab(mc.mc_confidence, mc.group).to_string())
out('MC match confidence (head), by group:'); out(pd.crosstab(mc.head_mc_confidence, mc.group).to_string())

# ---- First sample (100 items): agreement of the two codings, then H2 ----
out('')
out('B. First sample, 100 items')
s = pd.read_csv(DATA / 'first_sample_codes.csv', encoding='utf-8-sig', dtype=str, keep_default_na=False)
assert len(s) == 100
def kappa(p):
    n = len(p); po = sum(a == b for a, b in p) / n
    ca = Counter(a for a, _ in p); cb = Counter(b for _, b in p)
    pe = sum(ca[k] * cb[k] for k in set(ca) | set(cb)) / n / n
    return (po - pe) / (1 - pe), po
pairs = list(zip(s.nonblind_code, s.blind_code))
k4, po4 = kappa(pairs); k2, po2 = kappa([(a == 'Y', b == 'Y') for a, b in pairs])
out(f'Non-blind pass (instance that built the dataset) vs blind pass: n={len(pairs)}  four categories (Y/E/N/X) kappa={k4:.3f} (agreement {po4:.1%})  Y vs not-Y kappa={k2:.3f} (agreement {po2:.1%})')
yn = sum({a, b} == {'Y', 'N'} for a, b in pairs)
out(f'Y-N disagreements between the two passes: {yn}')
for _, r in s[s.nonblind_code != s.blind_code].iterrows():
    out(f'  disagreement ({r.phonetic}, {r.member}): non-blind {r.nonblind_code}, blind {r.blind_code}')

m = s.merge(d[['sw_id', 'group', 'paronomastic_gloss', 'mc_relation', 'mc_qusheng_direction', 'is_xinfu']].rename(columns={'group': 'group_in_pairs'}), on='sw_id', how='left')
assert len(m) == 100
out(f'items {len(m)}; group in the dataset: {m.group_in_pairs.value_counts(dropna=False).to_dict()}; in analysis set: {m.in_analysis_set.value_counts(dropna=False).to_dict()}')
out(f'items whose group in the coding sheet differs from the dataset: {m[(m.group != m.group_in_pairs) & m.group_in_pairs.notna()][["item", "phonetic", "member", "group", "group_in_pairs"]].values.tolist()}')
a = m[m.in_analysis_set == 'True'].copy(); a['grp'] = a.group_in_pairs
out(f'analysis-set items {len(a)} {a.grp.value_counts().to_dict()}')
def rep(df, col, name):
    df = df[df[col] != 'X'].copy(); df['y'] = df[col].isin(['Y', 'E']).astype(int); df['label'] = (df.grp == 'labelled').astype(int)
    y = df[df.label == 1]; o = df[df.label == 0]
    orr, p = fisher_exact([[y.y.sum(), len(y) - y.y.sum()], [o.y.sum(), len(o) - o.y.sum()]], alternative='greater')
    ys = (y[col] == 'Y').sum(); os_ = (o[col] == 'Y').sum()
    orr2, p2 = fisher_exact([[ys, len(y) - ys], [os_, len(o) - os_]], alternative='greater')
    out(f'{name}: Y+E {y.y.sum()}/{len(y)} vs {o.y.sum()}/{len(o)} OR={orr:.1f} p={p:.2g} | Y only {ys}/{len(y)} vs {os_}/{len(o)} OR={orr2:.1f} p={p2:.2g}')
    return df
for col, nm in [('blind_code', 'Blind pass'), ('nonblind_code', 'Non-blind pass')]:
    rep(a, col, nm + ' all')
    rep(a[a.paronomastic_gloss == 'False'], col, nm + ' no paronomastic gloss')
# cross: semantic coding x MC relation
b = a[a.blind_code != 'X'].copy(); b['semrel'] = b.blind_code.isin(['Y', 'E']).astype(int); b['ident'] = (b.mc_relation == 'identical').astype(int); b['label'] = (b.grp == 'labelled').astype(int)
b = b[b.mc_relation.notna() & (b.mc_relation != 'NA')]
out('Cross-table (group, coded related) x MC relation:')
out(pd.crosstab([b.grp, b.semrel], b.mc_relation).to_string())
g = smf.logit('ident ~ label + semrel', data=b).fit(disp=0); out('logit ident ~ label + semrel'); out(g.summary2().tables[1][['Coef.', 'P>|z|']].to_string())
g = smf.logit('semrel ~ label + ident', data=b).fit(disp=0); out('logit semrel ~ label + ident'); out(g.summary2().tables[1][['Coef.', 'P>|z|']].to_string())
out(f"phonetics in the sample {a.phonetic.nunique()}")
out('Paronomastic gloss among the sample, by group:'); out(pd.crosstab(a.grp, a.paronomastic_gloss).to_string())
df = a[a.blind_code != 'X'].copy(); df['y'] = df.blind_code.isin(['Y', 'E']).astype(int); df['label'] = (df.grp == 'labelled').astype(int)
g = smf.gee('y ~ label', groups='phonetic', data=df, family=sm.families.Binomial(), cov_struct=sm.cov_struct.Exchangeable()).fit()
b_, se = g.params['label'], g.bse['label']; out(f'H2 GEE (blind pass): n={len(df)}, phonetics={df.phonetic.nunique()}, OR={math.exp(b_):.3f} [{math.exp(b_ - 1.96 * se):.3f}, {math.exp(b_ + 1.96 * se):.3f}], one-sided p={g.pvalues["label"] / 2:.3g}')
df2 = df[df.paronomastic_gloss == 'False']
g = smf.gee('y ~ label', groups='phonetic', data=df2, family=sm.families.Binomial(), cov_struct=sm.cov_struct.Exchangeable()).fit()
b_, se = g.params['label'], g.bse['label']; out(f'H2 GEE without paronomastic glosses: n={len(df2)}, OR={math.exp(b_):.3f} [{math.exp(b_ - 1.96 * se):.3f}, {math.exp(b_ + 1.96 * se):.3f}], one-sided p={g.pvalues["label"] / 2:.3g}')
out(f'n in the identity-semantic model: {len(b)}')
out('')
out("Note: the sensitivity analysis without Wang Yun's rejected labels is in scripts/sensitivity_wang_yun.py (output/yisheng_models_wangyun_sensitivity.csv).")
(OUT / 'first_sample_checks_output.txt').write_text('\n'.join(lines) + '\n', encoding='utf-8')
print('\n'.join(lines))
