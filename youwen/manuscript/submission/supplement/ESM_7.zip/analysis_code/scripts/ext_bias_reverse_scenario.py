# Enlarged blind semantic coding (reverse-direction scenario for the bias sensitivity, S3). Exploratory, added after the results were seen; not part of the decision rule.
# Background: ext_bias_sensitivity.py looks in one direction only: truly unrelated ordinary pairs miscoded "related" would inflate the sound difference.
#   Here we look in the other direction: the 31 labelled pairs that the first blind pass coded unrelated are treated as related on the strength of the label itself
#   (as if the coders had missed a link) and are added to the related group, which lowers the near share of the labelled group
#   (only a small part of these 31 pairs is near). A hand computation from the counts of the paper's Table 8 gives a near OR of about 2.17;
#   the interval has to come from the script.
# Usage: python scripts/ext_bias_reverse_scenario.py      (run scripts/ext_analysis.py first)
# Reads:  output/ext_codes_long.csv, output/yisheng_models_ext_coding.csv
# Writes: output/ext_bias_reverse_scenario_output.txt, output/yisheng_bias_reverse_scenario.csv
# Note: gee()/mh()/verdict()/add() are the same functions as in ext_second_answer_sensitivity.py (which are the same as in ext_analysis.py).
#       The script first reproduces P1 and S1 of yisheng_models_ext_coding.csv without the folding and then folds. It only reads existing files; no new coding.
#       No random numbers are used: the result is deterministic.
import csv, math, warnings
import numpy as np, pandas as pd
import statsmodels.api as sm, statsmodels.formula.api as smf
from statsmodels.stats.contingency_tables import StratifiedTable
from scipy.stats import fisher_exact, norm
from _paths import OUT
warnings.filterwarnings('ignore')
SESOI = 2.0
lines = []
def out(s=''): lines.append(s)

C = pd.read_csv(OUT / 'ext_codes_long.csv', encoding='utf-8-sig', dtype=str)
for c in ['label', 'near', 'ident']: C[c] = C[c].astype(int)
C['cat4'] = C.cat4.replace('nan', np.nan)
assert len(C) == 767 and C.sw_id.is_unique

# ---------- Statistical tools (same as ext_second_answer_sensitivity.py) ----------
res = []
def gee(df, formula, term):
    x = df.copy()
    for cs in [sm.cov_struct.Exchangeable(), sm.cov_struct.Independence()]:
        try:
            g = smf.gee(formula, groups='phonetic', data=x, family=sm.families.Binomial(), cov_struct=cs).fit()
            b, se = g.params[term], g.bse[term]
            if np.isfinite(b) and np.isfinite(se) and 0 < se < 10 and abs(b) < 10:
                return dict(OR=math.exp(b), lo=math.exp(b - 1.96 * se), hi=math.exp(b + 1.96 * se),
                            p2=2 * norm.sf(abs(b / se)), p1=norm.sf(b / se))
        except Exception:
            pass
    return None
def mh(df, y):
    tabs = []
    for _, g in df.groupby('phonetic'):
        if g.label.nunique() < 2: continue
        tabs.append(np.array([[((g.label == 1) & (g[y] == 1)).sum(), ((g.label == 1) & (g[y] == 0)).sum()],
                              [((g.label == 0) & (g[y] == 1)).sum(), ((g.label == 0) & (g[y] == 0)).sum()]], dtype=float))
    if not tabs: return None
    st = StratifiedTable(tabs); lo, hi = st.oddsratio_pooled_confint()
    return dict(strata=len(tabs), OR=st.oddsratio_pooled, lo=lo, hi=hi, p=st.test_null_odds(correction=False).pvalue)
def verdict(g):
    if g is None: return 'not estimable (GEE; e.g. complete separation)'
    c = g['p1'] < 0.05; a = g['hi'] < SESOI
    if c and a: return 'mixed: excess significant but upper CI below 2 (small residual sound effect)'
    if c: return 'supports C (same word / minimal derivation)'
    if a: return 'supports A (meaning-first)'
    return 'indeterminate'
def add(tier, name, df, y, x='label', formula=None, note='', decide=False):
    L, O = df[df[x] == 1], df[df[x] == 0]
    r = dict(tier=tier, test=name, n=len(df), n_phonetics=df.phonetic.nunique(),
             group1_hits=int(L[y].sum()), group1_n=len(L), group0_hits=int(O[y].sum()), group0_n=len(O),
             group1_rate=round(L[y].mean(), 3) if len(L) else '', group0_rate=round(O[y].mean(), 3) if len(O) else '')
    g = gee(df, formula or f'{y} ~ {x}', x)
    if g:
        r.update(gee_OR=round(g['OR'], 2), gee_CI95=f"{g['lo']:.2f}-{g['hi']:.2f}", gee_p_one_sided='%.2g' % g['p1'], gee_p_two_sided='%.2g' % g['p2'],
                 gee_p_one_sided_exact='%.4g' % g['p1'], p1_raw=g['p1'])
    if x == 'label' and formula is None:
        m = mh(df, y)
        if m: r.update(mh_strata=m['strata'], mh_OR=round(m['OR'], 2), mh_CI95=f"{m['lo']:.2f}-{m['hi']:.2f}", cmh_p_two_sided='%.2g' % m['p'])
    a, n1, c, n0 = r['group1_hits'], r['group1_n'], r['group0_hits'], r['group0_n']
    if n1 and n0: r['fisher_p_two_sided'] = '%.2g' % fisher_exact([[a, n1 - a], [c, n0 - c]])[1]
    if decide: r['verdict'] = verdict(g)
    r['note'] = note
    res.append(r); return g

# ---------- Data: the same frame as the main test (in the frame, with Middle Chinese readings, first-pass code not X) ----------
P = C[C.cat4.notna() & (C.code1 != 'X')].copy()
assert len(P) == 634 and int(P.label.sum()) == 172
P['related'] = P.code1.isin(['Y', 'E']).astype(int)
L0 = P[(P.label == 1) & (P.related == 0)]                 # labelled, coded unrelated in the first pass
assert len(L0) == 31
P['fold_all'] = ((P.related == 1) | (P.label == 1)).astype(int)                          # all 31 folded in
P['fold_far'] = ((P.related == 1) | ((P.label == 1) & (P.near == 0))).astype(int)        # only the not-near ones among them (the least favourable choice)
assert int(P.fold_all.sum()) == int(P.related.sum()) + 31

VARS = [('control', 'Reference: the main test (first blind pass, pairs coded related)', 'related'),
        ('fold_all', 'S3: all 31 labelled pairs coded unrelated are added to the related group', 'fold_all'),
        ('fold_far', 'S3, least favourable choice: only the not-near ones among the 31 are added', 'fold_far')]
for tier, nm, col in VARS:
    add(tier, 'P1r near ~ label | related', P[P[col] == 1], 'near', decide=True)
    add(tier, 'S1r MC identical ~ label | related', P[P[col] == 1], 'ident', decide=True)

# Identity check: without the folding, P1 and S1 of yisheng_models_ext_coding.csv must be reproduced
ref = pd.read_csv(OUT / 'yisheng_models_ext_coding.csv', encoding='utf-8-sig', dtype=str).fillna('')
for tag, refname in [('P1r', 'P1'), ('S1r', 'S1')]:
    m = ref[ref.test.str.startswith(refname + ' ') & (ref.tier != 'descriptive')]
    assert len(m) == 1, (tag, len(m))
    m = m.iloc[0]
    r = [x for x in res if x['tier'] == 'control' and x['test'].startswith(tag + ' ')][0]
    assert all(str(r.get(c, '')) == m[c] for c in ['group1_hits', 'group1_n', 'group0_hits', 'group0_n', 'gee_OR', 'gee_CI95', 'gee_p_one_sided', 'mh_OR', 'mh_CI95']), tag

# ---------- Output ----------
def fmt(r):
    g = f"{r['group1_hits']}/{r['group1_n']} vs {r['group0_hits']}/{r['group0_n']}"
    o = f", OR {float(r['gee_OR']):.2f} [{r['gee_CI95'].replace('-', ', ')}], p1 {r['gee_p_one_sided']}" if 'gee_OR' in r else ', not estimable'
    if 'p1_raw' in r and 0.04 <= r['p1_raw'] <= 0.06: o += f" (exact one-sided p {r['p1_raw']:.4f}, right at the .05 boundary)"
    if r.get('mh_OR', '') != '': o += f"; MH {r['mh_OR']} [{r['mh_CI95'].replace('-', ', ')}]"
    return g + o
def crude(r):
    a, n1, c, n0 = r['group1_hits'], r['group1_n'], r['group0_hits'], r['group0_n']
    return (a * (n0 - c)) / ((n1 - a) * c)
byt = {(r['tier'], r['test'].split(' ')[0]): r for r in res}

out('Reverse-direction scenario for the bias sensitivity (S3; exploratory, added after the results were seen, not part of the decision rule)')
out('Background: the tipping-point analysis (ext_bias_sensitivity_output.txt) looks in one direction only: truly unrelated ordinary pairs miscoded "related" would inflate the sound difference.')
out('Here we look in the other direction: the 31 labelled pairs that the first blind pass coded unrelated are treated as related on the strength of the label itself (as if the coders had missed a link), added to the related group, and the near shares are compared again.')
out('This is an extreme scenario, not an estimate: it assumes that all 31 pairs really are related in meaning, so it is a stress test.')
out('')
out('1. What the 31 pairs are')
n_near = int(L0.near.sum())
out(f'  In the frame, 634 pairs: labelled 172 (coded related {int(((P.label == 1) & (P.related == 1)).sum())}, coded unrelated {len(L0)}), ordinary 462 (coded related {int(((P.label == 0) & (P.related == 1)).sum())}, coded unrelated {int(((P.label == 0) & (P.related == 0)).sum())}).')
cats = L0.cat4.value_counts()
out(f'  The 31 labelled pairs coded unrelated: near {n_near} ({n_near / len(L0):.0%}), not near {len(L0) - n_near} ({(len(L0) - n_near) / len(L0):.0%}). ' +
    'Middle Chinese category: ' + ', '.join(f'{k} {v}' for k, v in cats.items()) + '.')
lay = L0.layer.value_counts(); srcs = L0.source.value_counts()
out('  Source of the 31 pairs: ' + ', '.join(f'{ {"both": "shared by Da Xu and Xiao Xu", "daxu_only": "Da Xu only", "unknown": "collation undecided"}.get(k, k)} {v}' for k, v in lay.items()) +
    f'; with paronomastic glosses {int((L0.paronomastic_gloss == "True").sum())}; new items {int(srcs.get("extended", 0))}, first-sample items {int(srcs.get("original_100", 0))}.')
Lr = P[(P.label == 1) & (P.related == 1)]
out(f'  For comparison: of the labelled pairs coded related, {len(Lr)} pairs, {int(Lr.near.sum())} are near ({Lr.near.mean():.0%}). So the 31 pairs added have a much lower near share and pull the near share of the labelled group down.')
out('')
out('2. The main test under the three choices (near ~ label among the pairs coded related; GEE clustered by phonetic, one-sided p; rule: p < .05 and upper confidence limit >= 2 supports C)')
for tier, nm, col in VARS:
    r = byt[(tier, 'P1r')]
    out(f'  {nm}')
    out(f'      {fmt(r)}; pooled (unweighted) OR {crude(r):.2f}; rule: {r["verdict"]}')
out('')
out('3. Identity (S1 definition) under the three choices')
for tier, nm, col in VARS:
    r = byt[(tier, 'S1r')]
    out(f'  {nm}')
    out(f'      {fmt(r)}; pooled (unweighted) OR {crude(r):.2f}; rule: {r["verdict"]}')
out('')
ra = byt[('fold_all', 'P1r')]; rc = byt[('control', 'P1r')]; rf = byt[('fold_far', 'P1r')]
out('4. Comparison with a hand computation from the paper\'s Table 8')
out(f'  Hand computation from the counts of Table 8: 81/172 against 23/79, OR about 2.17. This script: {fmt(ra)}; pooled (unweighted) OR {crude(ra):.2f}.')
out(f'  The 2.17 is the unweighted pooled odds ratio (the script gives {crude(ra):.2f}, in agreement); the GEE clustered by phonetic gives a point estimate of {float(ra["gee_OR"]):.2f}, lower than the pooled value, and the interval is the GEE interval.' if abs(crude(ra) - 2.17) < 0.005 else f'  The hand-computed 2.17 does not agree with the script\'s pooled odds ratio {crude(ra):.2f}; the difference is reported as it is.')
out('')
out('Notes:')
out('  1. Exploratory, post hoc; the main test remains the first-blind-pass result of analysis plan section 4.2 and the rule has not been changed; no new coding was done and the official numbers are not changed.')
out(f'  2. The 31 pairs added have a near share of only {n_near}/{len(L0)} ({n_near / len(L0):.0%}), lower than the {Lr.near.mean():.0%} of the labelled pairs coded related, so adding all of them lowers the near share of the labelled group; the choice that lowers it most adds only the {len(L0) - n_near} not-near pairs among them (the near ones are not added). Pooled (unweighted) OR: not folded {crude(rc):.2f}, all folded {crude(ra):.2f}, only the not-near ones folded {crude(rf):.2f}. The GEE estimates are in section 2; only these choices were computed, not all subsets.')
out(f'  3. Result: with all folded in, GEE OR {float(ra["gee_OR"]):.2f} [{ra["gee_CI95"].replace("-", ", ")}], against {float(rc["gee_OR"]):.2f} [{rc["gee_CI95"].replace("-", ", ")}] for the reference and {float(rf["gee_OR"]):.2f} [{rf["gee_CI95"].replace("-", ", ")}] for the least favourable choice. The lower confidence limit is above 1 in all three, and by the rule all three read as "supports (C)" (upper limit >= 2 and one-sided p < .05); but the point estimate falls to about 2, the smallest effect of interest.')
out('  4. Taking the two directions together: false positives in the ordinary group (ext_bias_sensitivity_output.txt) can bring the OR down to 1 if their rate is large enough; this reverse direction, even in its most extreme form, does not bring the OR down to 1, only to about 2.')
out('  5. The GEE and the pooled odds ratio weight the pairs differently: 2.17 is the pooled odds ratio, whereas the GEE of the main test is clustered by phonetic; the paper cites the GEE figures.')

cols = ['tier', 'test', 'n', 'n_phonetics', 'group1_hits', 'group1_n', 'group1_rate', 'group0_hits', 'group0_n', 'group0_rate',
        'gee_OR', 'gee_CI95', 'gee_p_one_sided', 'gee_p_one_sided_exact', 'gee_p_two_sided', 'mh_strata', 'mh_OR', 'mh_CI95', 'cmh_p_two_sided', 'fisher_p_two_sided', 'verdict', 'note']
with open(OUT / 'yisheng_bias_reverse_scenario.csv', 'w', newline='', encoding='utf-8-sig') as f:
    w = csv.DictWriter(f, fieldnames=cols, lineterminator='\n'); w.writeheader()
    for r in res: w.writerow({k: r.get(k, '') for k in cols})
(OUT / 'ext_bias_reverse_scenario_output.txt').write_text('\n'.join(lines) + '\n', encoding='utf-8')
print('\n'.join(lines))
