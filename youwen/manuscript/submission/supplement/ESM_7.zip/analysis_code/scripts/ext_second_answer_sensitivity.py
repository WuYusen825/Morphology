# Enlarged blind semantic coding (sensitivity analysis X5: second answers substituted). Exploratory, added after the results were seen; not part of the decision rule.
# Background: in batches 3 and 6 of pass 1 the coder returned two complete answers to the same prompt. The rule fixed before any analysis was run
#   (analysis_plan, section 7: the first complete valid answer of each coder instance counts) did not count the second answer.
#   Here the second answers replace the first answers for the new items of those two batches and the main test and the related tests are recomputed,
#   to see whether the conclusion depends on that rule.
# Usage: python scripts/ext_second_answer_sensitivity.py      (run scripts/ext_analysis.py first)
# Reads:  data/ext_items_key.csv, output/ext_codes_long.csv, data/raw/pass1_b03.txt, data/raw/pass1_b06.txt and the two *_second_answer_not_used.txt files,
#         output/yisheng_models_ext_coding.csv
# Writes: output/ext_second_answer_sensitivity_output.txt, output/yisheng_models_ext_second_answer.csv, output/ext_second_answer_items.csv
# Note: gee()/mh()/verdict()/add()/frame()/battery() are the same functions as in ext_author_check.py (which are the same as in ext_analysis.py).
#       The script first reproduces the matching rows of yisheng_models_ext_coding.csv with the unsubstituted data (identity check) and then substitutes.
#       The label X5 is used for this analysis to keep it apart from S6 of the analysis plan, section 4.3 (counting only Y).
import re, csv, math, warnings
import numpy as np, pandas as pd
import statsmodels.api as sm, statsmodels.formula.api as smf
from statsmodels.stats.contingency_tables import StratifiedTable
from scipy.stats import fisher_exact, norm
from _paths import DATA, OUT
warnings.filterwarnings('ignore')
SESOI = 2.0
BATCHES = (3, 6)

lines = []
def out(s=''): lines.append(s)

# ---------- Input ----------
key = pd.read_csv(DATA / 'ext_items_key.csv', encoding='utf-8-sig', dtype=str)
C = pd.read_csv(OUT / 'ext_codes_long.csv', encoding='utf-8-sig', dtype=str)
for c in ['label', 'near', 'ident']: C[c] = C[c].astype(int)
C['cat4'] = C.cat4.replace('nan', np.nan)
assert C.sw_id.is_unique and len(C) == 767

LINE = re.compile(r'^\s*(\d+)\s*[\t,|]\s*([YENX])\s*[\t,|]\s*([123])\s*(?:[\t,|]\s*(.*))?$')
def parse(path, n):          # same as parse() in ext_analysis.py
    got = {}
    for ln in open(path, encoding='utf-8'):
        m = LINE.match(ln.rstrip('\n'))
        if m:
            i = int(m.group(1))
            if i in got: raise ValueError(f'{path}: item {i} twice')
            got[i] = (m.group(2), int(m.group(3)), (m.group(4) or '').strip())
    missing = sorted(set(range(1, n + 1)) - set(got))
    if missing: raise ValueError(f'{path}: missing items {missing}')
    extra = sorted(set(got) - set(range(1, n + 1)))
    if extra: raise ValueError(f'{path}: unexpected items {extra}')
    return got

# ---------- 1. The two answers, batch by batch; check that the first answer equals code1 in ext_codes_long.csv ----------
first, second = {}, {}           # sw_id -> four-category code
batch_of = {}
rows = []
for b in BATCHES:
    sub = key[key.p1_batch.astype(int) == b]
    n = len(sub)
    g1 = parse(DATA / 'raw' / f'pass1_b{b:02d}.txt', n)
    g2 = parse(DATA / 'raw' / f'pass1_b{b:02d}_second_answer_not_used.txt', n)
    for _, r in sub.iterrows():
        i = int(r.p1_item)
        rows.append(dict(batch=b, item=i, sw_id=r.sw_id, role=r.role, first=g1[i][0], second=g2[i][0], conf1=g1[i][1], conf2=g2[i][1]))
        if r.role == 'new':
            first[r.sw_id], second[r.sw_id] = g1[i][0], g2[i][0]; batch_of[r.sw_id] = b
I = pd.DataFrame(rows)
new_ids = set(first)
chk = C[C.sw_id.isin(new_ids)]
assert len(chk) == len(new_ids) == 97 + 96 and (chk.code1.values == [first[s] for s in chk.sw_id]).all()     # first answer equals the code1 used in the analysis, item by item
I.to_csv(OUT / 'ext_second_answer_items.csv', index=False, encoding='utf-8-sig')

# Code columns: codeS = both batches substituted; codeS3 / codeS6 = one batch only
C['codeS'] = C.code1; C['codeS3'] = C.code1; C['codeS6'] = C.code1
for s in new_ids:
    k = C.index[C.sw_id == s][0]
    C.at[k, 'codeS'] = second[s]
    if batch_of[s] == 3: C.at[k, 'codeS3'] = second[s]
    else: C.at[k, 'codeS6'] = second[s]

# ---------- 2. Statistical tools (same as ext_author_check.py) ----------
res = []
def gee(df, formula, term):
    x = df.copy()
    for cs in [sm.cov_struct.Exchangeable(), sm.cov_struct.Independence()]:
        try:
            g = smf.gee(formula, groups='phonetic', data=x, family=sm.families.Binomial(), cov_struct=cs).fit()
            b, se = g.params[term], g.bse[term]
            if np.isfinite(b) and np.isfinite(se) and 0 < se < 10 and abs(b) < 10:
                return dict(OR=math.exp(b), lo=math.exp(b - 1.96 * se), hi=math.exp(b + 1.96 * se),
                            p2=2 * norm.sf(abs(b / se)), p1=norm.sf(b / se))
        except Exception:
            pass
    return None
def mh(df, y):
    tabs = []
    for _, g in df.groupby('phonetic'):
        if g.label.nunique() < 2: continue
        tabs.append(np.array([[((g.label == 1) & (g[y] == 1)).sum(), ((g.label == 1) & (g[y] == 0)).sum()],
                              [((g.label == 0) & (g[y] == 1)).sum(), ((g.label == 0) & (g[y] == 0)).sum()]], dtype=float))
    if not tabs: return None
    st = StratifiedTable(tabs); lo, hi = st.oddsratio_pooled_confint()
    return dict(strata=len(tabs), OR=st.oddsratio_pooled, lo=lo, hi=hi, p=st.test_null_odds(correction=False).pvalue)
def verdict(g):
    if g is None: return 'not estimable (GEE; e.g. complete separation)'
    c = g['p1'] < 0.05; a = g['hi'] < SESOI
    if c and a: return 'mixed: excess significant but upper CI below 2 (small residual sound effect)'
    if c: return 'supports C (same word / minimal derivation)'
    if a: return 'supports A (meaning-first)'
    return 'indeterminate'
def add(tier, name, df, y, x='label', formula=None, note='', decide=False):
    L, O = df[df[x] == 1], df[df[x] == 0]
    r = dict(tier=tier, test=name, n=len(df), n_phonetics=df.phonetic.nunique(),
             group1_hits=int(L[y].sum()), group1_n=len(L), group0_hits=int(O[y].sum()), group0_n=len(O),
             group1_rate=round(L[y].mean(), 3) if len(L) else '', group0_rate=round(O[y].mean(), 3) if len(O) else '')
    g = gee(df, formula or f'{y} ~ {x}', x)
    if g:
        r.update(gee_OR=round(g['OR'], 2), gee_CI95=f"{g['lo']:.2f}-{g['hi']:.2f}", gee_p_one_sided='%.2g' % g['p1'], gee_p_two_sided='%.2g' % g['p2'],
                 gee_p_one_sided_exact='%.4g' % g['p1'], p1_raw=g['p1'])
    if x == 'label' and formula is None:
        m = mh(df, y)
        if m: r.update(mh_strata=m['strata'], mh_OR=round(m['OR'], 2), mh_CI95=f"{m['lo']:.2f}-{m['hi']:.2f}", cmh_p_two_sided='%.2g' % m['p'])
    a, n1, c, n0 = r['group1_hits'], r['group1_n'], r['group0_hits'], r['group0_n']
    if n1 and n0: r['fisher_p_two_sided'] = '%.2g' % fisher_exact([[a, n1 - a], [c, n0 - c]])[1]
    if decide: r['verdict'] = verdict(g)
    r['note'] = note
    res.append(r); return g
def frame(code_col, related=('Y', 'E'), sub=None):
    x = C[C.cat4.notna() & (C[code_col] != 'X')].copy()
    x['related'] = x[code_col].isin(related).astype(int)
    return x if sub is None else sub(x)
def battery(code_col, tag):
    P = frame(code_col); PR = P[P.related == 1]
    add(tag, 'P1 near ~ label | related', PR, 'near', decide=True)
    add(tag, 'S1 MC identical ~ label | related', PR, 'ident', decide=True)
    NP = frame(code_col, sub=lambda x: x[x.paronomastic_gloss != 'True'])
    add(tag, 'S2 near ~ label | related, paronomastic glosses removed', NP[NP.related == 1], 'near', decide=True)
    SH = frame(code_col, sub=lambda x: x[(x.label == 0) | (x.layer == 'both')])
    add(tag, 'S3 near ~ label | related, labels shared with Xiao Xu only', SH[SH.related == 1], 'near', decide=True)
    CORE = frame(code_col, sub=lambda x: x[(x.paronomastic_gloss != 'True') & ((x.label == 0) | (x.layer == 'both'))])
    add(tag, 'X3 near ~ label | related, shared and non-paronomastic (exploratory)', CORE[CORE.related == 1], 'near', decide=True)
    PY = frame(code_col, related=('Y',))
    add(tag, 'S6 near ~ label | coded Y only', PY[PY.related == 1], 'near', decide=True)
    PE = frame(code_col, related=('E',))
    add(tag, 'X1 near ~ label | coded E only (exploratory)', PE[PE.related == 1], 'near')
    add(tag, 'S8 H2 related ~ label | all coded pairs, X excluded', P, 'related')
    add(tag, 'S9 near ~ related + label: coefficient of label', P, 'near', x='label', formula='near ~ related + label')
    add(tag, 'S9 near ~ related + label: coefficient of related', P, 'near', x='related', formula='near ~ related + label')
    ex = PR[PR.source == 'extended']
    add(tag, 'X4 near ~ label | related, new items only (exploratory)', ex, 'near')

battery('code1', 'identity_pass1')
battery('codeS', 'second_b3_b6')
battery('codeS3', 'second_b3_only')
battery('codeS6', 'second_b6_only')

# Identity check: without substitution the results of ext_analysis.py must be reproduced
ref = pd.read_csv(OUT / 'yisheng_models_ext_coding.csv', encoding='utf-8-sig', dtype=str).fillna('')
chkmap = {'P1': 'P1', 'S1': 'S1', 'S2': 'S2', 'S3': 'S3', 'X3': 'X3', 'S8': 'S8 H2 related (Y/E) ~ label | all coded pairs in the MC frame, X excluded, pass-1 codes', 'X4': 'X4'}
ok = True; msgs = []
for r in [x for x in res if x['tier'] == 'identity_pass1']:
    tag = r['test'].split(' ')[0]
    if tag not in chkmap: continue
    m = ref[ref.test.str.startswith(chkmap[tag])]
    m = m[m.tier != 'descriptive']
    if tag == 'X4': m = m[m.test.str.startswith('X4 ')]
    if len(m) != 1: ok = False; msgs.append(f'{tag}: {len(m)} rows in reference'); continue
    m = m.iloc[0]
    same = all(str(r.get(c, '')) == m[c] for c in ['group1_hits', 'group1_n', 'group0_hits', 'group0_n', 'gee_OR', 'gee_CI95', 'gee_p_one_sided', 'mh_OR', 'mh_CI95'])
    if not same: ok = False; msgs.append(f'{tag}: differs')
assert ok, msgs

# ---------- 3. Output ----------
def kappa(a, b):
    a, b = list(a), list(b); n = len(a)
    po = sum(x == y for x, y in zip(a, b)) / n
    cats = set(a) | set(b)
    pe = sum((a.count(k) / n) * (b.count(k) / n) for k in cats)
    return ((po - pe) / (1 - pe) if pe < 1 else float('nan')), po
def fmt(r):
    if r is None: return '-'
    g = f"{r['group1_hits']}/{r['group1_n']} vs {r['group0_hits']}/{r['group0_n']}"
    o = f", OR {r['gee_OR']} [{r['gee_CI95'].replace('-', ', ')}], p1 {r['gee_p_one_sided']}" if 'gee_OR' in r else ', not estimable'
    if 'p1_raw' in r and 0.04 <= r['p1_raw'] <= 0.06: o += f" (exact one-sided p {r['p1_raw']:.4f}, right at the .05 boundary)"
    if r.get('mh_OR', '') != '': o += f"; MH {r['mh_OR']} [{r['mh_CI95'].replace('-', ', ')}]"
    return g + o

out('Sensitivity analysis with the second answers substituted (X5; exploratory, added after the results were seen, not part of the decision rule)')
out('Method: in batches 3 and 6 of pass 1 the coder returned a second answer; under the rule fixed before the analysis (the first complete valid answer of each coder instance counts) it was not used.')
out('Here the first answers for the new items of those two batches are replaced by the second answers; everything else stays as it was (the blind codes of the 90 first-sample items and pass 2 are untouched), and the main test and the related tests are recomputed.')
out('The second answer in batch 3 was given by the same coder instance in the same context as the first, so it is not independent of the first; the second answer in batch 6 is a fresh run of the same prompt and is independent of the first (analysis plan, section 7).')
out('The label X5 keeps this analysis apart from S6 of analysis plan section 4.3 (counting only Y).')
out('')
out('1. How the two answers differ (new items, anchor items excluded)')
def cls3(c): return 'R' if c in ('Y', 'E') else ('X' if c == 'X' else 'U')
for b in BATCHES:
    s = I[(I.batch == b) & (I.role == 'new')]
    k4, p4 = kappa(s['first'], s['second'])
    c1 = [cls3(c) for c in s['first']]; c2 = [cls3(c) for c in s['second']]
    k3, p3 = kappa(c1, c2)
    x_ch = int(((s['first'] == 'X') != (s['second'] == 'X')).sum())
    out(f'  Batch {b} ({len(s)} new items): four categories (Y/E/N/X) identical in {int((s["first"] == s["second"]).sum())}/{len(s)} ({p4:.1%}, kappa {k4:.3f}); three categories (related Y/E, unrelated N, proper name X) identical in {sum(x == y for x, y in zip(c1, c2))}/{len(s)} ({p3:.1%}, kappa {k3:.3f}); X versus non-X differs in {x_ch} items')
cc = C[C.sw_id.isin(new_ids)].copy()
cc['c1'] = cc.code1; cc['c2'] = cc.codeS
inframe = cc[cc.cat4.notna()]
out(f'  Of the new items in the two batches, {len(inframe)} have Middle Chinese readings at both ends (labelled {int(inframe.label.sum())}, ordinary {int((inframe.label == 0).sum())}); for {int((inframe.c1 == inframe.c2).sum())} of them the first and second answers give the same four-category code.')
out('  Changes from the first to the second answer (new items in the frame, by group; X = proper name):')
for l, nm in [(1, 'labelled'), (0, 'ordinary')]:
    s = inframe[inframe.label == l]
    def cls(c): return 'X' if c == 'X' else ('related' if c in ('Y', 'E') else 'unrelated')
    tt = pd.Series([f'{cls(a)} -> {cls(b)}' for a, b in zip(s.c1, s.c2) if cls(a) != cls(b)]).value_counts()
    out(f'    {nm} ({len(s)} items): ' + (', '.join(f'{k} {v}' for k, v in tt.items()) if len(tt) else 'no changes'))
out('')
out('2. The table of the main test (in the frame, with Middle Chinese readings, not X; near among the pairs coded related)')
for code_col, nm in [('code1', 'Reference (first answers, as analysed)'), ('codeS', 'Substitution (second answers in batches 3 and 6)'), ('codeS3', 'Batch 3 only'), ('codeS6', 'Batch 6 only')]:
    P = frame(code_col); PR = P[P.related == 1]
    L, O = PR[PR.label == 1], PR[PR.label == 0]
    out(f'  {nm}: {len(P)} pairs in the frame, of which {len(PR)} coded related (labelled {len(L)}, ordinary {len(O)}); near: labelled {int(L.near.sum())}/{len(L)}, ordinary {int(O.near.sum())}/{len(O)}')
out('')
out('3. The tests (GEE clustered by phonetic, one-sided p; rule: p < .05 and upper confidence limit >= 2 supports C)')
byname = {}
for r in res: byname.setdefault(r['test'], {})[r['tier']] = r
tiers = [('identity_pass1', 'Reference (first answers)'), ('second_b3_b6', 'Substitution (batches 3 and 6)'), ('second_b3_only', 'Batch 3 only'), ('second_b6_only', 'Batch 6 only')]
for name, dd in byname.items():
    out(f'  {name}')
    for t, nm in tiers:
        rr = dd.get(t)
        out(f'      {nm}: {fmt(rr)}' + (f'; rule: {rr["verdict"]}' if rr is not None and rr.get('verdict') else ''))
out('')
pp = byname['P1 near ~ label | related']
out('4. Comparison with an independent hand computation')
out(f'  The main test with batches 3 and 6 replaced by the second answers, computed by hand by an independent reader: OR 2.39 [1.38, 4.14]. This script: {fmt(pp["second_b3_b6"])}.')
g_ = pp['second_b3_b6']
same = ('gee_OR' in g_) and abs(float(g_['gee_OR']) - 2.39) < 0.005 and g_['gee_CI95'] == '1.38-4.14'
out('  ' + ('The numbers agree.' if same else 'The numbers do not agree (see the numbers of this script above; the difference is reported as it is and the hand-computed value is not adopted).'))
out('')
out('Notes:')
out('  1. This is an exploratory, post hoc analysis. The main test remains the first-answer result of analysis plan section 4.2 (OR 2.35); the rule fixed beforehand has not been changed.')
out('  2. The substitution concerns only the new items of two batches (193 items, of which those in the frame are given in section 1); the blind codes of the 90 first-sample items, the second blind pass and the authors\' check are untouched.')
out('  3. The second answer in batch 3 comes from the same context as the first and is not an independent recoding; the second answer in batch 6 is an independent fresh run of the same prompt. The rows "Batch 3 only" and "Batch 6 only" show the contribution of each.')
out('  4. The two answers were not merged into a "consensus" and no new coding was done.')

cols = ['tier', 'test', 'n', 'n_phonetics', 'group1_hits', 'group1_n', 'group1_rate', 'group0_hits', 'group0_n', 'group0_rate',
        'gee_OR', 'gee_CI95', 'gee_p_one_sided', 'gee_p_one_sided_exact', 'gee_p_two_sided', 'mh_strata', 'mh_OR', 'mh_CI95', 'cmh_p_two_sided', 'fisher_p_two_sided', 'verdict', 'note']
with open(OUT / 'yisheng_models_ext_second_answer.csv', 'w', newline='', encoding='utf-8-sig') as f:
    w = csv.DictWriter(f, fieldnames=cols, lineterminator='\n'); w.writeheader()
    for r in res: w.writerow({k: r.get(k, '') for k in cols})
(OUT / 'ext_second_answer_sensitivity_output.txt').write_text('\n'.join(lines) + '\n', encoding='utf-8')
print('\n'.join(lines))
