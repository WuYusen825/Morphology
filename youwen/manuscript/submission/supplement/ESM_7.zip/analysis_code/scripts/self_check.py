# Self-check of the analysis package. Three parts:
#   1. Reproduction: every file in expected/ is compared with the file of the same name that the scripts have just written to output/
#      (exact match; a difference of one unit in the last printed digit of a decimal number, as can occur in the variational-Bayes columns "glmm_vb_*"
#      or with other versions of the numerical libraries, is reported as "within tolerance"; counts must always match exactly).
#   2. Paper numbers: the numbers of Tables 2 and 4-11, Fig. 1 and the text of the paper that rest on this package are looked up in output/ and compared with the values printed in the paper.
#   3. Package integrity: UTF-8 text, English column headers, documented columns, file names, script headers, and no e-mail addresses, local file paths or unexpected repository links in any file.
# Usage: python scripts/self_check.py [--no-figure]      (run scripts/run_all.py first; exit code 0 = all checks passed)
import re, sys, csv, glob, py_compile
from pathlib import Path
import pandas as pd
from _paths import ROOT, OUT, DATA

NOFIG = '--no-figure' in sys.argv
EXP = ROOT / 'expected'
fails, warns, passed = [], [], 0
def ok(cond, msg):
    global passed
    if cond: passed += 1
    else: fails.append(msg); print('  FAIL:', msg)
def warn(msg): warns.append(msg); print('  note:', msg)

NUM = re.compile(r'-?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?')
def tok_close(x, y):
    """Integers must match exactly; a decimal number may differ by one unit in its last printed digit (2% if printed in scientific notation)."""
    if x == y: return True
    if '.' not in x or '.' not in y: return False
    fx, fy = float(x), float(y)
    if 'e' in x.lower() or 'e' in y.lower(): return abs(fx - fy) <= 0.02 * abs(fx)
    return abs(fx - fy) <= 1.01 * 10 ** (-len(x.split('.')[1]))
def similar(a, b):
    """Same text skeleton and every number within tok_close."""
    if NUM.sub('#', a) != NUM.sub('#', b): return False
    ta, tb = NUM.findall(a), NUM.findall(b)
    return len(ta) == len(tb) and all(tok_close(x, y) for x, y in zip(ta, tb))

# ------------------------------------------------------------------------------------------------ 1. reproduction
print('1. Reproduction of the expected outputs')
exp_files = sorted(p for p in EXP.glob('*') if p.is_file() and p.suffix in ('.csv', '.txt'))
ok(len(exp_files) > 0, 'expected/ is empty')
# the 14 coder prompts are compared by SHA-256 (the sampling reproduces them exactly)
import hashlib
for line in (EXP / 'prompts.sha256').read_text(encoding='utf-8').splitlines():
    h, name = line.split()
    q = OUT / 'prompts' / name
    ok(q.exists() and hashlib.sha256(q.read_bytes()).hexdigest() == h, f'prompts/{name}: not reproduced exactly')
n_exact = n_tol = 0
for p in exp_files:
    q = OUT / p.name
    if not q.exists():
        ok(False, f'{p.name}: not produced in output/'); continue
    if p.suffix == '.csv':
        a = pd.read_csv(p, encoding='utf-8-sig', dtype=str, keep_default_na=False)
        b = pd.read_csv(q, encoding='utf-8-sig', dtype=str, keep_default_na=False)
        if list(a.columns) != list(b.columns) or a.shape != b.shape:
            ok(False, f'{p.name}: shape or columns differ ({a.shape} vs {b.shape})'); continue
        bad = 0; tolerated = 0
        for c in a.columns:
            for x, y in zip(a[c], b[c]):
                if x == y: continue
                if similar(x, y): tolerated += 1
                else: bad += 1
        ok(bad == 0, f'{p.name}: {bad} cells differ from expected/')
        if bad == 0 and tolerated: warn(f'{p.name}: {tolerated} cells differ in the last digit (within tolerance)'); n_tol += 1
        elif bad == 0: n_exact += 1
    else:
        a, b = p.read_text(encoding='utf-8'), q.read_text(encoding='utf-8')
        if a == b: n_exact += 1; passed += 1
        elif similar(a, b): warn(f'{p.name}: numbers differ in the last digit (within tolerance)'); n_tol += 1; passed += 1
        else: ok(False, f'{p.name}: differs from expected/')
print(f'   {n_exact} files identical, {n_tol} within tolerance, of {len(exp_files)}')
print(f'   ({passed} checks so far, including the coder prompts)')

# ------------------------------------------------------------------------------------------------ 2. paper numbers
print('2. Numbers of the paper')
mark2 = passed
def load(name):
    return pd.read_csv(OUT / name, encoding='utf-8-sig', dtype=str, keep_default_na=False)
T = {n: load(n) for n in ['yisheng_models_ext_coding.csv', 'yisheng_models_ext_author_check.csv', 'yisheng_models_ext_second_answer.csv', 'yisheng_models_extra_checks.csv',
                          'yisheng_models.csv', 'yisheng_models_wangyun_sensitivity.csv', 'yisheng_models_xiaoxu_sensitivity.csv', 'yisheng_bias_reverse_scenario.csv', 'yisheng_summary.csv']}
def dec(s): return len(s.split('.')[1]) if '.' in s else 0
def close(actual, text):
    """actual (float) agrees with the number as printed in the paper (same number of decimals)."""
    return abs(float(actual) - float(text)) <= 0.5 * 10 ** (-dec(text)) + 1e-9
def est(txt, lo_hi_actual, label):
    """txt = '2.35 [1.43, 3.86]'; lo_hi_actual = (or, lo, hi) floats."""
    m = re.fullmatch(r'\s*([\d.]+) \[([\d.]+), ([\d.]+)\]\s*', txt)
    assert m, txt
    ok(all(close(a, t) for a, t in zip(lo_hi_actual, m.groups())), f'{label}: paper {txt}, package {tuple(round(float(x), 3) for x in lo_hi_actual)}')
def counts(row, p, label, pre='group'):
    h1, n1, h0, n0 = (row[f'{pre}1_hits'], row[f'{pre}1_n'], row[f'{pre}0_hits'], row[f'{pre}0_n']) if pre == 'group' else (row['labelled_hits'], row['labelled_n'], row['ordinary_hits'], row['ordinary_n'])
    ok(f'{h1}/{n1} vs {h0}/{n0}' == p, f'{label}: paper {p}, package {h1}/{n1} vs {h0}/{n0}')
def gee(row): lo, hi = row['gee_CI95'].split('-'); return float(row['gee_OR']), float(lo), float(hi)
def mh(row): lo, hi = row['mh_CI95'].split('-'); return float(row['mh_OR']), float(lo), float(hi)
def row_by(df, col, prefix, tier=None, nth=0):
    r = df[df[col].str.startswith(prefix)]
    if tier is not None: r = r[r.tier == tier]
    assert len(r) > nth, (col, prefix, tier, len(r))
    return r.iloc[nth]
def model(prefix, tier='identity_pass1', file='yisheng_models_ext_coding.csv', nth=0):
    df = T[file]
    if file == 'yisheng_models_ext_coding.csv': return row_by(df, 'test', prefix, nth=nth)
    return row_by(df, 'test', prefix, tier=tier, nth=nth)
X = T['yisheng_models_extra_checks.csv']
def extra(i): return X.iloc[i]

# Table 2 and Section 3 flow
c = pd.read_csv(OUT / 'ext_codes_long.csv', encoding='utf-8-sig')
ok((int((c.label == 1).sum()), int((c.label == 0).sum()), len(c)) == (212, 555, 767), 'Table 2: 212 labelled + 555 ordinary = 767 coded pairs')
d = pd.read_csv(DATA / 'pairs.csv', encoding='utf-8-sig', dtype=str, keep_default_na=False)
fr = d[d.in_comparison_frame == 'True']
ok((int((fr.group == 'labelled').sum()), int((fr.group == 'ordinary').sum()), fr.phonetic.nunique()) == (212, 953, 172), 'Table 2: analysis set 212 labelled, 953 ordinary, 172 phonetics')
mcfr = fr[fr.mc_relation != 'NA']
ok((int((mcfr.group == 'labelled').sum()), int((mcfr.group == 'ordinary').sum()), mcfr.phonetic.nunique()) == (177, 858, 152), 'Table 2: pairs with MC readings 177 / 858 on 152 phonetics')
ocfr = fr[fr.morph_relation_auto != 'NA']
ok((int((ocfr.group == 'labelled').sum()), int((ocfr.group == 'ordinary').sum())) == (60, 249), 'Table 2: pairs with OC forms 60 / 249')
ok(int(((d.group == 'labelled') & (d.label_source == 'daxu')).sum()) == 223, 'Section 3.1: 223 labelled head entries after removing the 4 false hits (227 raw strings)')
par = fr[fr.paronomastic_gloss == 'True']
ok((int((par.group == 'labelled').sum()), int((par.group == 'ordinary').sum())) == (58, 11), 'Section 3.3: paronomastic glosses 58 of 212 labelled and 11 of 953 ordinary')
ok((int((fr.filed_under_phonetic == 'True').sum())) == 40, 'Section 4.6: 40 labels filed under their own phonetic')

# Table 4
for i, (rel, lab, ordi, g, m_) in enumerate([('identical', '63/177', '133/858', '2.38 [1.69, 3.34]', '2.15 [1.36, 3.42]'),
                                              ('departing-tone alternation', '21/177', '58/858', '1.64 [1.04, 2.57]', '2.05 [1.03, 4.11]'),
                                              ('other tone or voicing alternation', '12/177', '92/858', '0.62 [0.33, 1.14]', '0.61 [0.28, 1.30]'),
                                              ('other difference', '81/177', '575/858', '0.52 [0.38, 0.70]', '0.44 [0.28, 0.70]')]):
    r = extra(i); counts(r, f'{lab} vs {ordi}', f'Table 4 {rel}', pre='labelled'); est(g, gee(r), f'Table 4 {rel} GEE'); est(m_, mh(r), f'Table 4 {rel} MH')
ok(extra(0).mh_strata == '121' and (extra(0).mh_labelled_n, extra(0).mh_ordinary_n) == ('148', '839'), 'Table 4 note: MH pools 121 phonetics (148 and 839 pairs)')
oc = T['yisheng_summary.csv']
r = oc[oc.comparison == 'OC (BS) identical, all phonetics'].iloc[0]
ok((r.labelled_hits, r.labelled_n, r.ordinary_hits, r.ordinary_n) == ('15', '60', '13', '249'), 'Section 4.1: OC identical 15 of 60 against 13 of 249')

# Table 6 and Section 4.2
mdl = T['yisheng_models.csv']
h1c = mdl[mdl.hypothesis == 'H1c'].iloc[0]; h1b = mdl[mdl.hypothesis == 'H1b'].iloc[0]; h1boc = mdl[mdl.hypothesis == 'H1b-OC'].iloc[0]
est('2.44 [1.34, 4.48]', gee(h1c), 'Table 6 H1c'); ok(close(h1c.holm_p, '0.0056'), 'Table 6 H1c Holm p = 0.0056')
est('1.29 [0.87, 1.91]', gee(h1b), 'Table 6 H1b'); ok(close(h1b.holm_p, '0.20'), 'Table 6 H1b Holm p = 0.20')
est('1.17 [0.62, 2.22]', gee(h1boc), 'Table 6 H1b-OC'); ok(close(h1boc.holm_p, '0.31'), 'Table 6 H1b-OC Holm p = 0.31')
counts(extra(5), '16/33 vs 43/150', 'Table 6 member departing', pre='labelled'); counts(extra(6), '21/33 vs 58/150', 'Table 6 step 1', pre='labelled'); est('2.42 [1.32, 4.46]', gee(extra(6)), 'Table 6 step 1')
counts(extra(10), '16/21 vs 43/58', 'Table 6 step 2', pre='labelled'); est('1.11 [0.31, 4.57]', gee(extra(10)), 'Table 6 step 2 (conditional MLE)'); est('0.27 [0.03, 2.78]', gee(extra(9)), 'Table 6 step 2 GEE')
counts(extra(8), '21/114 vs 58/725', 'Table 6 departing-tone alternation', pre='labelled'); est('2.12 [1.38, 3.26]', gee(extra(8)), 'Table 6 departing-tone alternation')
counts(extra(7), '12/114 vs 92/725', 'Table 6 other alternation', pre='labelled'); est('0.70 [0.36, 1.36]', gee(extra(7)), 'Table 6 other alternation')
counts(extra(11), '18/45 vs 84/236', 'Table 6 OC R', pre='labelled')
counts(extra(12), '8/45 vs 21/236', 'Table 6 R involving *-s', pre='labelled'); est('2.01 [0.98, 4.10]', gee(extra(12)), 'Table 6 R involving *-s')
counts(extra(13), '10/45 vs 63/236', 'Table 6 R not involving *-s', pre='labelled'); est('0.81 [0.39, 1.65]', gee(extra(13)), 'Table 6 R not involving *-s')
s = oc[oc.comparison == 'MC tone/voicing alternation among non-identical, all phonetics'].iloc[0]
ok((s.labelled_hits, s.labelled_n, s.ordinary_hits, s.ordinary_n) == ('33', '114', '150', '725'), 'Table 6 H1b MC: 33/114 vs 150/725')

# Table 7 (first sample and enlarged coding)
fs = (OUT / 'first_sample_checks_output.txt').read_text(encoding='utf-8')
for needle in ['Blind pass all: Y+E 25/33 vs 6/50 OR=22.9', 'Blind pass no paronomastic gloss: Y+E 18/26 vs 6/50 OR=16.5', 'Y only 8/33 vs 0/50 OR=inf p=0.00035',
               'Non-blind pass all: Y+E 27/35 vs 8/53 OR=19.0', 'kappa=0.773 (agreement 86.0%)', 'Y-N disagreements between the two passes: 0',
               'H2 GEE (blind pass): n=83, phonetics=58, OR=22.012 [7.122, 68.032]', 'H2 GEE without paronomastic glosses: n=76, OR=16.361 [5.065, 52.851]',
               'H1a MC identical: 63/177 (35.6%) vs 133/858 (15.5%)', 'Da Xu fanqie identical: 68/204 (33.3%) vs 128/947 (13.5%)', 'GEE OR=2.43 [1.74-3.39]']:
    ok(needle in fs, f'first-sample output: "{needle}" not found')
w = T['yisheng_models_wangyun_sensitivity.csv']
r = w.iloc[3]; est('16.4 [5.1, 52.9]', gee(r), 'Table 7 first sample, paronomastic glosses removed')
counts(extra(91), '25/33 vs 6/46', 'Table 7 note: first sample inside the frame', pre='labelled'); est('20.2 [6.6, 62.1]', gee(extra(91)), 'Table 7 note: frame-restricted H2')
r = model('S8 H2'); counts(r, '141/172 vs 79/462', 'Table 7 enlarged related'); est('21.6 [13.3, 35.0]', gee(r), 'Table 7 enlarged related')
r = model('S8b'); counts(r, '138/172 vs 83/459', 'Table 7 pass 2 related'); est('18.1 [11.7, 27.9]', gee(r), 'Table 7 pass 2 related')
r = row_by(T['yisheng_models_ext_author_check.csv'], 'test', 'S8 H2', tier='author_adjudicated'); counts(r, '138/172 vs 74/457', 'Table 7 authors replacing 126 codes'); est('20.7 [13.0, 33.1]', gee(r), 'Table 7 authors replacing 126 codes')
descr = T['yisheng_models_ext_coding.csv']
yn = descr[descr.test.str.startswith('coded related (Y/E), X excluded | all 212 labelled')]
ok(len(yn) == 1, 'descriptive row for all 212 labelled pairs present')
cl = pd.read_csv(OUT / 'ext_codes_long.csv', encoding='utf-8-sig')
frame = cl[cl.mc_relation.notna() & (cl.code1 != 'X')]
ok((int(((frame.label == 1) & (frame.code1 == 'Y')).sum()), int(((frame.label == 0) & (frame.code1 == 'Y')).sum())) == (38, 4), 'Table 7: near-synonymous (Y) 38/172 against 4/462')
ok(sorted(cl[(cl.label == 0) & (cl.code1 == 'Y') & cl.mc_relation.notna()].char) == sorted('祥愷佮僎'), 'Section 4.3: the four ordinary Y pairs are 祥, 愷, 佮, 僎')

# Section 4.4 and Table 8
spec8 = [('P1 ', '73/141 vs 23/79', '2.35 [1.43, 3.86]', 'Table 8 all related pairs (H5)'), ('S1 ', '54/141 vs 15/79', '2.57 [1.35, 4.87]', 'Table 8 identity only'),
         ('S2 ', '43/94 vs 20/73', '2.09 [1.18, 3.71]', 'Table 8 paronomastic glosses removed'), ('S3 ', '41/93 vs 23/79', '1.81 [1.04, 3.15]', 'Table 8 labels shared by both recensions'),
         ('X3 ', '27/66 vs 20/73', '1.80 [0.95, 3.42]', 'Table 8 shared labels without paronomastic glosses'), ('S5 ', '70/138 vs 23/83', '2.44 [1.49, 3.99]', 'Table 8 pass 2'),
         ('S7 ', '68/132 vs 18/65', '2.60 [1.48, 4.57]', 'Table 8 passes agree'), ('X1 ', '49/103 vs 23/75', '1.80 [1.00, 3.25]', 'Table 8 E only'),
         ('X2 ', None, '2.13 [1.26, 3.63]', 'Table 8 adjusted for Y against E'), ('X4 near', '59/116 vs 21/73', '2.42 [1.37, 4.25]', 'Table 8 677 new items')]
for pre, cnt, e_, lab in spec8:
    r = model(pre)
    if cnt: counts(r, cnt, lab)
    est(e_, gee(r), lab)
r = model('P1 '); est('2.01 [0.75, 5.39]', mh(r), 'Table 8 main test within series'); ok(r.mh_strata == '37', 'Table 8: 37 phonetics within series')
ok(close(r.gee_p_one_sided, '0.0004') or float(r.gee_p_one_sided) < 0.00045, 'Table 8 one-sided p = 0.0004')
r = model('X3 '); est('1.43 [0.29, 7.16]', mh(r), 'Table 8 shared labels without paronomastic glosses, within series')
r = row_by(T['yisheng_models_ext_author_check.csv'], 'test', 'P1 ', tier='author_adjudicated'); counts(r, '70/138 vs 19/74', 'Table 8 authors replacing 126 codes'); est('2.73 [1.61, 4.65]', gee(r), 'Table 8 authors replacing 126 codes'); est('2.26 [0.80, 6.33]', mh(r), 'Table 8 authors replacing 126 codes, within series')
r = row_by(T['yisheng_models_ext_author_check.csv'], 'test', 'X3 ', tier='author_adjudicated'); est('2.14 [1.08, 4.25]', gee(r), 'Table 8 note: authors replacing codes, shared labels without paronomastic glosses'); est('1.24 [0.23, 6.71]', mh(r), 'Table 8 note: same, within series'); ok(r.mh_strata == '13', 'Table 8 note: 13 phonetics')
sa = T['yisheng_models_ext_second_answer.csv']
for tier, cnt, e_ in [('second_b3_b6', '71/139 vs 21/74', '2.39 [1.38, 4.14]'), ('second_b3_only', None, '2.32 [1.42, 3.79]'), ('second_b6_only', None, '2.40 [1.39, 4.14]')]:
    r = row_by(sa, 'test', 'P1 ', tier=tier)
    if cnt: counts(r, cnt, f'Table 8 second answers ({tier})')
    est(e_, gee(r), f'Table 8 second answers ({tier})')
ok(model('S6').gee_OR == '' and model('S6').group1_hits == '24' and model('S6').group1_n == '38' and model('S6').group0_n == '4', 'Table 8 note: counting only Y cannot be estimated (24 of 38 against 0 of 4)')
ok(close(model('S6').fisher_p_two_sided, '0.027'), 'Table 8 note: Fisher p = 0.027 for the Y-only comparison')
est('2.34 [1.51, 3.63]', gee(model('S9 near ~ related + label: coefficient of related')), 'Section 4.4 relatedness effect (OR 2.34)'); est('1.98 [1.30, 3.02]', gee(model('S9 near ~ related + label: coefficient of label')), 'Section 4.4 label effect (OR 1.98)')
d_ = T['yisheng_models_ext_coding.csv']
def dcount(cat, grp):
    r = d_[d_.test == f'MC category {cat} | related {grp} pairs'].iloc[0]; return int(r.group1_hits)
ok((dcount('identical', 'labelled') + dcount('alt_departing', 'labelled'), dcount('other', 'labelled'), dcount('alt_other', 'labelled')) == (73, 60, 8), 'Section 4.4: 141 related labelled pairs = 73 near + 60 remote + 8 other tone or voicing')

# Table 10 and Section 4.6
for i, (cat, a_, b_) in enumerate([('identical', '35/122', '24/48'), ('alt_departing', '14/122', '6/48'), ('alt_other', '10/122', '2/48'), ('other', '63/122', '16/48')]):
    r = extra(23 + i); counts(r, f'{a_} vs {b_}', f'Table 10 {cat}', pre='labelled')
ok(extra(26).fisher_p_two_sided == '0.04', 'Section 4.6: remote 16 against 63, Fisher p = 0.04')
x16 = T['yisheng_models_xiaoxu_sensitivity.csv'].iloc[16]; est('0.39 [0.19, 0.80]', gee(x16), 'Section 4.6: OR shared relative to Da Xu-only for identity'); ok(close(x16.gee_p_two_sided, '0.01'), 'Section 4.6: p = 0.01')
counts(extra(30), '24/46 vs 26/90', 'Section 4.6 not filed under own phonetic', pre='labelled'); ok(close(extra(30).fisher_p_two_sided, '0.0091') or extra(30).fisher_p_two_sided == '0.0091', 'Section 4.6: Fisher p = 0.009')
counts(extra(31), '21/62 vs 31/140', 'Section 4.6 paronomastic gloss by layer', pre='labelled')
counts(extra(85), '24/92 vs 39/85', 'Section 4.6 core labels against the rest', pre='labelled'); ok(extra(85).fisher_p_two_sided == '0.0075', 'Section 4.6: Fisher p = 0.0075')
counts(extra(86), '4/21 vs 129/837', 'Section 4.6 Duan-noted ordinary compounds', pre='labelled'); ok(extra(86).fisher_p_two_sided == '0.55', 'Section 4.6: Fisher p = 0.55')
counts(extra(90), '13/32 vs 49/143', 'Section 4.6 labels Duan drops against keeps', pre='labelled'); counts(extra(89), '9/34 vs 54/143', 'Section 4.6 labels filed under own phonetic', pre='labelled')
ok(extra(90).fisher_p_two_sided == '0.54' and extra(89).fisher_p_two_sided == '0.24', 'Section 4.6: p = 0.54 (Duan) and p = 0.24 (filed under own phonetic)')
counts(extra(27), '45/81 vs 284/575', 'Section 4.5 initial and final both differ', pre='labelled'); ok(extra(27).fisher_p_two_sided == '0.34', 'Section 4.5: p = 0.34')
counts(extra(28), '6/29 vs 48/179', 'Section 4.5 OC R among the remote pairs', pre='labelled'); ok(extra(28).fisher_p_two_sided == '0.65', 'Section 4.5: p = 0.65')
x_ = T['yisheng_models_xiaoxu_sensitivity.csv']
counts(x_.iloc[19], '16/22 vs 8/10', 'Section 4.6 H3 meaning (Dà Xú-only 8/10, shared 16/22)', pre='labelled')

# Table 11
rows11 = [  # (label, H1a GEE, H1a MH, H1c GEE, H1c MH, H2) with row indices into the extra-checks table (46-60), the sensitivity tables and the first-sample table
    ('All labels', '2.38 [1.69, 3.34]', extra(0), '2.15 [1.36, 3.42]', '2.44 [1.34, 4.48]', extra(5), '7.35 [1.09, 49.5]', '22.0 [7.1, 68.0]', w.iloc[2]),
    ('Paronomastic glosses removed', '1.99 [1.34, 2.96]', extra(46), '1.54 [0.85, 2.78]', '1.82 [0.79, 4.22]', extra(48), '4.47 [0.65, 30.9]', '16.4 [5.1, 52.9]', w.iloc[3]),
    ('Labels shared by both recensions', '1.83 [1.18, 2.82]', extra(49), '1.58 [0.90, 2.78]', '2.32 [1.09, 4.93]', extra(51), '6.71 [1.01, 44.7]', '19.8 [5.5, 70.8]', x_.iloc[6]),
    ('Shared labels, paronomastic glosses removed', '1.59 [0.97, 2.61]', extra(52), '1.22 [0.61, 2.46]', '2.03 [0.78, 5.29]', extra(54), '4.47 [0.65, 30.9]', '16.1 [4.4, 59.2]', x_.iloc[7]),
    ("Wang Yun's nine rejected labels removed", '2.37 [1.68, 3.36]', extra(55), '2.26 [1.40, 3.64]', '2.21 [1.14, 4.29]', extra(57), '7.35 [1.09, 49.5]', '20.5 [6.6, 63.9]', w.iloc[6]),
    ('40 labels filed under own phonetic removed', '2.51 [1.74, 3.60]', extra(58), '2.17 [1.32, 3.56]', '2.58 [1.39, 4.81]', extra(60), None, None, None)]
for lab, h1a, rA, h1aMH, h1c, rC, h1cMH, h2, rH in rows11:
    est(h1a, gee(rA), f'Table 11 {lab}: H1a GEE'); est(h1aMH, mh(rA), f'Table 11 {lab}: H1a within series')
    est(h1c, gee(rC), f'Table 11 {lab}: H1c GEE')
    if h1cMH: est(h1cMH, mh(rC), f'Table 11 {lab}: H1c within series')
    if h2: est(h2, gee(rH), f'Table 11 {lab}: H2')
ok(extra(60).mh_OR == 'inf', 'Table 11: H1c within series not estimable after removing the filed-under labels')
est('2.43 [1.74, 3.39]', tuple(float(x) for x in re.search(r'GEE OR=([\d.]+) \[([\d.]+)-([\d.]+)\]', re.search(r'Da Xu fanqie identical.*', fs).group(0)).groups()), 'Table 11 identity read from fanqie strings')
ok(close(x_.iloc[4].gee_OR, '1.94') and close(x_.iloc[5].gee_OR, '2.44'), 'Table 11 note: 1.94 and 2.44 for the shared labels (ordinary restricted to series that keep a label)')
ok(close(w.iloc[4].gee_OR, '2.51') and close(w.iloc[5].gee_OR, '2.11'), 'Table 11 note: 2.51 and 2.11 without Wang Yun\'s nine (ordinary restricted)')
counts(extra(52), '24/92 vs 131/848', 'Section 4.6: the 92 core labels', pre='labelled')

# Text: agreement statistics, bias sensitivity, reverse scenario
kap = (OUT / 'ext_kappa_output.txt').read_text(encoding='utf-8')
for needle in ['0.817', '0.681', '0.824', '0.875', '0.918']:
    ok(needle in kap, f'Section 3.4: kappa {needle} not found in ext_kappa_output.txt')
sa_txt = (OUT / 'ext_second_answer_sensitivity_output.txt').read_text(encoding='utf-8')
for needle in ['Batch 3 (97 new items)', 'Batch 6 (96 new items)', '(193 items, of which']:
    ok(needle in sa_txt, f'Section 3.4: "{needle}" not found in the second-answer output')
ac = (OUT / 'ext_author_check_output.txt').read_text(encoding='utf-8')
for needle in ['126 items = all 76 items on which the two passes disagree + 50 items drawn at random from the 601 on which they agree', 'kappa = 0.735 [0.603, 0.842]', 'kappa = 0.798 [0.666, 0.905]', 'same as pass 1: 23; same as pass 2: 50; different from both: 3', 'four-category agreement 45/50; related/unrelated agreement 47/50']:
    ok(needle in ac, f'Section 4.3: "{needle}" not found in the author-check output')
bs = (OUT / 'ext_bias_sensitivity_output.txt').read_text(encoding='utf-8')
for needle in ['11.5% of the truly unrelated ordinary pairs', 'about 50 of the 79', 'bringing it to 2 needs 5.9%', 'false-positive rate is 4.2%', 'OR* = 2.20 [1.18, 4.34]', '10.2% [2.5%, 20.6%]', 'a false-positive rate of 4.2% [2.1%, 6.8%]', 'fp_O = 11.0%',
               'of the 333 pairs coded unrelated in pass 2, 14 were coded related in pass 1', '6 belong to the original 100 items', 'of the 73 new items, 20 were checked', '53 have no author judgment']:
    ok(needle in bs, f'Section 5.2: "{needle}" not found in the bias-sensitivity output')
rv = T['yisheng_bias_reverse_scenario.csv']
r = rv[(rv.tier == 'fold_all') & rv.test.str.startswith('P1r')].iloc[0]; counts(r, '81/172 vs 23/79', 'reverse scenario S3 counts'); est('2.00 [1.23, 3.26]', gee(r), 'reverse scenario S3 (GEE OR 2.00)')
pc = (OUT / 'paper_counts_output.txt').read_text(encoding='utf-8')
ok('all counts agree with the files' in pc, 'paper_counts.py did not finish')

# Fig. 1
if not NOFIG:
    fv = pd.read_csv(OUT / 'fig1_h5_forest_values.csv', encoding='utf-8-sig')
    ok(len(fv) == 13, 'Fig. 1: 13 rows')
    ok((OUT / 'fig1_h5_forest.png').exists() and (OUT / 'fig1_h5_forest.png').stat().st_size > 20000, 'Fig. 1 image written')

# ------------------------------------------------------------------------------------------------ 3. package integrity
print(f'   ({passed - mark2} numbers and counts compared)')
print('3. Package integrity')
mark3 = passed
files = [p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts]
TEXT_EXT = {'.py', '.csv', '.txt', '.md'}
bad_names = [str(p.relative_to(ROOT)) for p in files if not re.fullmatch(r'[A-Za-z0-9._\-]+', p.name)]
ok(not bad_names, f'file names with spaces or special characters: {bad_names[:5]}')
for p in files:
    if p.suffix in TEXT_EXT:
        try: p.read_text(encoding='utf-8')
        except UnicodeDecodeError: ok(False, f'{p.relative_to(ROOT)} is not valid UTF-8')
hdr_bad = []
for p in files:
    if p.suffix == '.csv':
        hdr = next(csv.reader(open(p, encoding='utf-8-sig', newline='')))
        if not all(re.fullmatch(r'[A-Za-z0-9_]+', h) for h in hdr): hdr_bad.append(str(p.relative_to(ROOT)))
ok(not hdr_bad, f'non-English or non-ASCII column headers in {hdr_bad}')
dic = pd.read_csv(ROOT / 'data_dictionary.csv', encoding='utf-8-sig', dtype=str, keep_default_na=False)
undoc = []
for p in files:
    rel = p.relative_to(ROOT).as_posix()
    if p.suffix == '.csv' and rel.split('/')[0] in ('data', 'output'):
        cols = pd.read_csv(p, encoding='utf-8-sig', nrows=0).columns
        have = set(dic[dic.file == rel].column)
        undoc += [f'{rel}:{c}' for c in cols if c not in have]
ok(not undoc, f'columns missing from data_dictionary.csv: {undoc[:8]}')
cookie = re.compile(r'^[ \t\f]*#.*?coding[:=][ \t]*([-\w.]+)')
for p in sorted((ROOT / 'scripts').glob('*.py')):
    try: py_compile.compile(str(p), doraise=True, cfile=str(Path(p.parent, '__pycache__', p.name + 'c')))
    except Exception as e: ok(False, f'{p.name} does not compile: {e}')
    first2 = p.read_text(encoding='utf-8').split('\n')[:2]
    ok(not any(cookie.match(l) for l in first2), f'{p.name}: the first two lines look like an encoding declaration (PEP 263)')
# no e-mail addresses, local file paths or links to repositories other than the open resources that the paper cites
pat = [r'[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}', r'/home/', r'/tmp/', r'/mnt/', r'[A-Z]:\\Users', r'github\.com/(?!shuowenjiezi/shuowen|digling/cddb)']
hits = []
for p in files:
    if p.suffix in TEXT_EXT and p.name != 'self_check.py':          # this file lists the patterns
        t = p.read_text(encoding='utf-8')
        for rx in pat:
            m = re.search(rx, t)
            if m: hits.append(f'{p.relative_to(ROOT)}: {m.group(0)}')
ok(not hits, f'e-mail addresses, local paths or unexpected repository links found: {hits[:6]}')
print(f'   ({passed - mark3} integrity checks)')
print(f'\n{passed} checks passed, {len(fails)} failed' + (f', {len(warns)} notes' if warns else ''))
sys.exit(1 if fails else 0)
