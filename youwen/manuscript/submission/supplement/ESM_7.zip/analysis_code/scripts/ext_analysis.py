# Enlarged blind semantic coding, step 2 (analysis). The plan (ESM_4) and this script were written before any batch was coded.
# Usage: python scripts/ext_analysis.py
# Reads:  data/ext_items_key.csv, data/raw/pass{1,2}_b{01..07}.txt (the coders' raw answers), data/first_sample_codes.csv,
#         data/pairs.csv, data/recension_collation.csv
# Writes: output/ext_codes_long.csv           (both passes for every coded pair, with group and Middle Chinese category)
#         output/yisheng_models_ext_coding.csv (primary, secondary, exploratory and descriptive tests; earlier values in the note column)
#         output/ext_kappa_output.txt          (kappa between the two passes and against the first sample's blind codes on the anchor items)
#         output/ext_check_key.csv, output/ext_check_sheet_blank.csv  (the authors' check: all disagreements between the passes plus 50 random agreed items)
import os, re, csv, math, random, warnings
import numpy as np, pandas as pd
import statsmodels.api as sm, statsmodels.formula.api as smf
from statsmodels.stats.contingency_tables import StratifiedTable
from scipy.stats import fisher_exact, norm
from _paths import DATA, OUT
warnings.filterwarnings('ignore')
SEED_CHECK, N_CHECK_RANDOM, N_BATCH = 20260934, 50, 7
SESOI = 2.0  # smallest effect of interest (analysis plan, section 4)

key = pd.read_csv(DATA / 'ext_items_key.csv', encoding='utf-8-sig', dtype=str)

# ---------- 1. Read the raw answers ----------
LINE = re.compile(r'^\s*(\d+)\s*[\t,|]\s*([YENX])\s*[\t,|]\s*([123])\s*(?:[\t,|]\s*(.*))?$')
def parse(path, n):
    got = {}
    for ln in open(path, encoding='utf-8'):
        m = LINE.match(ln.rstrip('\n'))
        if m:
            i = int(m.group(1))
            if i in got: raise ValueError(f'{path}: item {i} twice')
            got[i] = (m.group(2), int(m.group(3)), (m.group(4) or '').strip())
    missing = sorted(set(range(1, n + 1)) - set(got))
    if missing: raise ValueError(f'{path}: missing items {missing}')
    extra = sorted(set(got) - set(range(1, n + 1)))
    if extra: raise ValueError(f'{path}: unexpected items {extra}')
    return got
codes = {}
for p in (1, 2):
    for b in range(1, N_BATCH + 1):
        sub = key[key[f'p{p}_batch'].astype(int) == b]
        n = len(sub)
        got = parse(DATA / 'raw' / f'pass{p}_b{b:02d}.txt', n)
        for _, r in sub.iterrows():
            c, conf, note = got[int(r[f'p{p}_item'])]
            codes[(p, r.sw_id)] = (c, conf, note)
for p in (1, 2):
    key[f'p{p}_code'] = [codes[(p, s)][0] for s in key.sw_id]
    key[f'p{p}_conf'] = [codes[(p, s)][1] for s in key.sw_id]
    key[f'p{p}_note'] = [codes[(p, s)][2] for s in key.sw_id]

# ---------- 2. Merge: every coded pair in the frame ----------
d = pd.read_csv(DATA / 'pairs.csv', encoding='utf-8-sig', dtype=str)
A = d[d.in_analysis_set == 'True']
yph = set(A[A.relation == '亦聲'].phonetic)
F = A[A.phonetic.isin(yph)].copy()
DEP = {'member', 'head'}
def cat4(r):
    if pd.isna(r.mc_relation): return np.nan
    if r.mc_relation == 'identical': return 'identical'
    if r.mc_relation == 'tone_voicing_alt': return 'alt_departing' if r.mc_qusheng_direction in DEP else 'alt_other'
    return 'other'
F['cat4'] = F.apply(cat4, axis=1)
M = F[F.cat4.notna()]
assert (int(((M.relation == '亦聲') & (M.cat4 == 'identical')).sum()), int((M.relation == '亦聲').sum()),
        int(((M.relation == '聲') & (M.cat4 == 'identical')).sum()), int((M.relation == '聲').sum())) == (63, 177, 133, 858)
LAY = {r['sw_id']: r['layer'] for r in csv.DictReader(open(DATA / 'recension_collation.csv', encoding='utf-8-sig'))}
F['layer'] = F.sw_id.map(LAY)

S = pd.read_csv(DATA / 'first_sample_codes.csv', encoding='utf-8-sig', dtype=str)
S = S.rename(columns={'phonetic': 'series', 'member': 'char', 'blind_code': 'code', 'blind_confidence': 'conf'})
S = S[S.sw_id.isin(F.sw_id)]  # sw_id links each coded pair to data/pairs.csv; the 90 items inside the frame remain
assert len(S) == 90 and (S.relation == S.relation_in_pairs).all()

NEW = key[key.role == 'new']
rows = []
for _, r in S.iterrows():
    rows.append(dict(sw_id=r.sw_id, source='original_100', code1=r.code, code2=r.code, conf1=r.conf, conf2=r.conf))
for _, r in NEW.iterrows():
    rows.append(dict(sw_id=r.sw_id, source='extended', code1=r.p1_code, code2=r.p2_code, conf1=r.p1_conf, conf2=r.p2_conf))
C = pd.DataFrame(rows).merge(F[['sw_id', 'phonetic', 'char', 'relation', 'cat4', 'paronomastic_gloss', 'layer', 'mc_relation']], on='sw_id', how='left')
assert len(C) == 767 and C.sw_id.is_unique and C.relation.notna().all()
C['label'] = (C.relation == '亦聲').astype(int)
C['near'] = C.cat4.isin(['identical', 'alt_departing']).astype(int)
C['ident'] = (C.cat4 == 'identical').astype(int)
C.to_csv(OUT / 'ext_codes_long.csv', index=False, encoding='utf-8-sig')
key.to_csv(OUT / 'ext_items_with_answers.csv', index=False, encoding='utf-8-sig')  # items with both passes' code, confidence and note (used for the data workbook)

# ---------- 3. Statistical tools ----------
res = []
def gee(df, formula, term):
    x = df.copy()
    for cs, nm in [(sm.cov_struct.Exchangeable(), 'exchangeable'), (sm.cov_struct.Independence(), 'independence')]:
        try:
            g = smf.gee(formula, groups='phonetic', data=x, family=sm.families.Binomial(), cov_struct=cs).fit()
            b, se = g.params[term], g.bse[term]
            # |b| < 10 and se < 10: rules out the diverging estimates that arise under complete separation (added after coding, see the plan, section 7)
            if np.isfinite(b) and np.isfinite(se) and 0 < se < 10 and abs(b) < 10:
                return dict(OR=math.exp(b), lo=math.exp(b - 1.96 * se), hi=math.exp(b + 1.96 * se),
                            p2=2 * norm.sf(abs(b / se)), p1=norm.sf(b / se), cov=nm, n=len(x), clusters=x.phonetic.nunique())
        except Exception:
            pass
    return None
def mh(df, y):
    tabs = []
    for _, g in df.groupby('phonetic'):
        if g.label.nunique() < 2: continue
        tabs.append(np.array([[((g.label == 1) & (g[y] == 1)).sum(), ((g.label == 1) & (g[y] == 0)).sum()],
                              [((g.label == 0) & (g[y] == 1)).sum(), ((g.label == 0) & (g[y] == 0)).sum()]], dtype=float))
    if not tabs: return None
    st = StratifiedTable(tabs); lo, hi = st.oddsratio_pooled_confint()
    return dict(strata=len(tabs), OR=st.oddsratio_pooled, lo=lo, hi=hi, p=st.test_null_odds(correction=False).pvalue)
def verdict(g):
    if g is None: return 'not estimable (GEE; e.g. complete separation)'
    c = g['p1'] < 0.05; a = g['hi'] < SESOI
    if c and a: return 'mixed: excess significant but upper CI below 2 (small residual sound effect)'
    if c: return 'supports C (same word / minimal derivation)'
    if a: return 'supports A (meaning-first)'
    return 'indeterminate'
def add(tier, name, df, y, x='label', formula=None, note='', decide=False):
    L, O = df[df[x] == 1], df[df[x] == 0]
    r = dict(tier=tier, test=name, n=len(df), n_phonetics=df.phonetic.nunique(),
             group1_hits=int(L[y].sum()), group1_n=len(L), group0_hits=int(O[y].sum()), group0_n=len(O),
             group1_rate=round(L[y].mean(), 3) if len(L) else '', group0_rate=round(O[y].mean(), 3) if len(O) else '')
    g = gee(df, formula or f'{y} ~ {x}', x)
    if g:
        r.update(gee_OR=round(g['OR'], 2), gee_CI95=f"{g['lo']:.2f}-{g['hi']:.2f}", gee_p_one_sided='%.2g' % g['p1'], gee_p_two_sided='%.2g' % g['p2'], gee_cov=g['cov'])
    if x == 'label' and formula is None:
        m = mh(df, y)
        if m: r.update(mh_strata=m['strata'], mh_OR=round(m['OR'], 2), mh_CI95=f"{m['lo']:.2f}-{m['hi']:.2f}", cmh_p_two_sided='%.2g' % m['p'])
    a, n1, c, n0 = r['group1_hits'], r['group1_n'], r['group0_hits'], r['group0_n']
    if n1 and n0: r['fisher_p_two_sided'] = '%.2g' % fisher_exact([[a, n1 - a], [c, n0 - c]])[1]
    if decide: r['verdict'] = verdict(g)
    r['note'] = note
    res.append(r); return g

def frame(code_col, related=('Y', 'E'), sub=None):
    x = C[C.cat4.notna() & (C[code_col] != 'X')].copy()
    x['related'] = x[code_col].isin(related).astype(int)
    return x if sub is None else sub(x)

# ---------- 4. Primary test ----------
P = frame('code1'); PR = P[P.related == 1]
add('primary', 'P1 near (MC identical or departing-tone alternation) ~ label | pairs coded related (Y/E), pass-1 codes', PR, 'near', decide=True,
    note=f'one-sided test of OR > 1; smallest effect of interest OR {SESOI}; group1 = labelled, group0 = ordinary. '
         'Earlier value (first blind sample, 83 pairs, descriptive): 14/25 vs 2/6, Fisher p 0.39 (yisheng_models_v7_checks.csv, related pairs only)')

# ---------- 5. Secondary tests ----------
add('secondary', 'S1 MC identical ~ label | related, pass-1 codes', PR, 'ident', decide=True, note='earlier value (first blind sample): 9/25 vs 1/6')
NP = frame('code1', sub=lambda x: x[x.paronomastic_gloss != 'True'])
add('secondary', 'S2 near ~ label | related, paronomastic glosses removed (both groups)', NP[NP.related == 1], 'near', decide=True)
SH = frame('code1', sub=lambda x: x[(x.label == 0) | (x.layer == 'both')])
add('secondary', 'S3 near ~ label | related, labels shared with Xiao Xu only (all ordinary kept)', SH[SH.related == 1], 'near', decide=True,
    note='definition of the shared-labels row in Table 11: labelled entries dropped, all ordinary compounds kept')
# S4 = the mh_* columns of the primary row (within-phonetic Mantel-Haenszel estimate)
P2 = frame('code2'); P2R = P2[P2.related == 1]
add('secondary', 'S5 near ~ label | related, pass-2 codes for the new items (original blind codes for the 90 old items)', P2R, 'near', decide=True)
PY = frame('code1', related=('Y',))
add('secondary', 'S6 near ~ label | pairs coded Y only (strict relatedness), pass-1 codes', PY[PY.related == 1], 'near', decide=True,
    note='guards against residual confounding by true relatedness when E is a noisy proxy')
AG = P[(P.source == 'original_100') | (P.code1.isin(['Y', 'E']) == P.code2.isin(['Y', 'E']))]
add('secondary', 'S7 near ~ label | related, pairs whose two passes agree on related vs unrelated', AG[AG.related == 1], 'near', decide=True)
g_old = dict(note='earlier value: first blind sample, 83 pairs, 25/33 vs 6/50, GEE OR 22.0 [7.1, 68.0], p 3.9e-08 (first_sample_checks_output.txt); '
                  'frame-corrected 25/33 vs 6/46, OR 20.2 [6.56, 62.13] (yisheng_models_v7_checks.csv, section "blind sample frame")')
add('secondary', 'S8 H2 related (Y/E) ~ label | all coded pairs in the MC frame, X excluded, pass-1 codes', P, 'related', **g_old)
add('secondary', 'S8b H2 related (Y/E) ~ label | as S8 with pass-2 codes', P2, 'related')
add('secondary', 'S9 near ~ related + label: coefficient of related (meaning-first precondition), pass-1 codes', P, 'near', x='related', formula='near ~ related + label',
    note='group1 = related, group0 = unrelated (both groups pooled); earlier value (first blind sample, 79 in-frame pairs, ordinary logit): related OR 10.06 [2.17, 46.58]')
add('secondary', 'S9 near ~ related + label: coefficient of label, pass-1 codes', P, 'near', x='label', formula='near ~ related + label',
    note='earlier value (first blind sample, 79 in-frame pairs, ordinary logit): label OR 1.28 [0.29, 5.55]')
for grp, nm in [(1, 'labelled'), (0, 'ordinary')]:
    add('secondary', f'S9 near ~ related within {nm} pairs, pass-1 codes', P[P.label == grp], 'near', x='related',
        note='group1 = related, group0 = unrelated; earlier value (first blind sample): ' + ('14/25 vs 0/8' if grp else '2/6 vs 4/40'))

# ---------- 5b. Exploratory tests (added after the coding was complete and the main result seen, see the plan, section 7;
#              not pre-specified tests, and not part of the decision rule) ----------
PE = frame('code1', related=('E',))
add('exploratory', 'X1 near ~ label | pairs coded E only, pass-1 codes (stand-in for S6, which is not estimable)', PE[PE.related == 1], 'near',
    note='added after the first run: S6 has only 4 ordinary pairs coded Y (0 near), so the strength-of-relatedness bias is checked within E instead')
PRY = PR.copy(); PRY['isY'] = (PRY.code1 == 'Y').astype(int)
add('exploratory', 'X2 near ~ label + Y: coefficient of label | related, pass-1 codes (adjusts for Y vs E)', PRY, 'near', formula='near ~ label + isY',
    note='added after the first run; group1 = labelled, group0 = ordinary')
CORE = frame('code1', sub=lambda x: x[(x.paronomastic_gloss != 'True') & ((x.label == 0) | (x.layer == 'both'))])
add('exploratory', 'X3 near ~ label | related, labels shared with Xiao Xu and no paronomastic gloss (core; ordinary without paronomastic gloss)', CORE[CORE.related == 1], 'near',
    note='added after the first run; S2 and S3 combined, as in the core of Table 11 (92 pairs, not conditioned on relatedness: GEE 1.59 [0.97, 2.61])')
add('exploratory', 'X4 near ~ label | related, the 677 newly coded items only, pass-1 codes', PR[PR.source == 'extended'], 'near',
    note='added after the independent check of the results; the 90 original items alone are row X4b')
add('exploratory', 'X4b near ~ label | related, the 90 original blind-coded items only (original blind codes)', PR[PR.source == 'original_100'], 'near',
    note='added with X4; earlier value (first blind sample): 14/25 vs 2/6, Fisher p 0.39')

# ---------- 6. Descriptive ----------
ALLL = C[C.label == 1].copy(); ALLL['related'] = ALLL.code1.isin(['Y', 'E']).astype(int)
for nm, sub in [('all 212 labelled pairs', ALLL), ('labelled pairs without MC readings', ALLL[ALLL.cat4.isna()])]:
    s2 = sub[sub.code1 != 'X']
    res.append(dict(tier='descriptive', test=f'coded related (Y/E), X excluded | {nm}', n=len(s2), group1_hits=int(s2.related.sum()), group1_n=len(s2),
                    group1_rate=round(s2.related.mean(), 3) if len(s2) else '', note=f'X coded: {int((sub.code1 == "X").sum())}'))
for k in ['identical', 'alt_departing', 'alt_other', 'other']:
    for grp, nm in [(1, 'labelled'), (0, 'ordinary')]:
        s2 = PR[PR.label == grp]
        res.append(dict(tier='descriptive', test=f'MC category {k} | related {nm} pairs', n=len(s2), group1_hits=int((s2.cat4 == k).sum()), group1_n=len(s2),
                        group1_rate=round((s2.cat4 == k).mean(), 3) if len(s2) else ''))
for k in ['identical', 'alt_departing', 'alt_other', 'other']:
    s2 = P[P.cat4 == k]
    res.append(dict(tier='descriptive', test=f'coded related (Y/E) | MC category {k}, labelled and ordinary pooled', n=len(s2),
                    group1_hits=int(s2.related.sum()), group1_n=len(s2), group1_rate=round(s2.related.mean(), 3) if len(s2) else '',
                    note='earlier value (first blind sample): identical 10/13, alt_departing 6/7, alt_other 1/6, other 14/53'))

cols = ['tier', 'test', 'n', 'n_phonetics', 'group1_hits', 'group1_n', 'group1_rate', 'group0_hits', 'group0_n', 'group0_rate',
        'gee_OR', 'gee_CI95', 'gee_p_one_sided', 'gee_p_two_sided', 'gee_cov', 'mh_strata', 'mh_OR', 'mh_CI95', 'cmh_p_two_sided',
        'fisher_p_two_sided', 'verdict', 'note']
with open(OUT / 'yisheng_models_ext_coding.csv', 'w', newline='', encoding='utf-8-sig') as f:
    w = csv.DictWriter(f, fieldnames=cols, lineterminator='\n'); w.writeheader()
    for r in res: w.writerow({k: r.get(k, '') for k in cols})

# ---------- 7. Kappa ----------
def kappa(a, b):
    a, b = list(a), list(b); n = len(a)
    po = sum(x == y for x, y in zip(a, b)) / n
    cats = set(a) | set(b)
    pe = sum((a.count(k) / n) * (b.count(k) / n) for k in cats)
    return ((po - pe) / (1 - pe) if pe < 1 else float('nan')), po
lines = []
def rep(tag, a, b):
    k4, p4 = kappa(a, b); k2, p2 = kappa([x in 'YE' for x in a], [y in 'YE' for y in b]); kY, pY = kappa([x == 'Y' for x in a], [y == 'Y' for y in b])
    lines.append(f'{tag}: n={len(a)}  four-category kappa={k4:.3f} (agreement {p4:.1%})  related (Y/E) vs unrelated kappa={k2:.3f} (agreement {p2:.1%})  Y vs not-Y kappa={kY:.3f} (agreement {pY:.1%})')
rep('New items, pass 1 vs pass 2', NEW.p1_code, NEW.p2_code)
for rel, nm in [('亦聲', 'labelled'), ('聲', 'ordinary')]:
    s2 = NEW[NEW.relation == rel]; rep(f'  of which {nm} pairs', s2.p1_code, s2.p2_code)
AN = key[key.role == 'anchor']
rep('35 anchor items, pass 1 vs first sample', AN.p1_code, AN.orig_code)
rep('35 anchor items, pass 2 vs first sample', AN.p2_code, AN.orig_code)
rep('35 anchor items, pass 1 vs pass 2', AN.p1_code, AN.p2_code)
lines.append('')
lines.append('Cross-tabulation of the two passes on the new items (rows = pass 1, columns = pass 2):')
lines.append(pd.crosstab(NEW.p1_code, NEW.p2_code).to_string())
lines.append('')
for _, r in AN[AN.p1_code != AN.orig_code].iterrows():
    lines.append(f'Anchor disagreement (pass 1) {r.phonetic}/{r.char}: first sample {r.orig_code}, pass 1 {r.p1_code}')
for _, r in AN[AN.p2_code != AN.orig_code].iterrows():
    lines.append(f'Anchor disagreement (pass 2) {r.phonetic}/{r.char}: first sample {r.orig_code}, pass 2 {r.p2_code}')
# Addendum (added after coding began and before the formal run, see the plan, section 7): second answers returned by the same coder instance; used in no analysis
extra = [(p, b) for p in (1, 2) for b in range(1, N_BATCH + 1)
         if os.path.exists(DATA / 'raw' / f'pass{p}_b{b:02d}_second_answer_not_used.txt')]
if extra:
    lines.append('')
    lines.append('Addendum (not used in any analysis here, see the plan, section 7): second answers returned by the same coder instance, compared with the first answer that counts')
    for p, b in extra:
        n = int((key[f'p{p}_batch'].astype(int) == b).sum())
        g1 = parse(DATA / 'raw' / f'pass{p}_b{b:02d}.txt', n)
        g2 = parse(DATA / 'raw' / f'pass{p}_b{b:02d}_second_answer_not_used.txt', n)
        a1, a2 = [g1[i][0] for i in range(1, n + 1)], [g2[i][0] for i in range(1, n + 1)]
        k4, p4 = kappa(a1, a2)
        lines.append(f'  Pass {p}, batch {b}: n={n}, four-category agreement {sum(x == y for x, y in zip(a1, a2))}/{n}, kappa={k4:.3f}')
open(OUT / 'ext_kappa_output.txt', 'w', encoding='utf-8').write('\n'.join(lines) + '\n')

# ---------- 8. The authors' check: all disagreements between the passes + 50 random items among those on which the passes agree (group not shown) ----------
dis = NEW[NEW.p1_code != NEW.p2_code]
agr = NEW[NEW.p1_code == NEW.p2_code].sort_values('sw_id', key=lambda s: s.astype(int))
rc = random.Random(SEED_CHECK)
pick = rc.sample(list(agr.sw_id), min(N_CHECK_RANDOM, len(agr)))
CH = pd.concat([dis.assign(why='passes_disagree'), agr[agr.sw_id.isin(pick)].assign(why='random_agreed')])
order = list(CH.sw_id); rc.shuffle(order)
CH = CH.set_index('sw_id').loc[order].reset_index(); CH['check_id'] = range(1, len(CH) + 1)
CH[['check_id', 'sw_id', 'phonetic', 'char', 'relation', 'why', 'p1_code', 'p2_code']].to_csv(OUT / 'ext_check_key.csv', index=False, encoding='utf-8-sig')
CH.assign(author_code='', author_note='').rename(columns={'why': 'check_type', 'char': 'member', 'p1_code': 'pass1_code', 'p2_code': 'pass2_code'})[
    ['check_id', 'check_type', 'phonetic', 'phonetic_gloss', 'member', 'member_gloss', 'author_code', 'pass1_code', 'pass2_code', 'author_note']
].to_csv(OUT / 'ext_check_sheet_blank.csv', index=False, encoding='utf-8-sig')

for r in res:
    print(r['tier'], '|', r['test'], '|', f"{r.get('group1_hits', '')}/{r.get('group1_n', '')} vs {r.get('group0_hits', '')}/{r.get('group0_n', '')}",
          '| GEE', r.get('gee_OR', ''), r.get('gee_CI95', ''), 'p1', r.get('gee_p_one_sided', ''), '| MH', r.get('mh_OR', ''), r.get('mh_CI95', ''),
          '|', r.get('verdict', ''))
print('\n'.join(lines[:8]))
print('check sheet rows:', len(CH), '(disagreements', len(dis), ')')
