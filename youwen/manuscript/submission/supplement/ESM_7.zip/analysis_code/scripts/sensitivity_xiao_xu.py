# Recension-layer analysis (H3) and the sensitivity analysis "labels shared by both recensions": the H1a, H1c and H2 models of the paper are rerun on subsets
#   defined by the collation of the Da Xu and Xiao Xu texts (data/recension_collation.csv, column "layer": both / daxu_only / unknown).
# Variants: original; keep only the labels shared by both recensions (drop Da Xu-only and undecidable ones); drop Da Xu-only (keep undecidable ones);
#   Da Xu-only labels recoded as ordinary (sheng). H3 additionally compares the two layers within the labelled compounds (two-sided, exploratory).
# Usage: python scripts/sensitivity_xiao_xu.py
# Reads:  data/pairs.csv, data/first_sample_codes.csv, data/recension_collation.csv      Writes: output/yisheng_models_xiaoxu_sensitivity.csv
import csv, math, warnings
import pandas as pd, statsmodels.api as sm, statsmodels.formula.api as smf
from statsmodels.genmod.bayes_mixed_glm import BinomialBayesMixedGLM
from _paths import DATA, OUT
warnings.filterwarnings('ignore')
LAB, ORD = 'labelled', 'ordinary'
LAY = {r['sw_id']: r['layer'] for r in csv.DictReader(open(DATA / 'recension_collation.csv', encoding='utf-8-sig', newline=''))}
R = list(csv.DictReader(open(DATA / 'pairs.csv', encoding='utf-8-sig', newline='')))
lay = lambda r: LAY.get(str(r['sw_id']), '') if r['group'] == LAB else ''
S = list(csv.DictReader(open(DATA / 'first_sample_codes.csv', encoding='utf-8-sig', newline='')))
DS = {(r['phonetic'], r['char'], r['group']): r for r in R}
def keep(r, drop, recode):
    l = lay(r)
    if l in drop: return None
    if l in recode: return dict(r, group=ORD)
    return r
def variant(drop, recode):
    rows = [x for x in (keep(r, drop, recode) for r in R if r['in_analysis_set'] == 'True') if x]
    yph = {r['phonetic'] for r in rows if r['group'] == LAB}
    return [r for r in rows if r['phonetic'] in yph]
def h2rows(drop, recode):
    o = []
    for s in S:
        d = DS.get((s['phonetic'], s['member'], s['group']))
        if not d or d['in_analysis_set'] != 'True' or s['blind_code'] == 'X': continue
        d = keep(d, drop, recode)
        if not d: continue
        o.append(dict(y=int(s['blind_code'] in 'YE'), label=int(d['group'] == LAB), phon=d['phonetic'], par=d['paronomastic_gloss']))
    return pd.DataFrame(o)
def fit(df, vb=True, two=False):
    g = smf.gee('y ~ label', groups='phon', data=df, family=sm.families.Binomial(), cov_struct=sm.cov_struct.Exchangeable()).fit()
    b, se = g.params['label'], g.bse['label']; p = g.pvalues['label'] if two else (g.pvalues['label'] / 2 if b > 0 else 1 - g.pvalues['label'] / 2)
    res = dict(n=len(df), n_phonetics=df.phon.nunique(), labelled_hits=int(df[df.label == 1].y.sum()), labelled_n=int((df.label == 1).sum()),
               ordinary_hits=int(df[df.label == 0].y.sum()), ordinary_n=int((df.label == 0).sum()),
               gee_OR=round(math.exp(b), 2), gee_CI95=f'{math.exp(b - 1.96 * se):.2f}-{math.exp(b + 1.96 * se):.2f}', **{('gee_p_two_sided' if two else 'gee_p_one_sided'): '%.2g' % p})
    if vb:
        v = BinomialBayesMixedGLM.from_formula('y ~ label', {'phon': '0 + C(phon)'}, df).fit_vb()
        i = list(v.model.exog_names).index('label'); bm, sd = v.fe_mean[i], v.fe_sd[i]
        res.update(glmm_vb_OR=round(math.exp(bm), 2), glmm_vb_CI95=f'{math.exp(bm - 1.96 * sd):.2f}-{math.exp(bm + 1.96 * sd):.2f}')
    return res
res = []
for vname, drop, recode in [('original', (), ()), ('both recensions only (drop Da Xu-only and unknown)', ('daxu_only', 'unknown'), ()),
                            ('drop Da Xu-only (keep unknown)', ('daxu_only',), ()), ('Da Xu-only recoded as ordinary (sheng)', (), ('daxu_only',))]:
    A = variant(drop, recode); mc = [r for r in A if r['mc_relation'] != 'NA']
    df = pd.DataFrame(dict(y=[int(r['mc_relation'] == 'identical') for r in mc], label=[int(r['group'] == LAB) for r in mc], phon=[r['phonetic'] for r in mc]))
    res.append(dict(variant=vname, hypothesis='H1a', outcome='MC identical syllable', **fit(df)))
    alt = [r for r in mc if r['mc_relation'] == 'tone_voicing_alt']
    df = pd.DataFrame(dict(y=[int(r['mc_qusheng_direction'] == 'member') for r in alt], label=[int(r['group'] == LAB) for r in alt], phon=[r['phonetic'] for r in alt]))
    res.append(dict(variant=vname, hypothesis='H1c', outcome='member departing | tone/voicing alternation', **fit(df)))
    h = h2rows(drop, recode)
    res.append(dict(variant=vname, hypothesis='H2', outcome='semantic Y/E (blind LLM coding, X excluded)', **fit(h, vb=False)))
    res.append(dict(variant=vname, hypothesis='H2', outcome='same, paronomastic glosses removed', **fit(h[h.par == 'False'], vb=False)))
# H3: within the labelled compounds, both (labelled columns) against daxu_only (ordinary columns), two-sided
Y = [r for r in R if r['in_analysis_set'] == 'True' and r['group'] == LAB and lay(r) in ('both', 'daxu_only')]
m = [r for r in Y if r['mc_relation'] != 'NA']
for name, rows, pred in [('MC identical syllable', m, lambda r: r['mc_relation'] == 'identical'),
                         ('MC tone/voicing alternation', m, lambda r: r['mc_relation'] == 'tone_voicing_alt'),
                         ('member departing | alternation', [r for r in m if r['mc_relation'] == 'tone_voicing_alt'], lambda r: r['mc_qusheng_direction'] == 'member')]:
    df = pd.DataFrame(dict(y=[int(pred(r)) for r in rows], label=[int(lay(r) == 'both') for r in rows], phon=[r['phonetic'] for r in rows]))
    try: f = fit(df, vb=False, two=True)
    except Exception as e: f = dict(n=len(df), labelled_hits=int(df[df.label == 1].y.sum()), labelled_n=int((df.label == 1).sum()), ordinary_hits=int(df[df.label == 0].y.sum()), ordinary_n=int((df.label == 0).sum()), gee_OR='fit failed')
    res.append(dict(variant='H3 within labelled: both (labelled columns) vs Da Xu-only (ordinary columns)', hypothesis='H3', outcome=name, **f))
h = []
for s in S:
    d = DS.get((s['phonetic'], s['member'], s['group']))
    if d and d['in_analysis_set'] == 'True' and s['blind_code'] != 'X' and lay(d) in ('both', 'daxu_only'): h.append(dict(y=int(s['blind_code'] in 'YE'), label=int(lay(d) == 'both'), phon=d['phonetic']))
h = pd.DataFrame(h); res.append(dict(variant='H3 within labelled: both (labelled columns) vs Da Xu-only (ordinary columns)', hypothesis='H3', outcome='semantic Y/E (blind LLM)', n=len(h), labelled_hits=int(h[h.label == 1].y.sum()), labelled_n=int((h.label == 1).sum()), ordinary_hits=int(h[h.label == 0].y.sum()), ordinary_n=int((h.label == 0).sum())))
with open(OUT / 'yisheng_models_xiaoxu_sensitivity.csv', 'w', newline='', encoding='utf-8-sig') as f:
    w = csv.DictWriter(f, fieldnames=list(dict.fromkeys(k for r in res for k in r)), lineterminator='\n'); w.writeheader(); w.writerows(res)
for r in res: print(r['variant'][:40], '|', r['hypothesis'], r['outcome'][:30], f"{r['labelled_hits']}/{r['labelled_n']} vs {r['ordinary_hits']}/{r['ordinary_n']}", r.get('gee_OR', ''), r.get('gee_CI95', ''), r.get('gee_p_one_sided', r.get('gee_p_two_sided', '')), r.get('glmm_vb_OR', ''))
