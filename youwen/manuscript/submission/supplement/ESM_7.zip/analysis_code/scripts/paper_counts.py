# Counts quoted in the paper that no result file prints directly.
# Reads output/ext_codes_long.csv (one row per coded pair; code1 = pass 1 for the new items and the first blind pass for the 90 first-sample items in the frame,
# code2 = pass 2 likewise), output/ext_author_check_output.txt, data/pairs.csv and data/recension_collation.csv; prints each count with the place in the paper
# that cites it, writes output/paper_counts_output.txt and output/table5_departing_tone_members.csv, and stops with an AssertionError if a number in the paper
# would no longer match the files.
# Usage: python scripts/paper_counts.py      (run scripts/ext_analysis.py and scripts/ext_author_check.py first)
import csv
import pandas as pd
from _paths import DATA, OUT

lines = []
a = pd.read_csv(OUT / 'ext_codes_long.csv', encoding='utf-8-sig')
ac = (OUT / 'ext_author_check_output.txt').read_text(encoding='utf-8')

def say(s): print(s); lines.append(str(s))
def check(label, got, want):
    say(f'{label}: {got}')
    assert got == want, (label, got, want)

# Table 2 and Section 3.4: the flow from coded pairs to the tests
lab, ordi = a[a.label == 1], a[a.label == 0]
check('coded pairs (labelled, ordinary, all)', (len(lab), len(ordi), len(a)), (212, 555, 767))
check('new items, first-sample items in the frame', (int((a.source == 'extended').sum()), int((a.source == 'original_100').sum())), (677, 90))
check('labelled without an MC reading', int(lab.mc_relation.isna().sum()), 35)
check('labelled proper names with an MC reading', int(((lab.mc_relation.notna()) & (lab.code1 == 'X')).sum()), 5)
check('ordinary proper names', int((ordi.code1 == 'X').sum()), 93)
frame = a[(a.mc_relation.notna()) & (a.code1 != 'X')]
check('pairs in the tests (labelled, ordinary)', (int((frame.label == 1).sum()), int((frame.label == 0).sum())), (172, 462))
check('phonetics in the tests', frame.phonetic.nunique(), 150)

# Section 4.3: disagreements between the two blind passes on the 677 new items
new = a[a.source == 'extended']
dis = new[new.code1 != new.code2].copy()
check('disagreements (all, labelled, ordinary)', (len(dis), int((dis.label == 1).sum()), int((dis.label == 0).sum())), (76, 33, 43))
check('share of the 677', round(100 * len(dis) / len(new), 1), 11.2)
dis['pair'] = ['/'.join(sorted([x, y])) for x, y in zip(dis.code1, dis.code2)]
by = dis.groupby(['label', 'pair']).size()
check('labelled Y/E, E/N', (int(by[(1, 'E/Y')]), int(by[(1, 'E/N')])), (16, 15))
check('ordinary E/N, N/X', (int(by[(0, 'E/N')]), int(by[(0, 'N/X')])), (30, 10))
rel_n = dis[dis.pair.isin(['E/N', 'N/Y'])].groupby('label').size()
check('related on one pass, N on the other (labelled, ordinary)', (int(rel_n[1]), int(rel_n[0])), (17, 31))
check('new items per group (labelled, ordinary)', (int((new.label == 1).sum()), int((new.label == 0).sum())), (177, 500))

# Section 4.3: the authors' check, as printed by scripts/ext_author_check.py
for needle in ['same as pass 1: 23; same as pass 2: 50; different from both: 3',
               'four-category agreement 45/50; related/unrelated agreement 47/50',
               'kappa = 0.735 [0.603, 0.842]', 'kappa = 0.798 [0.666, 0.905]',
               'labelled pairs (45 items): unchanged 18, Y/E within related 12, related→unrelated 10, unrelated→related 5',
               'ordinary pairs (81 items): unchanged 50, related→unrelated 13, unrelated→related 8']:
    assert needle in ac, needle
say('author-check figures found in ext_author_check_output.txt')

# Table 3: the example pairs are items on which both passes agreed with confidence 3
ex = [('頃', '傾', 'Y'), ('巽', '僎', 'Y'), ('耳', '珥', 'E'), ('米', '鬻', 'E'), ('匡', '恇', 'N'), ('亡', '良', 'N'),
      ('善', '鄯', 'X'), ('文', '汶', 'X')]
for ph, ch, code in ex:
    r = a[(a.phonetic == ph) & (a.char == ch)]
    assert len(r) == 1 and r.iloc[0].code1 == r.iloc[0].code2 == code and r.iloc[0].conf1 == r.iloc[0].conf2 == 3, (ph, ch)
say('Table 3 examples: both passes agree with confidence 3')

# Table 5: the 16 labelled pairs whose member is the departing-tone alternant of the phonetic (H1c, 16 of 33 alternations)
d = pd.read_csv(DATA / 'pairs.csv', encoding='utf-8-sig', dtype=str, keep_default_na=False)
coll = pd.read_csv(DATA / 'recension_collation.csv', encoding='utf-8-sig', dtype=str, keep_default_na=False)
t5 = d[(d.group == 'labelled') & (d.in_analysis_set == 'True') & (d.mc_qusheng_direction == 'member')]
t5 = t5.merge(coll[['sw_id', 'layer']], on='sw_id', how='left')
a2 = a.copy(); a2['sw_id'] = a2.sw_id.astype(str)
t5 = t5.merge(a2[['sw_id', 'code1', 'source']].rename(columns={'code1': 'blind_code', 'source': 'coding_source'}), on='sw_id', how='left')
check('Table 5 rows', len(t5), 16)
check('Table 5: with a paronomastic gloss', int((t5.paronomastic_gloss == 'True').sum()), 8)
check('Table 5: shared by both recensions', int((t5.layer == 'both').sum()), 11)
check('Table 5: layer undecidable', t5[t5.layer == 'unknown'].char.tolist(), ['緉'])
check('Table 5: blind codes (Y, E, X)', (int((t5.blind_code == 'Y').sum()), int((t5.blind_code == 'E').sum()), int((t5.blind_code == 'X').sum())), (8, 7, 1))
t5 = t5[['sw_id', 'char', 'char_codepoint', 'phonetic', 'phonetic_codepoint', 'mc_bs2014', 'head_mc_bs2014', 'shuowen_gloss', 'blind_code', 'paronomastic_gloss', 'layer']]
t5.to_csv(OUT / 'table5_departing_tone_members.csv', index=False, encoding='utf-8-sig', lineterminator='\n')

# Table 9: relation types of the homophonous pairs; ordinary pairs restricted to the 172 phonetics of the frame
dd = pd.read_csv(DATA / 'pairs.csv', encoding='utf-8-sig')
dd = dd[dd.in_analysis_set == True]  # noqa: E712
ph172 = set(dd[dd.group == 'labelled'].phonetic)
hom = dd[dd.mc_relation == 'identical']
lab_t = hom[hom.group == 'labelled'].identical_relation_type.value_counts().to_dict()
ord_t = hom[(hom.group == 'ordinary') & hom.phonetic.isin(ph172)].identical_relation_type.value_counts().to_dict()
check('homophonous labelled pairs by type', lab_t, {'F': 42, 'L': 8, 'C': 5, 'U': 8})
check('homophonous ordinary pairs by type (172-phonetic frame)', ord_t, {'U': 73, 'X': 42, 'F': 15, 'L': 3})
check('homophonous ordinary pairs (frame, all rows)', (sum(ord_t.values()), int((hom.group == 'ordinary').sum())), (133, 143))

# Section 4.4: what the ordinary rate would give among the 141 related labelled pairs
check('141 x 23/79', round(141 * 23 / 79), 41)

# Section 4.4: the illustrative pairs (member, phonetic, reading category, group, blind pass-1 code where the paper names it)
for mem, ph, cat, grp, code in [('傾', '頃', 'identical', 1, 'Y'), ('珥', '耳', 'alt_departing', 1, 'E'), ('窞', '臽', 'other', 1, 'Y'), ('胖', '半', 'other', 1, None),
                                ('𠛎', '句', 'identical', 0, None), ('繪', '會', 'identical', 0, None), ('僎', '巽', 'other', 0, 'Y'), ('鬻', '米', 'other', 0, 'E')]:
    r = a[(a.char == mem) & (a.phonetic == ph)]
    assert len(r) == 1 and r.iloc[0].cat4 == cat and r.iloc[0].label == grp and (code is None or r.iloc[0].code1 == code), (mem, ph)
say('Section 4.4 illustrative pairs: reading categories and codes as in the text')

# Section 5.4 and Section 4.6: Wang Yun's nine rejected labels, the recension layers and the labels filed under their own phonetic
WY = list('貧愾恇娶婚姻婢緉坪')
check("Wang Yun's nine labels by reading category", a[(a.label == 1) & a.char.isin(WY)].groupby('cat4').size().to_dict(), {'alt_departing': 3, 'alt_other': 1, 'identical': 4, 'other': 1})
in_set = coll[coll.in_analysis_set == 'True']
check('212 entries by recension layer (both, Da Xu only, undecidable)', in_set.layer.value_counts().to_dict(), {'both': 140, 'daxu_only': 62, 'unknown': 10})
check("three of Wang Yun's nine labels present in both recensions", coll[coll.char.isin(list('愾恇婢')) & (coll.in_analysis_set == 'True')].layer.tolist(), ['both', 'both', 'both'])
fu = d[(d.group == 'labelled') & (d.in_analysis_set == 'True') & (d.filed_under_phonetic == 'True')].merge(coll[['sw_id', 'layer']], on='sw_id', how='left')
check('labels filed under their own phonetic (all, in both recensions)', (len(fu), int((fu.layer == 'both').sum())), (40, 37))
check('the 62 entries only in Da Xu include 喪, which Xiao Xu reads as a plain phonetic compound', coll[coll.char == '喪'][['layer', 'xiaoxu_reading']].values.tolist(), [['daxu_only', '聲']])
say('all counts agree with the files')
(OUT / 'paper_counts_output.txt').write_text('\n'.join(lines) + '\n', encoding='utf-8')
